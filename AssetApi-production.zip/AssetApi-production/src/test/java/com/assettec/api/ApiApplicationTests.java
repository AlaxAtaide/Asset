package com.assettec.api;

import com.assettec.api.integration.IG.transactions.inventory.InventoryLineService;
import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.orders.workorder.WorkOrderService;
import com.assettec.api.internal.core.receipt.POReceiptService;
import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.internal.core.transactions.Store2StoreService;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.mobile.services.WorkOrderMobileService;
import lombok.SneakyThrows;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class ApiApplicationTests {

    static Logger logger = LogManager.getLogger(ApiApplicationTests.class);

    @Autowired
    private RequestSender requestSender;
    @Autowired
    private RequestCreator requestBuilder;
    @Autowired
    private XMLParser xmlParser;
    @Autowired
    private InventoryLineService inventoryLineService;
    @Autowired
    private ApiUserService apiUserService;
    @Autowired
    private Store2StoreService store2StoreService;
    @Autowired
    private POReceiptService poReceiptService;
    @Autowired
    private GridService gridService;
    @Autowired
    private WorkOrderMobileService workOrderMobileService;
    @Autowired
    private WorkOrderService workOrderService;

    String host = XMLParser.getInforHost();

    @Test
    @SneakyThrows
    void test() {}
}


