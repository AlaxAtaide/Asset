package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PartRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String getPart(String userName, String tenant, String passWord, String organization, String partCode, String partOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0241_GetPart_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"Part\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0241_001\">\n" +
                "            <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PARTID>\n" +
                "        </MP0241_GetPart_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postPart(String userName, String tenant, String passWord, String organization, String partCode, String partOrganization, String partDescription, String uomCode, String typeTrackCode, String objectCode, String organizationCode, String departmentCode, String model) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0240_AddPart_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Part\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0240_001\">\n" +
                "            <Part recordid=\"1\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" xmlns=\"http://schemas.datastream.net/MP_entities/Part_001\">\n" +
                "                <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + partDescription + "</DESCRIPTION>\n" +
                "                </PARTID>\n" +
                "                <UOMID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + uomCode + "</UOMCODE>\n" +
                "                </UOMID>\n" +
                "                <TRACKMETHOD entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + typeTrackCode + "</TYPECODE>\n" +
                "                </TRACKMETHOD>\n" +
                "                <Profile recordid=\"1\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" xmlns=\"http://schemas.datastream.net/MP_entities/Profile_001\">\n" +
                "                    <PROFILEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                        <OBJECTCODE>" + objectCode + "</OBJECTCODE>\n" +
                "                        <ORGANIZATIONID entity=\"Equipment\">\n" +
                "                            <ORGANIZATIONCODE>" + organizationCode + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PROFILEID>\n" +
                "                    <DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                        <DEPARTMENTCODE>" + departmentCode + "</DEPARTMENTCODE> \n" +
                "                    </DEPARTMENTID>\n" +
                "                    <ManufacturerInfo>\n" +
                "                        <MODEL xmlns=\"http://schemas.datastream.net/MP_fields\">" + model + "</MODEL>\n" +
                "                    </ManufacturerInfo>\n" +
                "                </Profile>\n" +
                "            </Part>\n" +
                "        </MP0240_AddPart_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPart(String userName, String tenant, String passWord, String organization, String partCode, String partOrganization, String partDescription, String uomCode, String typeTrackCode, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0242_SyncPart_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"Part\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0242_001\">\n" +
                "            <Part recordid=\"" + updatedCount + "\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" xmlns=\"http://schemas.datastream.net/MP_entities/Part_001\">\n" +
                "                <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + partDescription + "</DESCRIPTION>\n" +
                "                </PARTID>\n" +
                "                <UOMID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + uomCode + "</UOMCODE>\n" +
                "                </UOMID>\n" +
                "                <TRACKMETHOD entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + typeTrackCode + "</TYPECODE>\n" +
                "                </TRACKMETHOD>\n" +
                "            </Part>\n" +
                "        </MP0242_SyncPart_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deletePart(String userName, String tenant,String passWord, String organization, String partCode, String partOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0243_DeletePart_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"Part\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0243_001\">\n" +
                "            <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PARTID>\n" +
                "        </MP0243_DeletePart_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
