package com.assettec.api.internal.core.entities.supplier;

import com.assettec.api.internal.core.entities.supplier.address.SupplierAddress;
import com.assettec.api.internal.core.entities.supplier.contact.SupplierContact;
import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Supplier {
    private Long id;
    private String company;

    private String code;
    private String organization;
    private String description;
    private String currency;
    private String language;

    private Set<SupplierAddress> supplierAddresses = new HashSet<>();
    private Set<SupplierContact> supplierContacts = new HashSet<>();

    private UserDefinedFields userDefinedFields;
    private UserDefinedArea userDefinedArea;

    private int updatedCount;
}
