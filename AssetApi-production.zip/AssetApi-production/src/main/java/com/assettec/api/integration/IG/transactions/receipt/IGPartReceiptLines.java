package com.assettec.api.integration.IG.transactions.receipt;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGPartReceiptLines {
    private String partCode;
    private String partOrganization;
    private String partBin;
    private double receivedQuantity;
    private int partLine;
}
