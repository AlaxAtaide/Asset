package com.assettec.api.integration.IG.transactions.system;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGFilteredSystem {
    private String systemCode;
    private String systemStatus;
    private String systemDepartment;
    private String systemOrganization;
}
