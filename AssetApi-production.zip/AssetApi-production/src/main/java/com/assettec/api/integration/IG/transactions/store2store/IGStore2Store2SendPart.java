package com.assettec.api.integration.IG.transactions.store2store;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGStore2Store2SendPart {
    private String oldBin;
    private String newBin;
    private String partCode;
    private String codeIGERP;
    private double receivedQuantity;
}
