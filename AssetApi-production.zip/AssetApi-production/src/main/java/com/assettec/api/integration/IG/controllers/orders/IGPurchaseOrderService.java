package com.assettec.api.integration.IG.controllers.orders;

import com.assettec.api.integration.IG.controllers.orders.purchase.IGPurchaseOrder;
import com.assettec.api.integration.IG.controllers.orders.purchase.IGPurchaseOrderLine;
import com.assettec.api.integration.IG.controllers.orders.purchase.send.IGSendPurchaseOrder;
import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.core.items.part.PartService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.orders.purchaseorder.PartForPurchase;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrder;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrderService;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class IGPurchaseOrderService {

    private PurchaseOrderService purchaseOrderService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;
    private GridService gridService;
    private PartService partService;

    @SneakyThrows
    public List<IGSendPurchaseOrder> returnPurchaseOrdersByStatus(ApiUser apiUser, String status) {
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "PSPORD", "PSPORD", "purchaseorderstatus", status, "=");
        response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");
        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar ordens de compra com status: " + status);

        List<PurchaseOrder> purchaseOrderList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String code = gridService.getDataByName("ordercode",row);
            String organization = gridService.getDataByName("organization",row);
            String rowStatus = gridService.getDataByName("purchaseorderstatus",row);

            // todo: mudar o status
            if (Objects.equals(rowStatus, status)) {
                PurchaseOrder purchaseOrder = purchaseOrderService.getPurchaseOrder(apiUser, code, organization);
                purchaseOrderList.add(purchaseOrder);
            }
        }

        List<IGSendPurchaseOrder> sendPurchaseOrders = new ArrayList<>();
        for (PurchaseOrder purchaseOrder : purchaseOrderList) {
            IGSendPurchaseOrder sendPurchaseOrder = new IGSendPurchaseOrder();

            sendPurchaseOrder.setPurchaseOrderCode(purchaseOrder.getCode());
            sendPurchaseOrder.setPurchaseOrderOrganization(purchaseOrder.getOrganization());
            sendPurchaseOrder.setPurchaseOrderDescription(purchaseOrder.getDescription());
            sendPurchaseOrder.setPurchaseOrderClass(purchaseOrder.getClassCode());

            sendPurchaseOrder.setPurchaseOrderCreatedDate(purchaseOrder.getOrderDate());
            sendPurchaseOrder.setPurchaseOrderDueDate(purchaseOrder.getDueDate());
            sendPurchaseOrder.setPurchaseOriginator(purchaseOrder.getOriginator().getCode());
            sendPurchaseOrder.setSupplierCode(purchaseOrder.getSupplier().getCode());
            sendPurchaseOrder.setStoreCode(purchaseOrder.getStore().getCode());
            sendPurchaseOrder.setPurchasePaymentTerm(purchaseOrder.getPaymentTerm());
            sendPurchaseOrder.setPurchasePaymentMethod(purchaseOrder.getPaymentMethod());

            List<IGPurchaseOrderLine> purchaseOrderLines = new ArrayList<>();
            for (int j = 0; j < purchaseOrder.getPartsForPurchase().size(); j++) {
                PartForPurchase partForPurchase = purchaseOrder.getPartsForPurchase().get(j);
                IGPurchaseOrderLine igPurchaseOrderLine = new IGPurchaseOrderLine();

                igPurchaseOrderLine.setPurchaseOrderLine(Integer.parseInt(partForPurchase.getLineNum()) / 10);
                //todo: procurar no lugar certo o código do IGERP
                String codeIGERP = partService.getPart(apiUser,partForPurchase.getPart().getCode(),partForPurchase.getPart().getOrganization()).getUserDefinedFields().getUdfChar04() == null ? "" : partService.getPart(apiUser,partForPurchase.getPart().getCode(),partForPurchase.getPart().getOrganization()).getUserDefinedFields().getUdfChar04();
                igPurchaseOrderLine.setIgerpPartCode(codeIGERP);
                igPurchaseOrderLine.setPartCode(partForPurchase.getPart().getCode());
                igPurchaseOrderLine.setPartOrganization(partForPurchase.getPart().getOrganization());
                igPurchaseOrderLine.setPartDescription(partForPurchase.getPart().getDescription());
                igPurchaseOrderLine.setQuantity(Double.parseDouble(partForPurchase.getPartQuantity()));
                igPurchaseOrderLine.setQuantityPerUnitOfMetric(Double.parseDouble(partForPurchase.getConversionFactor()));
                igPurchaseOrderLine.setUnitOfMetric(partForPurchase.getPurchaseUnitOfMetric());
                igPurchaseOrderLine.setPricePerUnitOfMetric(Double.parseDouble(partForPurchase.getPrice()));

                purchaseOrderLines.add(igPurchaseOrderLine);
            }
            sendPurchaseOrder.setPurchaseOrderLines(purchaseOrderLines);
            sendPurchaseOrders.add(sendPurchaseOrder);
        }
        return sendPurchaseOrders;
    }

    @SneakyThrows
    public IGSendPurchaseOrder confirmSentPurchaseOrder(ApiUser apiUser, List<IGSendPurchaseOrder> sentPurchaseOrders, IGPurchaseOrder request) {
        if (request.getCode() == null || request.getCode().isEmpty()) throw new IllegalStateException("PurchaseOrderCode não pode ser null ou estar em branco.");

        for (IGSendPurchaseOrder sentPurchaseOrder : sentPurchaseOrders) {
            if (sentPurchaseOrder.getPurchaseOrderCode().equals(request.getCode())) {
                //todo: testar e descomentar as coisas
                PurchaseOrder purchaseOrder = purchaseOrderService.getPurchaseOrder(apiUser, sentPurchaseOrder.getPurchaseOrderCode(), sentPurchaseOrder.getPurchaseOrderOrganization());
                String postRequest = requestBuilder.getPurchaseOrderRequestBuilder().putPurchaseOrder(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), purchaseOrder.getCode(), purchaseOrder.getOrganization(), purchaseOrder.getDescription(), "A", purchaseOrder.getType(), purchaseOrder.getSupplier().getCode(), purchaseOrder.getSupplier().getOrganization(), purchaseOrder.getStore().getCode(), purchaseOrder.getOriginator().getCode(), purchaseOrder.getAttentionTo(), purchaseOrder.getExchangeValue(), purchaseOrder.getExchangeDecimals(), purchaseOrder.getExchangeCurrency(), purchaseOrder.getCurrency(), purchaseOrder.getDueDate().getYear(), purchaseOrder.getDueDate().getMonthValue(), purchaseOrder.getDueDate().getDayOfMonth(), purchaseOrder.getOrderDate().getYear(), purchaseOrder.getOrderDate().getMonthValue(), purchaseOrder.getOrderDate().getDayOfMonth(), purchaseOrder.getOrderDate().getHour(), purchaseOrder.getOrderDate().getMinute(), purchaseOrder.getOrderDate().getSecond(), purchaseOrder.getOrderDate().getNano(), purchaseOrder.getOrderDateTimeZone(), purchaseOrder.getUserDefinedFields().getUdfChar30(), purchaseOrder.getUpdateCount(), purchaseOrder.getUserDefinedFields().getUdfChkBox05(), purchaseOrder.getBuyer().getCode(), purchaseOrder.getEmployee().getCode(), purchaseOrder.getPaymentTerm(), purchaseOrder.getPaymentMethod(), purchaseOrder.getDeliveryAddress(), purchaseOrder.getShipViaCode(), purchaseOrder.getShipViaOrganization(), purchaseOrder.getFobPointCode(), purchaseOrder.getFobPointOrganization(), purchaseOrder.getFreightTermCode(), purchaseOrder.getFreightTermOrganization(), purchaseOrder.getOriginator().getName(), purchaseOrder.getClassCode(), purchaseOrder.getClassOrganization());
                requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());
                return sentPurchaseOrder;
            }
        }
        throw new IllegalStateException("Não foi possível encontrar ordem de compra com status: " + request.getCode());
    }
}
