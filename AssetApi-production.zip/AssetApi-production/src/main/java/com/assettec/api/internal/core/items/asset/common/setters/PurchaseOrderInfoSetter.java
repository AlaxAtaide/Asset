package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class PurchaseOrderInfoSetter {

    private IdSetter idSetter;

    public void setPurchaseOrderInfo(AssetEquipment asset, NodeList childNodes) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("PURCHASEORDERLINEID")) {
                for (int j = 0; j < childNode.getChildNodes().getLength(); j++) {
                    Node childNode2 = childNode.getChildNodes().item(j);

                    if (childNode2.getNodeName().equals("PURCHASEORDERID")) asset.setPurchaseOrder(idSetter.setId(childNode2.getChildNodes()));
                    if (childNode2.getNodeName().equals("PURCHASEORDERLINENUM")) asset.setPurchaseOrderLineNum(childNode2.getTextContent());

                }
            }
        }
    }
}
