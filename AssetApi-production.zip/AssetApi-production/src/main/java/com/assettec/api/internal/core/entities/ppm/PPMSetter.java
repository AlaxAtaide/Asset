package com.assettec.api.internal.core.entities.ppm;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class PPMSetter {

    private CodeSetter codeSetter;

    public PPM setPPM(NodeList childNodes) {
        PPM ppm = new PPM();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("PPMCODE")) ppm.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("PPMREVISION")) ppm.setRevision(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) ppm.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) ppm.setDescription(childNode.getTextContent());

        }

        return ppm;
    }

    public PPM setRoute(NodeList childNodes) {
        PPM ppm = new PPM();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("ROUTECODE")) ppm.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("ROUTEREVISION")) ppm.setRevision(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) ppm.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) ppm.setDescription(childNode.getTextContent());

        }

        return ppm;
    }
}
