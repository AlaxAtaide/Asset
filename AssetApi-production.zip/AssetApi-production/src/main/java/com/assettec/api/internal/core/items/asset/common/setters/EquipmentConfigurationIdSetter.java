package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.items.asset.common.objects.EquipmentConfigurationId;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class EquipmentConfigurationIdSetter {

    private CodeSetter codeSetter;
    private CountSetter countSetter;

    public EquipmentConfigurationId setEquipmentConfigurationId(NodeList childNodes) {
        EquipmentConfigurationId equipmentConfigurationId = new EquipmentConfigurationId("",new InforEamCode("",""),new InforEamCount("","","",""),"");

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().contains("CODE")) equipmentConfigurationId.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) equipmentConfigurationId.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("REVISIONNUM")) equipmentConfigurationId.setRevisionNum(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) equipmentConfigurationId.setDescription(childNode.getTextContent());
        }

        return equipmentConfigurationId;
    }
}
