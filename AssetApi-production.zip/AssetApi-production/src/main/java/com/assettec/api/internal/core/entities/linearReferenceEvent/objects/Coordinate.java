package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Coordinate {
    private InforEamCount x;
    private InforEamCount y;

    public String buildRequest() {
        if (x == null && y == null) return "";
        if (x == null) return "<Y qualifier=\"ACTHRS\">" +
                y.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</Y>";
        if (y == null) return "<X qualifier=\"ACTHRS\">" +
                x.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</X>";
        return "<X qualifier=\"ACTHRS\">" +
                x.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</X>" +
                "<Y qualifier=\"ACTHRS\">" +
                y.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</Y>";
    }
}
