package com.assettec.api.internal.controllers;

import com.assettec.api.internal.core.transactions.Store2StoreService;
import com.assettec.api.internal.core.transactions.StoreToStore;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "core/store2store")
@AllArgsConstructor
public class CoreStore2StoreController {

    private ApiUserService apiUserService;
    private Store2StoreService store2StoreService;

    @GetMapping
    public List<StoreToStore> getStore2StoreTransaction(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return store2StoreService.getStore2StoreTransactions(apiUser);
    }

}
