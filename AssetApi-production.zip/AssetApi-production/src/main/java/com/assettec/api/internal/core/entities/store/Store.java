package com.assettec.api.internal.core.entities.store;

import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Store {
    private String code;
    private String organization;
    private String description;
    private String type;
    private String autoApproveCode;

    private UserDefinedFields userDefinedFields;
    private UserDefinedArea userDefinedArea;

    private int updatedCount;
}
