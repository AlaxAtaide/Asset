package com.assettec.api.mobile.services;

import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.mobile.objects.assets.MobileAsset;
import com.assettec.api.mobile.objects.assets.MobileAssetList;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class MobileAssetService {

    private final Logger logger = LoggerFactory.getLogger(MobileAssetService.class);
    private GridService gridService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;

    @SneakyThrows
    public MobileAssetList getAssets(ApiUser apiUser, int position) {
        logger.info("[MobileAssetService][ Retrieving Assets Grid Data ]");
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "OSOBJA", "OSOBJA", 100, position);
        response = requestSender.sendPostRequest(postRequest, host);
        List<Row> rows = gridService.getRows(response);

        List<MobileAsset> assetList = new ArrayList<>();

        for (Row row : rows) {
            MobileAsset asset = new MobileAsset(Integer.parseInt(row.getId()),
                    row.getDataByName("equipmentno"),
                    row.getDataByName("organization"),
                    row.getDataByName("equipmentdesc"),
                    row.getDataByName("assetstatus"),
                    row.getDataByName("department"));

            assetList.add(asset);

        }
        logger.info("[MobileAssetService][ Returning Assets Grid Data ]");
        return new MobileAssetList(gridService.getRecords(response),assetList);
    }


    @SneakyThrows
    public MobileAssetList getPositions(ApiUser apiUser, int position) {
        logger.info("[MobileAssetService][ retrieving assets grid data ]");
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "OSOBJP", "OSOBJP",100, position);
        response = requestSender.sendPostRequest(postRequest, host);
        List<Row> rows = gridService.getRows(response);

        List<MobileAsset> assetList = new ArrayList<>();

        for (Row row : rows) {
            MobileAsset asset = new MobileAsset(Integer.parseInt(row.getId()),
                    row.getDataByName("equipmentno"),
                    row.getDataByName("organization"),
                    row.getDataByName("equipmentdesc"),
                    row.getDataByName("assetstatus"),
                    row.getDataByName("department"));

            assetList.add(asset);
        }
        return new MobileAssetList(gridService.getRecords(response),assetList);
    }

    @SneakyThrows
    public MobileAssetList getSystems(ApiUser apiUser, int position) {
        logger.info("[MobileAssetService][ retrieving assets grid data ]");
        String postRequest, response, host = XMLParser.getInforHost();

        List<MobileAsset> assetList = new ArrayList<>();

        postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "OSOBJS", "OSOBJS",100, position);
        response = requestSender.sendPostRequest(postRequest, host);
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            MobileAsset asset = new MobileAsset(Integer.parseInt(row.getId()),
                    row.getDataByName("equipmentno"),
                    row.getDataByName("organization"),
                    row.getDataByName("equipmentdesc"),
                    row.getDataByName("assetstatus"),
                    row.getDataByName("department"));

            assetList.add(asset);
        }

        logger.info("[MobileAssetService][ returning assets grid data ]");
        return new MobileAssetList(gridService.getRecords(response),assetList);
    }
}
