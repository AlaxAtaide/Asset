package com.assettec.api.internal.core.issueReturnLines;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class IssueReturnRequest {
    private String transactionOrganization;
    private String serviceOrderCode;
    private String serviceOrderOrganization;
    private String activityCode;
    private String storeCode;
    private String storeOrganization;
    private String departmentCode;
    private String departmentOrganization;
    private String issueTo;

    private List<IssueReturnLine> issueReturnLines;
}
