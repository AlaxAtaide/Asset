package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import com.assettec.api.internal.core.items.asset.common.objects.Dormant;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class DormantSetter {

    private DateSetter dateSetter;

    public void setDormant(AssetEquipment asset, NodeList childNodes) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("DORMANTSTART")) asset.setDormantStart(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DORMANTEND")) asset.setDormantEnd(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DORMANTREUSE")) asset.setDormantReuse(childNode.getTextContent());
        }
    }

    public Dormant setDormant(NodeList childNodes) {
        Dormant dormant = new Dormant();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("DORMANTSTART")) dormant.setStart(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DORMANTEND")) dormant.setEnd(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DORMANTREUSE")) dormant.setReUse(childNode.getTextContent());
        }

        return dormant;
    }
}
