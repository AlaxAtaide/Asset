package com.assettec.api.integration.IG.controllers.orders.purchase;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGPurchaseOrder {
    private String code;
    private String organization;
    private String description;
    private LocalDateTime createdDate;
    private LocalDateTime dueDate;
    private String originator;
    private String supplierCode;
    private String storeCode;
    private String paymentTerm;
    private String paymentMethod;

    private String status;

    private List<IGPurchaseOrderLine> purchaseOrderLines;
}
