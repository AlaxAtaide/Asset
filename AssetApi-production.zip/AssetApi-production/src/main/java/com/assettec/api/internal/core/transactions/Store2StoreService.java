package com.assettec.api.internal.core.transactions;

import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class Store2StoreService {

    private Store2StoreUpdater store2StoreUpdater;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;
    private XMLParser xmlParser;

    @SneakyThrows
    public StoreToStore getStore2StoreReceipt(ApiUser apiUser, String transactionCode) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getStoreTransactionsRequestBuilder().getStoreToStoreReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), transactionCode, "*");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        Node resultData = xmlData.getElementsByTagName("ResultData").item(0);
        return store2StoreUpdater.setStore2StoreTransaction(resultData.getChildNodes());
    }

    @SneakyThrows
    public StoreToStore getStore2StoreIssue(ApiUser apiUser, String transactionCode) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getStoreTransactionsRequestBuilder().getStoreToStoreIssue(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), transactionCode, "*");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        Node resultData = xmlData.getElementsByTagName("ResultData").item(0);
        return store2StoreUpdater.setStore2StoreTransaction(resultData.getChildNodes());
    }

    @SneakyThrows
    public List<Store2StorePart> getStore2StoreParts(ApiUser apiUser, StoreToStore storeToStore) {
        String host = XMLParser.getInforHost();

        int lineNum = 1;
        String postRequest = requestBuilder.getStoreTransactionsRequestBuilder().getStoreToStoreReceiptPart(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), storeToStore.getTransactionId().getCode(), "*", lineNum);
        String response = requestSender.sendPostRequest(postRequest, host);

        List<Store2StorePart> store2storeParts = new ArrayList<>();
        while (!Objects.equals(response, "Unable to locate registry")) {
            if (response.equals("missing toBin field") && !storeToStore.getTransactionStatus().getCode().equals("C"))
                throw new IllegalStateException("Unable to read part from transaction: " + storeToStore.getTransactionId().getCode() + ", cause: part with line: " + lineNum + " does not contain to bin field value. Needs manual intervention.");
            else if (!response.equals("missing toBin field")) {
                Document xmlData = xmlParser.toDocument(response);
                Store2StorePart store2StorePart = store2StoreUpdater.setStore2StorePart(xmlData, new Store2StorePart(), apiUser);
                store2storeParts.add(store2StorePart);
            }
            lineNum += 1;
            postRequest = requestBuilder.getStoreTransactionsRequestBuilder().getStoreToStoreReceiptPart(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), storeToStore.getTransactionId().getCode(), "*", lineNum);
            response = requestSender.sendPostRequest(postRequest, host);
        }
        return store2storeParts;
    }

    @SneakyThrows
    public Store2StorePart getStoreIssuePart(ApiUser apiUser, String transactionCode, String lineNum) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getStoreTransactionsRequestBuilder().getStoreToStoreIssuePart(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), transactionCode, "*", Integer.parseInt(lineNum) / 10);
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        return store2StoreUpdater.setStore2StorePart(xmlData, new Store2StorePart(), apiUser);
    }

    @SneakyThrows
    public List<StoreToStore> getStore2StoreTransactions(ApiUser apiUser) {
        String postRequest, response, host = XMLParser.getInforHost();
        List<StoreToStore> storeToStoreList = new ArrayList<>();

        postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "SSSTSR", "SSSTSR");
        response = requestSender.sendPostRequest(postRequest, host);

        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String transactionCode = gridService.getDataByName("transactioncode", row);
            StoreToStore store2store = getStore2StoreReceipt(apiUser, transactionCode);
            storeToStoreList.add(store2store);

            postRequest = requestBuilder.getStoreTransactionsRequestBuilder().putStoreToStoreReceipt(apiUser,store2store);
            requestSender.sendPostRequest(postRequest,host);
        }

        return storeToStoreList;
    }
}
