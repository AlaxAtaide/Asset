package com.assettec.api.integration.IG.transactions.system;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGAssetSystemSendGetRequest {
    private String systemCode;
    private String oldOrganization;
    private String newOrganization;
    private String systemDescription;
    private String systemType;
    private String systemStatus;
    private String systemDepartment;
    private double systemValue;
    private String systemSerialNumber;
    private String systemModel;
    private String systemState;
    private LocalDateTime purchaseDate;
    private double purchaseCost;
    private String codeIGERP;
    private String codeIGPAT;
    private String codeBEMIG;
    private String sent;
}
