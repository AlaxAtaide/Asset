package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductionMobile {
    private String productionRequest;
    private String productionRequestRevision;
    private String productionOrder;
    private String productionPriority;
    private String productionPriorityDescription;
    private String productionStartDate;
    private String productionEndDate;
    private String accountingEntity;

    public static ProductionMobile createEmpty() {
        return new ProductionMobile("", "", "", "", "", "", "", "");
    }
}
