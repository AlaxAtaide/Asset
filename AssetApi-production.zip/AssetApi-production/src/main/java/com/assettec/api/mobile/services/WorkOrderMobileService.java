package com.assettec.api.mobile.services;

import com.assettec.api.internal.core.entities.department.Department;
import com.assettec.api.internal.core.grid.DataSpy;
import com.assettec.api.internal.core.grid.Field;
import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.internal.core.orders.workorder.WorkOrderService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.mobile.labels.WorkOrderDetailsLabelsSetter;
import com.assettec.api.mobile.objects.departments.DepartmentList;
import com.assettec.api.mobile.objects.grid.GridData;
import com.assettec.api.mobile.objects.grid.GridWorkOrder;
import com.assettec.api.mobile.objects.organizations.Organization;
import com.assettec.api.mobile.objects.organizations.OrganizationList;
import com.assettec.api.mobile.objects.types.Type;
import com.assettec.api.mobile.objects.types.TypeList;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import com.assettec.api.mobile.orders.utilities.WorkOrderDetailsSetter;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class WorkOrderMobileService {

    private WorkOrderDetailsSetter workOrderDetailsSetter;
    private WorkOrderService workOrderService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;
    private XMLParser xmlParser;
    private WorkOrderDetailsLabelsSetter workOrderDetailsLabelsSetter;
    private final Logger logger = LoggerFactory.getLogger(WorkOrderMobileService.class);

    @SneakyThrows
    public GridData getGridWorkOrderData(ApiUser apiUser, String dataSpy) {
        logger.info("[WorkOrderMobileService][ retrieving workOrderGrid data ]");
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getGridRequestBuilder().buildDataSpyGridRequest(apiUser, "WSJOBS", "WSJOBS", dataSpy);
        response = requestSender.sendPostRequest(postRequest, host);
        List<Row> rows = gridService.getRows(response);

        int i = 0;
        List<GridWorkOrder> workOrderList = new ArrayList<>();
        for (Row row : rows) {

            GridWorkOrder workOrder = new GridWorkOrder();
            workOrder.setId(i);

            workOrder.setEquipment(row.getDataByName("equipment"));
            workOrder.setDepartment(row.getDataByName("department"));
            workOrder.setWorkOrderClass(row.getDataByName("woclass"));
            workOrder.setWorkOrderStatusDescription(row.getDataByName("workorderstatus_display"));
            workOrder.setScheduledStartDate(row.getDataByName("schedstartdate"));
            workOrder.setReportedBy(row.getDataByName("reportedby"));
            workOrder.setOrganization(row.getDataByName("organization"));
            workOrder.setWorkOrderCode(row.getDataByName("workordernum"));
            workOrder.setDescription(row.getDataByName("description"));
            workOrder.setDueDate(row.getDataByName("duedate"));
            workOrder.setWorkOrderStatus(row.getDataByName("workorderstatus"));
            workOrder.setWorkOrderType(row.getDataByName("workorderrtype"));
            workOrder.setUpdatedCount(row.getDataByName("recordid"));
            workOrder.setEquipmentSystemType(row.getDataByName("equipsystype"));
            workOrder.setRelatedFromReference(row.getDataByName("relatedfromreference"));
            workOrder.setRelatedToReference(row.getDataByName("relatedtoreference"));
            workOrder.setReasonForRepair(row.getDataByName("reasonforrepair"));
            workOrder.setWorkAccomplished(row.getDataByName("workaccomplished"));
            workOrder.setTechnicalPartFailure(row.getDataByName("techpartfailure"));
            workOrder.setManufacturer(row.getDataByName("manufacturer"));
            workOrder.setSystemLevel(row.getDataByName("syslevel"));
            workOrder.setAssemblyLevel(row.getDataByName("asslevel"));
            workOrder.setComponentLevel(row.getDataByName("complevel"));
            workOrder.setComponentLocation(row.getDataByName("componentlocation"));

            workOrderList.add(workOrder);
            i++;
        }

        logger.info("[WorkOrderMobileService][ returning workOrderGrid data ]");
        return new GridData(gridService.getCurrentDataSpy(response), workOrderList);
    }

    @SneakyThrows
    public WorkOrderDetails getGridWorkOrderDetails(ApiUser apiUser, String workOrderCode, String organization) {
        WorkOrder workOrder = workOrderService.getWorkOrder(apiUser, workOrderCode, organization);

        return workOrderDetailsSetter.getWorkOrderDetails(workOrder);
    }

    public List<WorkOrderDetails> testEnvironment(ApiUser apiUser) {
        GridData gridData = getGridWorkOrderData(apiUser, "");
        List<WorkOrderDetails> workOrderList = new ArrayList<>();

        for (GridWorkOrder gridWorkOrder : gridData.getWorkOrderList()) {
            WorkOrderDetails workOrder = getGridWorkOrderDetails(apiUser, gridWorkOrder.getWorkOrderCode(), gridWorkOrder.getOrganization());
            workOrderList.add(workOrder);
        }

        return workOrderList;
    }

    @SneakyThrows
    public WorkOrderDetails getLabels(ApiUser apiUser) {
        logger.info("[WorkOrderMobileService][ retrieving labels ]");

        String postRequest = requestBuilder.getGridRequestBuilder().buildDataSpyGridRequestLimited(apiUser, "WSJOBS", "WSJOBS", "", 0);
        String response = requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());

        WorkOrderDetails workOrderDetailsLabels = WorkOrderDetails.createEmpty();
        List<Field> fieldList = gridService.getFieldList(response);

        for (Field field : fieldList) {
            workOrderDetailsLabelsSetter.setLabels(field, workOrderDetailsLabels);
        }

        logger.info("[WorkOrderMobileService][ labels retrieved ]");
        return workOrderDetailsLabels;
    }

    @SneakyThrows
    public List<DataSpy> getDataSpies(ApiUser apiUser) {
        logger.info("[WorkOrderMobileService][ retrieving DataSpies ]");

        String postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "WSJOBS", "WSJOBS", 0);
        String response = requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());

        List<DataSpy> dataSpiesList = gridService.getDataSpies(response);
        logger.info("[WorkOrderMobileService][ DataSpies retrieved ]");
        return dataSpiesList;
    }

    @SneakyThrows
    public OrganizationList getOrganizations(ApiUser apiUser, int position) {
        logger.info("[WorkOrderMobileService][ retrieving Organizations ]");

        String postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "LVORG", "WSJOBS", 100, position);
        String response = requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());

        List<Row> rows = gridService.getRows(response);
        List<Organization> organizations = new ArrayList<>();

        for (Row row : rows) {
            Organization organization = new Organization(Integer.parseInt(row.getId()), row.getDataByName("organization"));
            organizations.add(organization);
        }

        logger.info("[WorkOrderMobileService][ Organizations retrieved ]");
        return new OrganizationList(gridService.getRecords(response), organizations);
    }

    @SneakyThrows
    public DepartmentList getDepartments(ApiUser apiUser, int position) {
        logger.info("[WorkOrderMobileService][ retrieving Departments ]");

        String postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "BSDEPT", "BSDEPT", 100, position);
        String response = requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());

        List<Row> rows = gridService.getRows(response);
        List<Department> departments = new ArrayList<>();

        for (Row row : rows) {
            Department department = new Department(Integer.parseInt(row.getId()), row.getDataByName("departmentcode"), row.getDataByName("departmentorganization"), row.getDataByName("departmentdescription"));
            departments.add(department);
        }

        logger.info("[WorkOrderMobileService][ Departments retrieved ]");
        return new DepartmentList(gridService.getRecords(response), departments);
    }

    @SneakyThrows
    public TypeList getTypes(ApiUser apiUser, String userGroup) {
        logger.info("[WorkOrderMobileService][ retrieving Types ]");

        String postRequest = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "WUTEST", "WUTEST");
        String response = requestSender.sendPostRequest(postRequest, XMLParser.getInforHost());

        String typeAuthPostRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "WUJBTA", "WUJBTA", "jta_group", userGroup, "=");
        String typeAuthResponse = requestSender.sendPostRequest(typeAuthPostRequest, XMLParser.getInforHost());

        List<Row> rows = gridService.getRows(response);
        List<Row> typeAuthRows = gridService.getRows(typeAuthResponse);
        List<Type> types = new ArrayList<>();

        for (Row row : rows) {
            Type type = new Type();
            type.setId(Integer.parseInt(row.getId()));
            type.setCode(row.getDataByName("uco_code"));
            type.setDescription(row.getDataByName("uco_desc"));
            type.setNotUsed(row.getDataByName("uco_notused").equals("1"));
            type.setSystemCode(row.getDataByName("uco_system").equals("+"));
            List<String> statusList = new ArrayList<>();
            for (Row typeAuthRow : typeAuthRows) {
                if (typeAuthRow.getDataByName("jta_jobtype").equals(type.getCode())) {
                    type.setUserGroup(typeAuthRow.getDataByName("jta_group"));
                    statusList.add(typeAuthRow.getDataByName("jta_status"));
                }
            }
            type.setStatus(statusList);
            if (statusList.size() != 0) types.add(type);
        }

        logger.info("[WorkOrderMobileService][ Types retrieved ]");
        return new TypeList(gridService.getRecords(response), gridService.getRecords(typeAuthResponse), types);
    }

    public String putMobileWorkOrder(ApiUser apiUser, WorkOrderDetails workOrderDetails) {
        WorkOrder workOrder = workOrderService.getWorkOrder(apiUser, workOrderDetails.getCode(), workOrderDetails.getOrganization());

        workOrder.getStatus().setCode(workOrderDetails.getStatusCode());
        workOrder.getStatus().setDescription(workOrderDetails.getStatusDescription());

        return workOrderService.putWorkOrder(apiUser, workOrder);
    }
}
