package com.assettec.api.internal.core.receipt;

import com.assettec.api.internal.core.entities.classId.ClassId;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrder;
import com.assettec.api.internal.core.receipt.packingSlip.PackingSlip;
import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class POReceipt {
    private Long id;

    private String code;
    private String organization;
    private String description;
    private String status;

    private PurchaseOrder purchaseOrder;
    private ClassId classId;

    private String receivedBy;
    private String orderTermCode;
    private String orderTermOrganization;
    private String departmentCode;
    private String departmentOrganization;
    private String dockLocation;
    private String freight;
    private String reference;
    private int numberOfReceiptLines;
    private String packSlip;

    private UserDefinedFields userDefinedFields;
    private UserDefinedArea userDefinedArea;

    private LocalDateTime dateReceived;
    private String dateReceivedTimeZone;
    private LocalDateTime dateUpdated;
    private String dateUpdatedTimeZone;

    private List<PackingSlip> packingSlips;

    private String company;
    private int updateCount;
}
