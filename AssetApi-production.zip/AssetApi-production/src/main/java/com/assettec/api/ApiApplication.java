package com.assettec.api;

import com.assettec.api.internal.users.ApiUserRepository;
import com.assettec.api.internal.utilities.common.XMLParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class ApiApplication{

	private static ConfigurableApplicationContext context;
	private final static Logger logger = LoggerFactory.getLogger(ApiApplication.class);

	public static void main(String[] args) {
		context = SpringApplication.run(ApiApplication.class, args);
		ApiUserRepository.checkIfFileExists();
		XMLParser.getInforHost();
	}

	public static void restart() {
		logger.info("[ApiApplication][ Spring boot restarting: CIAO ]");
		ApplicationArguments args = context.getBean(ApplicationArguments.class);

		Thread thread = new Thread(() -> {
			context.close();
			context = SpringApplication.run(ApiApplication.class, args.getSourceArgs());
		});

		thread.setDaemon(false);
		thread.start();
	}

}

