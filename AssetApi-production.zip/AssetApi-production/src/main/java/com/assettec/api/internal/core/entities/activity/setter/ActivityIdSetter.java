package com.assettec.api.internal.core.entities.activity.setter;

import com.assettec.api.internal.core.entities.activity.ActivityId;
import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ActivityIdSetter {

    private IdSetter idSetter;

    public ActivityId setActivityId(NodeList childNodes) {
        ActivityId activityId = new ActivityId();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("WORKORDERID")) activityId.setWorkOrderId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ACTIVITYCODE")) activityId.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("ACTIVITYNOTE")) activityId.setNote(childNode.getTextContent());

        }

        return activityId;
    }
}
