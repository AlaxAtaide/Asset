package com.assettec.api.mobile.labels;

import com.assettec.api.internal.core.grid.Field;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class UserDefinedFieldsLabelsSetter {


    public void setLabels(Field field, WorkOrderDetails workOrderDetailsLabels) {
        if (field.getName().equals("udfchar01")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar01(field.getLabel());
        if (field.getName().equals("udfchar02")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar02(field.getLabel());
        if (field.getName().equals("udfchar03")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar03(field.getLabel());
        if (field.getName().equals("udfchar04")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar04(field.getLabel());
        if (field.getName().equals("udfchar05")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar05(field.getLabel());
        if (field.getName().equals("udfchar06")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar06(field.getLabel());
        if (field.getName().equals("udfchar07")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar07(field.getLabel());
        if (field.getName().equals("udfchar08")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar08(field.getLabel());
        if (field.getName().equals("udfchar09")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar09(field.getLabel());
        if (field.getName().equals("udfchar10")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar10(field.getLabel());
        if (field.getName().equals("udfchar11")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar11(field.getLabel());
        if (field.getName().equals("udfchar12")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar12(field.getLabel());
        if (field.getName().equals("udfchar13")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar13(field.getLabel());
        if (field.getName().equals("udfchar14")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar14(field.getLabel());
        if (field.getName().equals("udfchar15")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar15(field.getLabel());
        if (field.getName().equals("udfchar16")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar16(field.getLabel());
        if (field.getName().equals("udfchar17")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar17(field.getLabel());
        if (field.getName().equals("udfchar18")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar18(field.getLabel());
        if (field.getName().equals("udfchar19")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar19(field.getLabel());
        if (field.getName().equals("udfchar20")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar20(field.getLabel());
        if (field.getName().equals("udfchar21")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar21(field.getLabel());
        if (field.getName().equals("udfchar22")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar22(field.getLabel());
        if (field.getName().equals("udfchar23")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar23(field.getLabel());
        if (field.getName().equals("udfchar24")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar24(field.getLabel());
        if (field.getName().equals("udfchar25")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar25(field.getLabel());
        if (field.getName().equals("udfchar26")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar26(field.getLabel());
        if (field.getName().equals("udfchar27")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar27(field.getLabel());
        if (field.getName().equals("udfchar28")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar28(field.getLabel());
        if (field.getName().equals("udfchar29")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar29(field.getLabel());
        if (field.getName().equals("udfchar30")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar30(field.getLabel());
        if (field.getName().equals("udfchar30")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar30(field.getLabel());
        if (field.getName().equals("udfchar31")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar31(field.getLabel());
        if (field.getName().equals("udfchar32")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar32(field.getLabel());
        if (field.getName().equals("udfchar33")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar33(field.getLabel());
        if (field.getName().equals("udfchar34")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar34(field.getLabel());
        if (field.getName().equals("udfchar35")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar35(field.getLabel());
        if (field.getName().equals("udfchar36")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar36(field.getLabel());
        if (field.getName().equals("udfchar37")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar37(field.getLabel());
        if (field.getName().equals("udfchar38")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar38(field.getLabel());
        if (field.getName().equals("udfchar39")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar39(field.getLabel());
        if (field.getName().equals("udfchar40")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar40(field.getLabel());
        if (field.getName().equals("udfchar41")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar41(field.getLabel());
        if (field.getName().equals("udfchar42")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar42(field.getLabel());
        if (field.getName().equals("udfchar43")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar43(field.getLabel());
        if (field.getName().equals("udfchar44")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar44(field.getLabel());
        if (field.getName().equals("udfchar45")) workOrderDetailsLabels.getUserDefinedFields().setUdfChar45(field.getLabel());

        if (field.getName().equals("udfchkbox01")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox01(field.getLabel());
        if (field.getName().equals("udfchkbox02")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox02(field.getLabel());
        if (field.getName().equals("udfchkbox03")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox03(field.getLabel());
        if (field.getName().equals("udfchkbox04")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox04(field.getLabel());
        if (field.getName().equals("udfchkbox05")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox05(field.getLabel());
        if (field.getName().equals("udfchkbox06")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox06(field.getLabel());
        if (field.getName().equals("udfchkbox07")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox07(field.getLabel());
        if (field.getName().equals("udfchkbox08")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox08(field.getLabel());
        if (field.getName().equals("udfchkbox09")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox09(field.getLabel());
        if (field.getName().equals("udfchkbox10")) workOrderDetailsLabels.getUserDefinedFields().setUdfChkBox10(field.getLabel());

        if (field.getName().equals("udfdate01")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate1(field.getLabel());
        if (field.getName().equals("udfdate02")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate2(field.getLabel());
        if (field.getName().equals("udfdate03")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate3(field.getLabel());
        if (field.getName().equals("udfdate04")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate4(field.getLabel());
        if (field.getName().equals("udfdate05")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate5(field.getLabel());
        if (field.getName().equals("udfdate06")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate6(field.getLabel());
        if (field.getName().equals("udfdate07")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate7(field.getLabel());
        if (field.getName().equals("udfdate08")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate8(field.getLabel());
        if (field.getName().equals("udfdate09")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate9(field.getLabel());
        if (field.getName().equals("udfdate10")) workOrderDetailsLabels.getUserDefinedFields().setUdfDate10(field.getLabel());

        if (field.getName().equals("udfnum01")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum1(field.getLabel());
        if (field.getName().equals("udfnum02")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum2(field.getLabel());
        if (field.getName().equals("udfnum03")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum3(field.getLabel());
        if (field.getName().equals("udfnum04")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum4(field.getLabel());
        if (field.getName().equals("udfnum05")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum5(field.getLabel());
        if (field.getName().equals("udfnum06")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum6(field.getLabel());
        if (field.getName().equals("udfnum07")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum7(field.getLabel());
        if (field.getName().equals("udfnum08")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum8(field.getLabel());
        if (field.getName().equals("udfnum09")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum9(field.getLabel());
        if (field.getName().equals("udfnum10")) workOrderDetailsLabels.getUserDefinedFields().setUdfNum10(field.getLabel());

        if (field.getName().equals("udfnote01")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote01(field.getLabel());
        if (field.getName().equals("udfnote02")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote02(field.getLabel());
        if (field.getName().equals("udfnote03")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote03(field.getLabel());
        if (field.getName().equals("udfnote04")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote04(field.getLabel());
        if (field.getName().equals("udfnote05")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote05(field.getLabel());
        if (field.getName().equals("udfnote06")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote06(field.getLabel());
        if (field.getName().equals("udfnote07")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote07(field.getLabel());
        if (field.getName().equals("udfnote08")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote08(field.getLabel());
        if (field.getName().equals("udfnote09")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote09(field.getLabel());
        if (field.getName().equals("udfnote10")) workOrderDetailsLabels.getUserDefinedFields().setUdfNote10(field.getLabel());
    }
}
