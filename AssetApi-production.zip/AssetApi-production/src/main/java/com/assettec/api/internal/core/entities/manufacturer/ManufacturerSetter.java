package com.assettec.api.internal.core.entities.manufacturer;

import com.assettec.api.internal.core.user.info.area.UserDefinedAreaSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

@Service
@AllArgsConstructor
public class ManufacturerSetter {

    private UserDefinedAreaSetter userDefinedAreaSetter;

    public Manufacturer setManufacturer(Document xmlData, Manufacturer manufacturer) {

        manufacturer.setCode(xmlData.getElementsByTagName("MANUFACTURERID").item(0).getFirstChild().getTextContent());
        manufacturer.setOrganization(xmlData.getElementsByTagName("MANUFACTURERID").item(0).getChildNodes().item(1).getFirstChild().getTextContent());
        manufacturer.setDescription(xmlData.getElementsByTagName("MANUFACTURERID").item(0).getLastChild().getTextContent());
        manufacturer.setUpdatedCount(Integer.parseInt(xmlData.getElementsByTagName("Manufacturer").item(0).getAttributes().getNamedItem("recordid").getTextContent()));

        NodeList parentNode = xmlData.getElementsByTagName("USERDEFINEDAREA");
        NodeList childNodes = parentNode.getLength() != 0 ? parentNode.item(0).getChildNodes() : parentNode;

        manufacturer.setUserDefinedArea(userDefinedAreaSetter.setUserDefinedArea(childNodes));
        return manufacturer;
    }
}
