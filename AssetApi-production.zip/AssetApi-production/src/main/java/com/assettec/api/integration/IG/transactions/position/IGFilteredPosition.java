package com.assettec.api.integration.IG.transactions.position;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGFilteredPosition {
    private String positionCode;
    private String positionStatus;
    private String positionDepartment;
    private String positionOrganization;
}
