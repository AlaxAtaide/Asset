package com.assettec.api.internal.controllers;

import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.internal.users.AppUser;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "core/user")
@AllArgsConstructor
public class CoreUsersController {

    private ApiUserService apiUserService;
    @Operation(summary = "Get Registered User Information By Token")
    @GetMapping
    public AppUser getUserInfo(@Parameter(description = "API User Token", example = "917a008a-c5ed-4c03-8aac-df572db06d04") @RequestParam(name = "token") String token) {
        return apiUserService.findByToken(token).toAppUser();
    }
    @Operation(summary = "Registers User")
    @PostMapping
    public AppUser createUser(@Parameter(description = "API Base Token", example = "aa937bc76_uo8703bn31_act038741yj") @RequestParam(name = "token") String ignoredToken, @RequestBody AppUser appUser) {
        return apiUserService.createUser(appUser).toAppUser();
    }

    @Operation(summary = "Updates Registered User Information")
    @PutMapping
    public AppUser updateUser(@Parameter(description = "API User Token", example = "917a008a-c5ed-4c03-8aac-df572db06d04") @RequestParam(name = "token") String token, @RequestBody AppUser appUser) {
        return apiUserService.updateUser(token, appUser).toAppUser();
    }
}
