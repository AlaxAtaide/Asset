package com.assettec.api.integration.IG.controllers.part;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class IGPartRegistrationRequest {

    private String http;
    private String message;

    private String partCode;
    private String partDescription;
    private String partOrganization;
    private String unitOfMetric;
    private String model;
    private String trackMethod;
    private String departmentCode;
    private String codeIGERP;
}
