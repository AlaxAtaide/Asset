package com.assettec.api.internal.core.transactions;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamDate;
import com.assettec.api.internal.core.entities.employee.Employee;
import com.assettec.api.internal.core.entities.store.Store;
import com.assettec.api.internal.core.requisitions.Requisition;
import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class StoreToStore {
    private Id transactionId;
    private InforEamCode transactionStatus;
    private Id fromStoreId;
    private Id toStoreId;
    private Id classId;
    private Id requisitionId;
    private String advice;

    private InforEamCode approver;
    private InforEamDate transactionDate;

    private UserDefinedArea userDefinedArea;
    private UserDefinedFields userDefinedFields;

    private List<Store2StorePart> store2StoreParts;

    private String partLineCount;
    private String updatedCount;
}
