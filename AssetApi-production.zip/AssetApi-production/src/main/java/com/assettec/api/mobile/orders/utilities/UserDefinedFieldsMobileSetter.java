package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.UserDefinedFieldsMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class UserDefinedFieldsMobileSetter {
    public void setUserDefinedFields(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        UserDefinedFieldsMobile userDefinedFields = new UserDefinedFieldsMobile();

        userDefinedFields.setUdfChar01(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar01() == null ? "" : workOrder.getUserDefinedFields().getUdfChar01());
        userDefinedFields.setUdfChar02(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar02() == null ? "" : workOrder.getUserDefinedFields().getUdfChar02());
        userDefinedFields.setUdfChar03(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar03() == null ? "" : workOrder.getUserDefinedFields().getUdfChar03());
        userDefinedFields.setUdfChar04(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar04() == null ? "" : workOrder.getUserDefinedFields().getUdfChar04());
        userDefinedFields.setUdfChar05(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar05() == null ? "" : workOrder.getUserDefinedFields().getUdfChar05());
        userDefinedFields.setUdfChar06(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar06() == null ? "" : workOrder.getUserDefinedFields().getUdfChar06());
        userDefinedFields.setUdfChar07(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar07() == null ? "" : workOrder.getUserDefinedFields().getUdfChar07());
        userDefinedFields.setUdfChar08(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar08() == null ? "" : workOrder.getUserDefinedFields().getUdfChar08());
        userDefinedFields.setUdfChar09(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar09() == null ? "" : workOrder.getUserDefinedFields().getUdfChar09());
        userDefinedFields.setUdfChar10(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar10() == null ? "" : workOrder.getUserDefinedFields().getUdfChar10());
        userDefinedFields.setUdfChar11(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar11() == null ? "" : workOrder.getUserDefinedFields().getUdfChar11());
        userDefinedFields.setUdfChar12(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar12() == null ? "" : workOrder.getUserDefinedFields().getUdfChar12());
        userDefinedFields.setUdfChar13(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar13() == null ? "" : workOrder.getUserDefinedFields().getUdfChar13());
        userDefinedFields.setUdfChar14(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar14() == null ? "" : workOrder.getUserDefinedFields().getUdfChar14());
        userDefinedFields.setUdfChar15(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar15() == null ? "" : workOrder.getUserDefinedFields().getUdfChar15());
        userDefinedFields.setUdfChar16(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar16() == null ? "" : workOrder.getUserDefinedFields().getUdfChar16());
        userDefinedFields.setUdfChar17(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar17() == null ? "" : workOrder.getUserDefinedFields().getUdfChar17());
        userDefinedFields.setUdfChar18(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar18() == null ? "" : workOrder.getUserDefinedFields().getUdfChar18());
        userDefinedFields.setUdfChar19(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar19() == null ? "" : workOrder.getUserDefinedFields().getUdfChar19());
        userDefinedFields.setUdfChar20(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar20() == null ? "" : workOrder.getUserDefinedFields().getUdfChar20());
        userDefinedFields.setUdfChar21(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar21() == null ? "" : workOrder.getUserDefinedFields().getUdfChar21());
        userDefinedFields.setUdfChar22(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar22() == null ? "" : workOrder.getUserDefinedFields().getUdfChar22());
        userDefinedFields.setUdfChar23(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar23() == null ? "" : workOrder.getUserDefinedFields().getUdfChar23());
        userDefinedFields.setUdfChar24(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar24() == null ? "" : workOrder.getUserDefinedFields().getUdfChar24());
        userDefinedFields.setUdfChar25(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar25() == null ? "" : workOrder.getUserDefinedFields().getUdfChar25());
        userDefinedFields.setUdfChar26(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar26() == null ? "" : workOrder.getUserDefinedFields().getUdfChar26());
        userDefinedFields.setUdfChar27(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar27() == null ? "" : workOrder.getUserDefinedFields().getUdfChar27());
        userDefinedFields.setUdfChar28(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar28() == null ? "" : workOrder.getUserDefinedFields().getUdfChar28());
        userDefinedFields.setUdfChar29(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar29() == null ? "" : workOrder.getUserDefinedFields().getUdfChar29());
        userDefinedFields.setUdfChar30(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar30() == null ? "" : workOrder.getUserDefinedFields().getUdfChar30());
        userDefinedFields.setUdfChar31(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar31() == null ? "" : workOrder.getUserDefinedFields().getUdfChar31());
        userDefinedFields.setUdfChar32(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar32() == null ? "" : workOrder.getUserDefinedFields().getUdfChar32());
        userDefinedFields.setUdfChar33(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar33() == null ? "" : workOrder.getUserDefinedFields().getUdfChar33());
        userDefinedFields.setUdfChar34(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar34() == null ? "" : workOrder.getUserDefinedFields().getUdfChar34());
        userDefinedFields.setUdfChar35(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar35() == null ? "" : workOrder.getUserDefinedFields().getUdfChar35());
        userDefinedFields.setUdfChar36(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar36() == null ? "" : workOrder.getUserDefinedFields().getUdfChar36());
        userDefinedFields.setUdfChar37(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar37() == null ? "" : workOrder.getUserDefinedFields().getUdfChar37());
        userDefinedFields.setUdfChar38(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar38() == null ? "" : workOrder.getUserDefinedFields().getUdfChar38());
        userDefinedFields.setUdfChar39(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar39() == null ? "" : workOrder.getUserDefinedFields().getUdfChar39());
        userDefinedFields.setUdfChar40(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar40() == null ? "" : workOrder.getUserDefinedFields().getUdfChar40());
        userDefinedFields.setUdfChar41(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar41() == null ? "" : workOrder.getUserDefinedFields().getUdfChar41());
        userDefinedFields.setUdfChar42(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar42() == null ? "" : workOrder.getUserDefinedFields().getUdfChar42());
        userDefinedFields.setUdfChar43(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar43() == null ? "" : workOrder.getUserDefinedFields().getUdfChar43());
        userDefinedFields.setUdfChar44(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar44() == null ? "" : workOrder.getUserDefinedFields().getUdfChar44());
        userDefinedFields.setUdfChar45(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChar45() == null ? "" : workOrder.getUserDefinedFields().getUdfChar45());

        userDefinedFields.setUdfNum1(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum1() == null ? "" : workOrder.getUserDefinedFields().getUdfNum1().toString());
        userDefinedFields.setUdfNum2(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum2() == null ? "" : workOrder.getUserDefinedFields().getUdfNum2().toString());
        userDefinedFields.setUdfNum3(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum3() == null ? "" : workOrder.getUserDefinedFields().getUdfNum3().toString());
        userDefinedFields.setUdfNum4(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum4() == null ? "" : workOrder.getUserDefinedFields().getUdfNum4().toString());
        userDefinedFields.setUdfNum5(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum5() == null ? "" : workOrder.getUserDefinedFields().getUdfNum5().toString());
        userDefinedFields.setUdfNum6(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum6() == null ? "" : workOrder.getUserDefinedFields().getUdfNum6().toString());
        userDefinedFields.setUdfNum7(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum7() == null ? "" : workOrder.getUserDefinedFields().getUdfNum7().toString());
        userDefinedFields.setUdfNum8(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum8() == null ? "" : workOrder.getUserDefinedFields().getUdfNum8().toString());
        userDefinedFields.setUdfNum9(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum9() == null ? "" : workOrder.getUserDefinedFields().getUdfNum9().toString());
        userDefinedFields.setUdfNum10(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNum10() == null ? "" : workOrder.getUserDefinedFields().getUdfNum10().toString());

        userDefinedFields.setUdfDate1(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate1() == null ? "" : workOrder.getUserDefinedFields().getUdfDate1().toString(true));
        userDefinedFields.setUdfDate2(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate2() == null ? "" : workOrder.getUserDefinedFields().getUdfDate2().toString(true));
        userDefinedFields.setUdfDate3(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate3() == null ? "" : workOrder.getUserDefinedFields().getUdfDate3().toString(true));
        userDefinedFields.setUdfDate4(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate4() == null ? "" : workOrder.getUserDefinedFields().getUdfDate4().toString(true));
        userDefinedFields.setUdfDate5(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate5() == null ? "" : workOrder.getUserDefinedFields().getUdfDate5().toString(true));
        userDefinedFields.setUdfDate6(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate6() == null ? "" : workOrder.getUserDefinedFields().getUdfDate6().toString(true));
        userDefinedFields.setUdfDate7(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate7() == null ? "" : workOrder.getUserDefinedFields().getUdfDate7().toString(true));
        userDefinedFields.setUdfDate8(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate8() == null ? "" : workOrder.getUserDefinedFields().getUdfDate8().toString(true));
        userDefinedFields.setUdfDate9(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate9() == null ? "" : workOrder.getUserDefinedFields().getUdfDate9().toString(true));
        userDefinedFields.setUdfDate10(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfDate10() == null ? "" : workOrder.getUserDefinedFields().getUdfDate10().toString(true));

        userDefinedFields.setUdfChkBox01(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox01() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox01());
        userDefinedFields.setUdfChkBox02(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox02() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox02());
        userDefinedFields.setUdfChkBox03(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox03() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox03());
        userDefinedFields.setUdfChkBox04(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox04() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox04());
        userDefinedFields.setUdfChkBox05(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox05() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox05());
        userDefinedFields.setUdfChkBox06(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox06() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox06());
        userDefinedFields.setUdfChkBox07(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox07() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox07());
        userDefinedFields.setUdfChkBox08(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox08() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox08());
        userDefinedFields.setUdfChkBox09(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox09() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox09());
        userDefinedFields.setUdfChkBox10(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfChkBox10() == null ? "" : workOrder.getUserDefinedFields().getUdfChkBox10());

        userDefinedFields.setUdfNote01(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote01() == null ? "" : workOrder.getUserDefinedFields().getUdfNote01());
        userDefinedFields.setUdfNote02(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote02() == null ? "" : workOrder.getUserDefinedFields().getUdfNote02());
        userDefinedFields.setUdfNote03(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote03() == null ? "" : workOrder.getUserDefinedFields().getUdfNote03());
        userDefinedFields.setUdfNote04(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote04() == null ? "" : workOrder.getUserDefinedFields().getUdfNote04());
        userDefinedFields.setUdfNote05(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote05() == null ? "" : workOrder.getUserDefinedFields().getUdfNote05());
        userDefinedFields.setUdfNote06(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote06() == null ? "" : workOrder.getUserDefinedFields().getUdfNote06());
        userDefinedFields.setUdfNote07(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote07() == null ? "" : workOrder.getUserDefinedFields().getUdfNote07());
        userDefinedFields.setUdfNote08(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote08() == null ? "" : workOrder.getUserDefinedFields().getUdfNote08());
        userDefinedFields.setUdfNote09(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote09() == null ? "" : workOrder.getUserDefinedFields().getUdfNote09());
        userDefinedFields.setUdfNote10(workOrder.getUserDefinedFields() == null || workOrder.getUserDefinedFields().getUdfNote10() == null ? "" : workOrder.getUserDefinedFields().getUdfNote10());

        workOrderDetails.setUserDefinedFields(userDefinedFields);
    }
}
