package com.assettec.api.mobile.objects.grid;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GridWorkOrder {
    private int id;
    private String workOrderCode;
    private String organization;
    private String description;
    private String workOrderType;
    private String workOrderStatus;
    private String workOrderStatusDescription;
    private String workOrderClass;
    private String department;
    private String scheduledStartDate;
    private String reportedBy;
    private String dueDate;
    private String updatedCount;
    private String equipment;
    private String equipmentSystemType;
    private String equipmentOrganization;
    private String relatedFromReference;
    private String relatedToReference;
    private String reasonForRepair;
    private String workAccomplished;
    private String technicalPartFailure;
    private String manufacturer;
    private String systemLevel;
    private String assemblyLevel;
    private String componentLevel;
    private String componentLocation;
}
