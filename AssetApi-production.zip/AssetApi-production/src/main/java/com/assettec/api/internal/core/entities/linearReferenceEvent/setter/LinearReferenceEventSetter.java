package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class LinearReferenceEventSetter {

    private CountSetter countSetter;
    private CodeSetter codeSetter;
    private OffsetDirectionSetter offsetDirectionSetter;
    private CoordinateSetter coordinateSetter;
    private HorizontalVerticalDetailsSetter horizontalVerticalDetailsSetter;
    private DetailsSetter detailsSetter;

    public LinearReferenceEvent setLinearReferenceEvent(NodeList nodeList) {
        LinearReferenceEvent linearReferenceEvent = new LinearReferenceEvent();

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);

            if (node.getNodeName().equals("FROMPOINT")) linearReferenceEvent.setFromPoint(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("FROMREFDESC")) linearReferenceEvent.setFromReferenceDescription(node.getTextContent());
            if (node.getNodeName().equals("FROMGEOREF")) linearReferenceEvent.setFromGeoReference(node.getTextContent());

            if (node.getNodeName().equals("TOPOINT")) linearReferenceEvent.setToPoint(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("TOREFDESC")) linearReferenceEvent.setToReferenceDescription(node.getTextContent());
            if (node.getNodeName().equals("TOGEOREF")) linearReferenceEvent.setToGeoReference(node.getTextContent());

            if (node.getNodeName().equals("FROMREFERENCEID")) linearReferenceEvent.setFromReferenceId(codeSetter.setCode(node.getChildNodes()));
            if (node.getNodeName().equals("FROMOFFSET")) linearReferenceEvent.setFromOffset(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("FROMOFFSETPERCENTAGE")) linearReferenceEvent.setFromOffsetPercentage(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("FROMOFFSETDIRECTION")) linearReferenceEvent.setFromOffSetDirection(offsetDirectionSetter.setOffsetDirection(node.getChildNodes()));
            if (node.getNodeName().equals("FROMCOORDINATE")) linearReferenceEvent.setFromCoordinate(coordinateSetter.setCoordinate(node.getChildNodes()));
            if (node.getNodeName().equals("FROMLATITUDE")) linearReferenceEvent.setFromLatitude(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("FROMLONGITUDE")) linearReferenceEvent.setFromLongitude(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("FROMHORIZONTALVERTICALDETAILS")) linearReferenceEvent.setFromHorizontalVerticalDetails(horizontalVerticalDetailsSetter.setHorizontalVerticalDetails(node.getChildNodes()));

            if (node.getNodeName().equals("TOREFERENCEID")) linearReferenceEvent.setToReferenceId(codeSetter.setCode(node.getChildNodes()));
            if (node.getNodeName().equals("TOOFFSET")) linearReferenceEvent.setToOffset(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("TOOFFSETPERCENTAGE")) linearReferenceEvent.setToOffsetPercentage(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("TOOFFSETDIRECTION")) linearReferenceEvent.setToOffSetDirection(offsetDirectionSetter.setOffsetDirection(node.getChildNodes()));
            if (node.getNodeName().equals("TOCOORDINATE")) linearReferenceEvent.setToCoordinate(coordinateSetter.setCoordinate(node.getChildNodes()));
            if (node.getNodeName().equals("TOLATITUDE")) linearReferenceEvent.setToLatitude(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("TOLONGITUDE")) linearReferenceEvent.setToLongitude(countSetter.setCount(node.getChildNodes()));
            if (node.getNodeName().equals("TOHORIZONTALVERTICALDETAILS")) linearReferenceEvent.setToHorizontalVerticalDetails(horizontalVerticalDetailsSetter.setHorizontalVerticalDetails(node.getChildNodes()));
            if (node.getNodeName().equals("RELATIONSHIPTYPEID")) linearReferenceEvent.setRelationShipType(codeSetter.setCode(node.getChildNodes()));

            if (node.getNodeName().equals("RELATEDLINEARREFERENCEDETAILS")) linearReferenceEvent.setRelatedLinearReferenceEventDetails(detailsSetter.setDetails(node.getChildNodes()));
        }

        return linearReferenceEvent;
    }
}
