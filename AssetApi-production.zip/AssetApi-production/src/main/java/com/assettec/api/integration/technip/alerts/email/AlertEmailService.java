package com.assettec.api.integration.technip.alerts.email;

import com.assettec.api.internal.core.installationcode.InstallationCode;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.internet.MimeMessage;
import java.time.LocalDateTime;
import java.util.logging.Logger;

@Component
@AllArgsConstructor
public class AlertEmailService {

    private JavaMailSender mailSender;

    @SneakyThrows
    public void send(String to, String email, String subject) {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
        helper.setText(email, true);
        helper.setTo(to);
        helper.setSubject(subject);
        //todo change setFrom
        helper.setFrom("suporte@assettec.com");
        boolean sent = false;
        while (!sent) {
            try {
                mailSender.send(mimeMessage);
                sent = true;
                Thread.sleep(36000);
            } catch (Exception e) {
                e.printStackTrace();
                if (e.getMessage().contains("you are sending too many mails")) {
                    Thread.sleep(50000);
                    sent = true;
                } else if (e.getMessage().contains("Couldn't connect to host")) {
                    Logger.getGlobal().info("Error while sending email, trying again.");
                    sent = false;
                }
            }
        }
    }

    public String buildRedAlertEmail(String workOrderCode, String dueDate, String message) {
        String rawContent = "<body style=\"margin: 0; padding: 0; background: #f00;\">\n" +
                "  <div class=\"container\">\n" +
                "    <table\n" +
                "      align=\"center\"\n" +
                "      border=\"0\"\n" +
                "      cellpadding=\"0\"\n" +
                "      cellspacing=\"0\"\n" +
                "      width=\"650\"\n" +
                "    >\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"#f00\" style=\"padding: 20px 20px 20px 20px\">\n" +
                "          <table bgcolor=\"white\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"padding: 40px 30px 20px 30px\">\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <center>\n" +
                "                  <font face=\"arial\">\n" +
                "                      <h1>\n" +
                "                        Ordem de serviço expirada.\n" +
                "                      </h1>\n" +
                "                  </font>\n" +
                "                </center>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <font face=\"arial\">\n" +
                "                  <center>\n" +
                "                    A ordem de serviço: ${CODE}, expirou em: ${DATE}.\n" +
                "                  </center>\n" +
                "                </font>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "              <tr>\n" +
                "                  <td>\n" +
                "                      <font face=\"arial\">\n" +
                "                        <center style=\"padding: 30px 30px 40px 30px\">\n" +
                "                          ${MESSAGE}\n" +
                "                        </center>\n" +
                "                      </font>\n" +
                "                  </td>\n" +
                "              </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "</body>";
        return rawContent.replace("${CODE}", workOrderCode).replace("${DATE}", dueDate).replace("${MESSAGE}", message);
    }

    public String buildWarningEmail(String workOrderCode, String dueDate, String message) {
        String rawContent = "<body style=\"margin: 0; padding: 0; background: #ff6c00;\">\n" +
                "  <div class=\"container\">\n" +
                "    <table\n" +
                "      align=\"center\"\n" +
                "      border=\"0\"\n" +
                "      cellpadding=\"0\"\n" +
                "      cellspacing=\"0\"\n" +
                "      width=\"650\"\n" +
                "    >\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"#ff6c00\" style=\"padding: 20px 20px 20px 20px\">\n" +
                "          <table bgcolor=\"white\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"padding: 40px 30px 20px 30px\">\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <center>\n" +
                "                  <font face=\"arial\">\n" +
                "                      <h1>\n" +
                "                        Ordem de serviço prestes a expirar.\n" +
                "                      </h1>\n" +
                "                  </font>\n" +
                "                </center>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <font face=\"arial\">\n" +
                "                  <center>\n" +
                "                    A ordem de serviço: ${CODE}, expira em: ${DATE}.\n" +
                "                  </center>\n" +
                "                </font>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "              <tr>\n" +
                "                  <td>\n" +
                "                      <font face=\"arial\">\n" +
                "                        <center style=\"padding: 30px 30px 40px 30px\">\n" +
                "                          ${MESSAGE}\n" +
                "                        </center>\n" +
                "                      </font>\n" +
                "                  </td>\n" +
                "              </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "</body>";
        return rawContent.replace("${CODE}", workOrderCode).replace("${DATE}", dueDate).replace("${MESSAGE}", message);
    }

    public String buildDelayedEmail(String workOrderCode, String dueDate, String message) {
        String rawContent = "<body style=\"margin: 0; padding: 0; background: #000;\">\n" +
                "  <div class=\"container\">\n" +
                "    <table\n" +
                "      bgcolor=\"#b30000\"\n" +
                "      align=\"center\"\n" +
                "      border=\"0\"\n" +
                "      cellpadding=\"0\"\n" +
                "      cellspacing=\"0\"\n" +
                "      width=\"650\">\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"#000\" style=\"padding: 20px 20px 20px 20px\">\n" +
                "          <table bgcolor=\"#b30000\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"padding: 40px 30px 20px 30px\">\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <center>\n" +
                "                  <font face=\"arial\" color=\"white\">\n" +
                "                      <h1>\n" +
                "                        Ordem de serviço atrasada.\n" +
                "                      </h1>\n" +
                "                  </font>\n" +
                "                </center>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "            <tr>\n" +
                "              <td>\n" +
                "                <font face=\"arial\" color=\"white\">\n" +
                "                  <center>\n" +
                "                    A ordem de serviço: ${CODE} devia ter sido fechada em: ${DATE}.\n" +
                "                  </center>\n" +
                "                </font>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "              <tr>\n" +
                "                  <td>\n" +
                "                      <font face=\"arial\" color=\"white\">\n" +
                "                        <center style=\"padding: 30px 30px 40px 30px\">\n" +
                "                          ${MESSAGE}\n" +
                "                        </center>\n" +
                "                      </font>\n" +
                "                  </td>\n" +
                "              </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "</body>";
        return rawContent.replace("${CODE}", workOrderCode).replace("${DATE}", dueDate).replace("${MESSAGE}", message);
    }

    public void sendWarningAlert(String[] userEmails, String workOrderCode, String workOrderDueDateString, InstallationCode installationCode) {
        for (String userEmail : userEmails) {
            userEmail = userEmail.replace(" ", "");
            String warning = buildWarningEmail(workOrderCode, workOrderDueDateString, installationCode.getDescription());
            Logger.getGlobal().info("Sending Warning Alert email at " + LocalDateTime.now());
            send(userEmail, warning, "Ordem de serviço: " + workOrderCode + " está prestes a expirar.");
        }
    }

    public void sendRedAlert(String[] userEmails, String workOrderCode, String workOrderDueDateString, InstallationCode installationCode) {
        for (String userEmail : userEmails) {
            userEmail = userEmail.replace(" ", "");
            String alert = buildRedAlertEmail(workOrderCode, workOrderDueDateString, installationCode.getDescription());
            Logger.getGlobal().info("Sending Red Alert email at " + LocalDateTime.now());
            send(userEmail, alert, "Ordem de serviço: " + workOrderCode + " está expirada.");
        }
    }

    public void sendDelayedAlert(String[] userEmails, String workOrderCode, String workOrderDueDateString, InstallationCode installationCode) {
        for (String userEmail : userEmails) {
            userEmail = userEmail.replace(" ", "");
            String delayed = buildDelayedEmail(workOrderCode, workOrderDueDateString, installationCode.getDescription());
            Logger.getGlobal().info("Sending Delayed Alert email at " + LocalDateTime.now());
            send(userEmail, delayed, "Ordem de serviço: " + workOrderCode + " está atrasada.");
        }
    }
}
