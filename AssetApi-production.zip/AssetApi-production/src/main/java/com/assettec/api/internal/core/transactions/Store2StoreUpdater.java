package com.assettec.api.internal.core.transactions;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.Id.IdLineNum;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.AssetService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.entities.department.Department;
import com.assettec.api.internal.core.entities.manufacturer.ManufacturerService;
import com.assettec.api.internal.core.items.part.Part;
import com.assettec.api.internal.core.items.part.PartService;
import com.assettec.api.internal.core.user.info.area.UserDefinedAreaSetter;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFieldsSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class Store2StoreUpdater {

    private PartService partService;
    private AssetService assetService;
    private ManufacturerService manufacturerService;
    private UserDefinedAreaSetter userDefinedAreaSetter;
    private UserDefinedFieldsSetter userDefinedFieldsSetter;
    private IdSetter idSetter;
    private DateSetter dateSetter;
    private CodeSetter codeSetter;

    public StoreToStore setStore2StoreTransaction(NodeList childNodes) {
        StoreToStore storeToStore = new StoreToStore();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("StoreToStoreReceipt")) {
                for (int j = 0; j < childNode.getChildNodes().getLength(); j++) {
                    Node nonDetailsNode = childNode.getChildNodes().item(j);

                    if (nonDetailsNode.getNodeName().equals("StoreToStoreReceiptDetails")) {
                        storeToStore.setUpdatedCount(nonDetailsNode.getAttributes().getNamedItem("recordid").getTextContent());

                        for (int k = 0; k < nonDetailsNode.getChildNodes().getLength(); k++) {
                            Node detailsNode = nonDetailsNode.getChildNodes().item(k);

                            if (detailsNode.getNodeName().equals("TRANSACTIONID")) storeToStore.setTransactionId(idSetter.setId(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("TRANSACTIONSTATUS")) storeToStore.setTransactionStatus(codeSetter.setCode(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("FROMSTOREID")) storeToStore.setFromStoreId(idSetter.setId(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("TOSTOREID")) storeToStore.setToStoreId(idSetter.setId(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("CLASSID")) storeToStore.setClassId(idSetter.setId(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("REQUISITIONID")) storeToStore.setRequisitionId(idSetter.setId(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("USERDEFINEDAREA")) storeToStore.setUserDefinedArea(userDefinedAreaSetter.setUserDefinedArea(detailsNode.getChildNodes()));
                            if (detailsNode.getNodeName().equals("StandardUserDefinedFields")) storeToStore.setUserDefinedFields(userDefinedFieldsSetter.setUserDefinedFields(detailsNode.getChildNodes()));
                        }
                    }
                    if (nonDetailsNode.getNodeName().equals("APPROVER")) storeToStore.setApprover(codeSetter.setCode(nonDetailsNode.getChildNodes()));
                    if (nonDetailsNode.getNodeName().equals("TRANSACTIONDATE")) storeToStore.setTransactionDate(dateSetter.setDate(nonDetailsNode.getChildNodes()));
                }
            }
            if (childNode.getNodeName().equals("PARTLINECOUNT")) storeToStore.setPartLineCount(childNode.getTextContent());
            if (childNode.getNodeName().equals("StoreToStoreIssue")) {
                storeToStore.setPartLineCount(childNode.getAttributes().getNamedItem("partlinecount").getTextContent());
                storeToStore.setUpdatedCount(childNode.getAttributes().getNamedItem("recordid").getTextContent());

                for (int j = 0; j < childNode.getChildNodes().getLength(); j++) {
                    Node issueNode = childNode.getChildNodes().item(j);

                    if (issueNode.getNodeName().equals("TRANSACTIONID")) storeToStore.setTransactionId(idSetter.setId(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("FROMSTOREID")) storeToStore.setFromStoreId(idSetter.setId(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("TOSTOREID")) storeToStore.setToStoreId(idSetter.setId(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("STATUS")) storeToStore.setTransactionStatus(codeSetter.setCode(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("CLASSID")) storeToStore.setClassId(idSetter.setId(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("REQUISITIONID")) storeToStore.setRequisitionId(idSetter.setId(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("TRANSACTIONDATE")) storeToStore.setTransactionDate(dateSetter.setDate(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("ADVICENUMBER")) storeToStore.setAdvice(issueNode.getTextContent());
                    if (issueNode.getNodeName().equals("APPROVER")) storeToStore.setApprover(codeSetter.setCode(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("USERDEFINEDAREA")) storeToStore.setUserDefinedArea(userDefinedAreaSetter.setUserDefinedArea(issueNode.getChildNodes()));
                    if (issueNode.getNodeName().equals("StandardUserDefinedFields")) storeToStore.setUserDefinedFields(userDefinedFieldsSetter.setUserDefinedFields(issueNode.getChildNodes()));
                }
            }
        }

        return storeToStore;
    }

    public Store2StorePart setStore2StorePart(Document xmlData, Store2StorePart store2StorePart, ApiUser apiUser) {
        store2StorePart.setLineNum(xmlData.getElementsByTagName("TRANSACTIONLINENUM").item(0).getTextContent());

        store2StorePart.setReceiptQuantityValue(xmlData.getElementsByTagName("RECEIPTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("RECEIPTQUANTITY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setReceiptQuantityDecimals(xmlData.getElementsByTagName("RECEIPTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("RECEIPTQUANTITY").item(0).getChildNodes().item(1).getTextContent() : "");

        store2StorePart.setRepairReceiptQuantityValue(xmlData.getElementsByTagName("REPAIRRECEIPTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("REPAIRRECEIPTQUANTITY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setRepairReceiptQuantityDecimals(xmlData.getElementsByTagName("REPAIRRECEIPTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("REPAIRRECEIPTQUANTITY").item(0).getChildNodes().item(1).getTextContent() : "");

        store2StorePart.setScrapQuantityValue(xmlData.getElementsByTagName("SCRAPQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("SCRAPQUANTITY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setScrapQuantityDecimals(xmlData.getElementsByTagName("SCRAPQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("SCRAPQUANTITY").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "");

        store2StorePart.setOldBin(xmlData.getElementsByTagName("BIN").getLength() != 0 ? xmlData.getElementsByTagName("BIN").item(0).getTextContent() : "");
        store2StorePart.setToBin(xmlData.getElementsByTagName("TOBIN").getLength() != 0 ? xmlData.getElementsByTagName("TOBIN").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setPriceValue(xmlData.getElementsByTagName("PRICE").getLength() != 0 ? xmlData.getElementsByTagName("PRICE").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setPriceDecimals(xmlData.getElementsByTagName("PRICE").getLength() != 0 ? xmlData.getElementsByTagName("PRICE").item(0).getChildNodes().item(1).getTextContent() : "");

        store2StorePart.setCoreValue(xmlData.getElementsByTagName("COREVALUE").getLength() != 0 ? xmlData.getElementsByTagName("COREVALUE").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setCoreDecimals(xmlData.getElementsByTagName("COREVALUE").getLength() != 0 ? xmlData.getElementsByTagName("COREVALUE").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "");

        store2StorePart.setStockPriceValue(xmlData.getElementsByTagName("STOCKPRICE").getLength() != 0 ? xmlData.getElementsByTagName("STOCKPRICE").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setStockPriceDecimals(xmlData.getElementsByTagName("STOCKPRICE").getLength() != 0 ? xmlData.getElementsByTagName("STOCKPRICE").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "");

        String manufacturerCode = xmlData.getElementsByTagName("PRIMARYMANUFACTURERID").getLength() != 0 ? xmlData.getElementsByTagName("PRIMARYMANUFACTURERID").item(0).getFirstChild().getTextContent() : "";
        String manufacturerOrganization = xmlData.getElementsByTagName("PRIMARYMANUFACTURERID").getLength() != 0 ? xmlData.getElementsByTagName("PRIMARYMANUFACTURERID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        if (xmlData.getElementsByTagName("PRIMARYMANUFACTURERID").getLength() != 0) store2StorePart.setPrimaryManufacturer(manufacturerService.getManufacturer(apiUser, manufacturerCode, manufacturerOrganization));

        store2StorePart.setPrimaryManufacturerPartCode(xmlData.getElementsByTagName("PRIMARYMANUFACTURERPARTCODE").getLength() != 0 ? xmlData.getElementsByTagName("PRIMARYMANUFACTURERPARTCODE").item(0).getTextContent() : "");

        store2StorePart.setPrintQuantityValue(xmlData.getElementsByTagName("PRINTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("PRINTQUANTITY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setPrintQuantityDecimals(xmlData.getElementsByTagName("PRINTQUANTITY").getLength() != 0 ? xmlData.getElementsByTagName("PRINTQUANTITY").item(0).getChildNodes().item(1).getTextContent() : "");

        store2StorePart.setLabelPrintingDefault(xmlData.getElementsByTagName("LABELPRINTINGDEFAULT").getLength() != 0 ? xmlData.getElementsByTagName("LABELPRINTINGDEFAULT").item(0).getTextContent() : "");
        store2StorePart.setPartConditionTemplateCode(xmlData.getElementsByTagName("PARTCONDITIONTEMPLATECONDITIONCODE").getLength() != 0 ? xmlData.getElementsByTagName("PARTCONDITIONTEMPLATECONDITIONCODE").item(0).getTextContent() : "");

        NodeList requisitionNodeList = xmlData.getElementsByTagName("REQUISITIONLINEID");
        if (requisitionNodeList.getLength() != 0 && requisitionNodeList.item(0).getFirstChild() != null) store2StorePart.setRequisition(idSetter.setIdLineNum(requisitionNodeList.item(0).getFirstChild().getChildNodes()));
        else store2StorePart.setRequisition(new IdLineNum(new Id("",new InforEamCode("",""),""),""));

        store2StorePart.setByAsset(xmlData.getElementsByTagName("BYASSET").getLength() != 0 ? xmlData.getElementsByTagName("BYASSET").item(0).getTextContent() : "");
        store2StorePart.setUomCode(xmlData.getElementsByTagName("UOMID").getLength() != 0 ? xmlData.getElementsByTagName("UOMID").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setStatus(xmlData.getElementsByTagName("STATUS").getLength() != 0 ? xmlData.getElementsByTagName("STATUS").item(0).getFirstChild().getTextContent() : "");

        store2StorePart.setInTransitQuantityValue(xmlData.getElementsByTagName("INTRANSITQTY").getLength() != 0 ? xmlData.getElementsByTagName("INTRANSITQTY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setInTransitQuantityDecimals(xmlData.getElementsByTagName("INTRANSITQTY").getLength() != 0 ? xmlData.getElementsByTagName("INTRANSITQTY").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "");

        store2StorePart.setInTransitRepairQuantityValue(xmlData.getElementsByTagName("INTRANSITREPAIRQTY").getLength() != 0 ? xmlData.getElementsByTagName("INTRANSITREPAIRQTY").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setInTransitRepairQuantityDecimals(xmlData.getElementsByTagName("INTRANSITREPAIRQTY").getLength() != 0 ? xmlData.getElementsByTagName("INTRANSITREPAIRQTY").item(0).getChildNodes().item(1).getTextContent() : "");

        store2StorePart.setCurrency(xmlData.getElementsByTagName("CURRENCYID").getLength() != 0 ? xmlData.getElementsByTagName("CURRENCYID").item(0).getFirstChild().getTextContent() : "");

        Node expirationDate = xmlData.getElementsByTagName("EXPIRATIONDATE").getLength() != 0 ? xmlData.getElementsByTagName("EXPIRATIONDATE").item(0) : null;

        String year = expirationDate != null ? expirationDate.getFirstChild().getTextContent() : "";
        String month = expirationDate != null ? expirationDate.getChildNodes().item(1).getTextContent() : "";
        String day = expirationDate != null ? expirationDate.getChildNodes().item(2).getTextContent() : "";
        String hour = expirationDate != null ? expirationDate.getChildNodes().item(3).getTextContent() : "";
        String minute = expirationDate != null ? expirationDate.getChildNodes().item(4).getTextContent() : "";
        String second = expirationDate != null ? expirationDate.getChildNodes().item(5).getTextContent() : "";
        String nano = expirationDate != null ? expirationDate.getChildNodes().item(6).getTextContent() : "";
        String timeZone = expirationDate != null ? expirationDate.getLastChild().getTextContent() : "";

        if (expirationDate != null) {
            store2StorePart.setExpirationDate(LocalDateTime.of(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day), Integer.parseInt(hour), Integer.parseInt(minute), Integer.parseInt(second), Integer.parseInt(nano)));
            store2StorePart.setExpirationDateTimeZone(timeZone);
        }

        store2StorePart.setManufacturerLot(xmlData.getElementsByTagName("MANUFACTLOT").getLength() != 0 ? xmlData.getElementsByTagName("MANUFACTLOT").item(0).getTextContent() : "");
        store2StorePart.setSerialNumber(xmlData.getElementsByTagName("SERIALNUMBER").getLength() != 0 ? xmlData.getElementsByTagName("SERIALNUMBER").item(0).getTextContent() : "");
        store2StorePart.setRepairable(xmlData.getElementsByTagName("REPAIRABLE").getLength() != 0 ? xmlData.getElementsByTagName("REPAIRABLE").item(0).getTextContent() : "");

        String partCode = xmlData.getElementsByTagName("PARTID").getLength() != 0 ? xmlData.getElementsByTagName("PARTID").item(0).getFirstChild().getTextContent() : "";
        String partOrganization = xmlData.getElementsByTagName("PARTID").getLength() != 0 ? xmlData.getElementsByTagName("PARTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        if (xmlData.getElementsByTagName("PARTID").getLength() != 0) {
            Part part = partService.getPart(apiUser, partCode, partOrganization);

            part.setLot(xmlData.getElementsByTagName("LOT").getLength() != 0 ? xmlData.getElementsByTagName("LOT").item(0).getTextContent() : "");
            part.setBin("*");

            store2StorePart.setPart(part);
        }


        String assetCode = xmlData.getElementsByTagName("ASSETID").getLength() != 0 ? xmlData.getElementsByTagName("ASSETID").item(0).getFirstChild().getTextContent() : "";
        String assetOrganization = xmlData.getElementsByTagName("ASSETID").getLength() != 0 ? xmlData.getElementsByTagName("ASSETID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        if (xmlData.getElementsByTagName("ASSETID").getLength() != 0) store2StorePart.setAsset(assetService.getAsset(apiUser,assetCode,assetOrganization));

        String equipmentCode = xmlData.getElementsByTagName("ATTACHTOEQUIPMENT").getLength() != 0 ? xmlData.getElementsByTagName("ATTACHTOEQUIPMENT").item(0).getFirstChild().getTextContent() : "";
        String equipmentOrganization = xmlData.getElementsByTagName("ATTACHTOEQUIPMENT").getLength() != 0 ? xmlData.getElementsByTagName("ATTACHTOEQUIPMENT").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        if (xmlData.getElementsByTagName("ATTACHTOEQUIPMENT").getLength() != 0) store2StorePart.setAttachToEquipment(assetService.getAsset(apiUser,equipmentCode,equipmentOrganization));

        Department department = new Department();
        department.setCode(xmlData.getElementsByTagName("DEPARTMENTID").getLength() != 0 ? xmlData.getElementsByTagName("DEPARTMENTID").item(0).getFirstChild().getTextContent() : "");
        store2StorePart.setDepartment(department);

        NodeList parentNode = xmlData.getElementsByTagName("USERDEFINEDAREA");
        NodeList childNodes = parentNode.getLength() != 0 ? parentNode.item(0).getChildNodes() : parentNode;

        store2StorePart.setUserDefinedFields(userDefinedFieldsSetter.setUserDefinedFields(childNodes));
        return store2StorePart;
    }
}
