package com.assettec.api.internal.core.entities.campaign;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CampaignId {
    private Id campaignEventId;
    private String campaignEvent;
}
