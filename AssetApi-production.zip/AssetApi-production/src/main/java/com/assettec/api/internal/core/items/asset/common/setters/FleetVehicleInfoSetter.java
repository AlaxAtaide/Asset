package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class FleetVehicleInfoSetter {

    private IdSetter idSetter;
    private CodeSetter codeSetter;

    public void setFleetVehicleInfo(AssetEquipment asset, NodeList childNodes) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            String nodeName = childNode.getNodeName();

            if (nodeName.equals("ISVEHICLE")) asset.setIsVehicle(childNode.getTextContent());
            if (nodeName.equals("FLEETCUSTOMERID")) asset.setFleetCustomer(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("FLEETBILLINGID")) asset.setFleetBilling(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("FLEETMARKUPID")) asset.setFleetMarkUp(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("VEHICLESTATUS")) asset.setVehicleStatus(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("VEHICLETYPE")) asset.setVehicleType(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("ISSUETO")) asset.setIssueTo(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("ISRENTAL")) asset.setIsRental(childNode.getTextContent());
            if (nodeName.equals("RENTALTEMPLATEID")) asset.setRentalTemplate(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("ISCONTRACT")) asset.setIsContract(childNode.getTextContent());
            if (nodeName.equals("CONTRACTTEMPLATEID")) asset.setContractTemplate(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("CUSTOMERID")) asset.setCustomer(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("AVAILABILITYSTATUS")) asset.setAvailabilityStatus(codeSetter.setCode(childNode.getChildNodes()));
        }
    }
}
