package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.ScheduleMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class ScheduleSetter {
    public void setSchedule(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        ScheduleMobile schedule = new ScheduleMobile();

        schedule.setReportedBy(workOrder.getRequestedBy() == null
                || workOrder.getRequestedBy().getCode() == null
                ? "" : workOrder.getRequestedBy().getCode());

        schedule.setReportedDate(workOrder.getReported() == null
                ? "" : workOrder.getReported().toString(true));

        schedule.setAssignedBy(workOrder.getScheduledGroup() == null
                ? "" : workOrder.getScheduledGroup());

        schedule.setAssignedTo(workOrder.getAssignedTo() == null
                || workOrder.getAssignedTo().getCode() == null
                ? "" : workOrder.getAssignedTo().getCode());

        schedule.setProgramedStartDate(workOrder.getTargetDate() == null
                ? "" : workOrder.getTargetDate().toString(true));

        schedule.setProgramedEndDate(workOrder.getScheduledEnd() == null
                ? "" : workOrder.getScheduledEnd().toString(true));

        schedule.setSolicitedStartDate(workOrder.getRequestedStart() == null
                ? "" : workOrder.getRequestedStart().toString(true));

        schedule.setSolicitedEndDate(workOrder.getRequestedEnd() == null
                ? "" : workOrder.getRequestedEnd().toString(true));

        schedule.setStartDate(workOrder.getStartDate() == null
                ? "" : workOrder.getStartDate().toString(true));

        schedule.setEndDate(workOrder.getCompletedDate() == null
                ? "" : workOrder.getCompletedDate().toString(true));

        schedule.setShift(workOrder.getShift() == null
                || workOrder.getShift().getCode() == null
                ? "" : workOrder.getShift().getCode());

        schedule.setBudget(workOrder.getProjectId() == null
                || workOrder.getProjectId().getCode() == null
                ? "" : workOrder.getProjectId().getCode());

        schedule.setCampaign(workOrder.getCampaignId() == null
                || workOrder.getCampaignId().getCampaignEventId() == null
                || workOrder.getCampaignId().getCampaignEventId().getCode() == null
                ? "" : workOrder.getCampaignId().getCampaignEventId().getCode());

        schedule.setServiceRequestCode(workOrder.getServiceRequest() == null
                || workOrder.getServiceRequest().getCode() == null
                ? "" : workOrder.getServiceRequest().getCode());

        workOrderDetails.setSchedule(schedule);
    }
}
