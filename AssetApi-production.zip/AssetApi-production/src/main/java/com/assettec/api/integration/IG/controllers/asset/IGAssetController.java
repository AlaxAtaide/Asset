package com.assettec.api.integration.IG.controllers.asset;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "asset")
@AllArgsConstructor
public class IGAssetController {
    private ApiUserService apiUserService;
    private IGAssetService assetService;

    @SneakyThrows
    @PostMapping()
    public IGAssetRegistrationRequest registerAsset(@RequestParam(name = "token") String token, @RequestBody IGAssetRegistrationRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return assetService.registerAsset(apiUser, request);
    }

}
