package com.assettec.api.internal.core.entities.supplier.contact;

import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SupplierContact {
    private Long id;

    private int sequenceNumber;
    private String name;
    private String phone;
    private String contactMethod;
    private String fax;
    private String email;
    private String streetAddress1;
    private String streetAddress2;
    private String city;
    private String state;
    private String zip;
    private String secondEmail;
    private String secondPhone;
    private String thirdPhone;

    private UserDefinedFields userDefinedFields;
    private UserDefinedArea userDefinedArea;

    private int updatedCount;
}
