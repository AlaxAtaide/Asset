package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceMobile {
    private String aboveCeilingPermit;
    private String interimLifeSafety;
    private String interimInfectionControl;
    private String preConstructionRiskAssessment;
    private String planImprovement;
    private String statementOfCondition;
    private String buildMaintenanceProgram;
    private String personalProtectiveEquipment;
    private String lockout;
    private String burnPermit;
    private String confinedSpace;
    private String patientSafety;
    private String recallNotice;
    private String SMDA;
    private String hipaaConfidentiality;

    public static ComplianceMobile createEmpty() {
        return new ComplianceMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
