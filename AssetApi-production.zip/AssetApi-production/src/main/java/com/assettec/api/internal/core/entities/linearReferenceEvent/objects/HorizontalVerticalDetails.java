package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HorizontalVerticalDetails {
    private InforEamCode relationShipTypeId;

    private InforEamCount horizontalOffSet;
    private InforEamCode horizontalOffSetUom;
    private InforEamCode horizontalOffSetTypeId;

    private InforEamCount verticalOffSet;
    private InforEamCode verticalOffSetUom;
    private InforEamCode verticalOffSetTypeId;

    public String buildRequest() {
        return "<RELATIONSHIPTYPEID entity=\"OrganizationValidity\">" +
                "<TYPECODE>" + relationShipTypeId.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + relationShipTypeId.getDescription() + "</DESCRIPTION>" +
                "</RELATIONSHIPTYPEID>" +
                "<HORIZONTALOFFSET qualifier=\"ALLOWEDWT\">" +
                "<VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + horizontalOffSet.getValue() + "</VALUE>" +
                "<NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">" + horizontalOffSet.getDecimals() + "</NUMOFDEC>" +
                "<SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">" + horizontalOffSet.getSign() + "</SIGN>" +
                "<UOM xmlns=\"http://www.openapplications.org/oagis_fields\">" + horizontalOffSet.getUom() + "</UOM>" +
                "</HORIZONTALOFFSET>" +
                "<HORIZONTALOFFSETUOM>" +
                "<LINEARREFUOM>" + horizontalOffSetUom.getCode() + "</LINEARREFUOM>" +
                "<DESCRIPTION>" + horizontalOffSetUom.getDescription() + "</DESCRIPTION>" +
                "</HORIZONTALOFFSETUOM>" +
                "<HORIZONTALOFFSETTYPEID entity=\"Department\">" +
                "<TYPECODE>" + horizontalOffSetTypeId.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + horizontalOffSetTypeId.getDescription() + "</DESCRIPTION>" +
                "</HORIZONTALOFFSETTYPEID>" +
                "<VERTICALOFFSET qualifier=\"ALLOWEDWT\">" +
                verticalOffSet.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</VERTICALOFFSET>" +
                "<VERTICALOFFSETUOM>" +
                "<LINEARREFUOM>" + verticalOffSetUom.getCode() + "</LINEARREFUOM>" +
                "<DESCRIPTION>" + verticalOffSetUom.getDescription() + "</DESCRIPTION>" +
                "</VERTICALOFFSETUOM>" +
                "<VERTICALOFFSETTYPEID entity=\"Department\">" +
                "<TYPECODE>" + verticalOffSetTypeId.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + verticalOffSetTypeId.getDescription() + "</DESCRIPTION>" +
                "</VERTICALOFFSETTYPEID>";
    }
}
