package com.assettec.api.internal.core.entities.task;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TaskId {
    private String code;
    private String revision;
    private InforEamCode organization;
    private String description;
    private InforEamCount taskQuantity;
    private InforEamCode taskUom;

    public String buildOrganizationRequestString(String upper, String lower) {
        if (organization == null) return "";
        String organizationCode = organization.getCode() == null || organization.getCode().isEmpty() ? "" : "<ORGANIZATIONCODE>" + organization.getCode() + "</ORGANIZATIONCODE>";
        String organizationDescription = organization.getDescription() == null || organization.getDescription().isEmpty() ? "" : "<DESCRIPTION>" + organization.getDescription() + "</DESCRIPTION>";

        return upper + organizationCode + organizationDescription + lower;
    }

    public String buildRequest(String upper, String lower) {

        String taskQuantity = getTaskQuantity() == null ? "" : getTaskQuantity().buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">","</TASKQUANTITY>");
        String taskCode = getCode() == null ? "" : "<TASKCODE>" + getCode() + "</TASKCODE>";
        String taskRevision = getRevision() == null ? "" : "<TASKREVISION>" + getRevision() + "</TASKREVISION>";
        String description = getDescription() == null ? "" : "<DESCRIPTION>" + getDescription() + "</DESCRIPTION>";

        String organization = getOrganization() == null ? "" : getOrganization().buildRequest("<ORGANIZATIONID entity=\"WorkOrderDefault\">","</ORGANIZATIONID>","ORGANIZATIONCODE","DESCRIPTION");
        String taskUom = getTaskUom() == null ? "" : getTaskUom().buildRequest("<TASKUOM>","</TASKUOM>","UOMCODE","DESCRIPTION");

        return  upper + taskCode + taskRevision + organization + description + taskQuantity + taskUom + lower;
    }
}
