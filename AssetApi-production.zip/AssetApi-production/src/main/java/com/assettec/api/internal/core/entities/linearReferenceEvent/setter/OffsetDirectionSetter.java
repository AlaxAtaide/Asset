package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.OffSetDirection;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class OffsetDirectionSetter {

    public OffSetDirection setOffsetDirection(NodeList nodeList) {
        OffSetDirection offSetDirection = new OffSetDirection("","","");

        offSetDirection.setUCodeEntity(nodeList.item(0).getTextContent());
        offSetDirection.setUCode(nodeList.item(1).getTextContent());
        offSetDirection.setDescription(nodeList.item(2).getTextContent());

        return offSetDirection;
    }
}
