package com.assettec.api.internal.utilities.handlers;

import com.assettec.api.internal.utilities.requests.requestbuilders.*;
import com.assettec.api.internal.utilities.requests.requestbuilders.assetRequestBuilder.AssetRequestBuilder;
import com.assettec.api.internal.utilities.requests.requestbuilders.store2store.StoreToStoreTransactionsRequestBuilder;
import com.assettec.api.internal.utilities.requests.requestbuilders.workOrderBuilder.WorkOrderRequestBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.stereotype.Component;

@Component
@Getter
@AllArgsConstructor
public class RequestCreator {
    private EquipmentRequestBuilder equipmentRequestBuilder;
    private GridRequestBuilder gridRequestBuilder;
    private ManufacturerRequestBuilder manufacturerRequestBuilder;
    private PartRequestBuilder partRequestBuilder;
    private PurchaseOrderRequestBuilder purchaseOrderRequestBuilder;
    private WorkOrderRequestBuilder workOrderRequestBuilder;
    private SupplierRequestBuilder supplierRequestBuilder;
    private StoreRequestBuilder storeRequestBuilder;
    private POReceiptRequestBuilder poReceiptRequestBuilder;
    private TransactionsRequestBuilder transactionsRequestBuilder;
    private StoreToStoreTransactionsRequestBuilder storeTransactionsRequestBuilder;
    private PackingSlipRequestBuilder packingSlipRequestBuilder;
    private AssetRequestBuilder assetRequestBuilder;
    private AdministrationRequestBuilder administrationRequestBuilder;
}
