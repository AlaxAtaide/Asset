package com.assettec.api.internal.controllers;

import com.assettec.api.internal.core.receipt.POReceipt;
import com.assettec.api.internal.core.receipt.POReceiptService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(path = "core/purchase")
public class CorePurchaseOrderController {

    private ApiUserService apiUserService;
    private POReceiptService poReceiptService;

    @GetMapping()
    @SneakyThrows
    public List<POReceipt> getReceiptByPurchaseOrder(@RequestParam(name = "token") String token, @RequestParam(name = "code") String code) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return poReceiptService.getReceiptsByPurchaseOrder(apiUser, code);
    }
}
