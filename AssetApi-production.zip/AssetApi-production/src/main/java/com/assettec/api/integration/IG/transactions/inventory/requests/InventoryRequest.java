package com.assettec.api.integration.IG.transactions.inventory.requests;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class InventoryRequest {

    String partCode;
    String partName;
    String partOrganization;
    String store;
    String lastPrice;
    String basePrice;
    String averagePrice;
    String standardPrice;
    double quantityInStore;

}
