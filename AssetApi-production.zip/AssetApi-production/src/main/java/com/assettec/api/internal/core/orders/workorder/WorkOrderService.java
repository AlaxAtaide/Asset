package com.assettec.api.internal.core.orders.workorder;

import com.assettec.api.internal.core.orders.workorder.utilities.WorkOrderUpdater;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

@Service
@AllArgsConstructor
public class WorkOrderService {

    private WorkOrderUpdater workOrderUpdater;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public WorkOrder getWorkOrder(ApiUser apiUser, String workOrderCode, String organization) {
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getWorkOrderRequestBuilder().getWorkOrder(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), workOrderCode, organization);
        response = requestSender.sendPostRequest(postRequest, host);
        Document xmlData = xmlParser.toDocument(response);
        NodeList resultData = xmlData.getElementsByTagName("ResultData").item(0).getChildNodes();

        return workOrderUpdater.setWorkOrder(resultData);
    }

    @SneakyThrows
    public String postWorkOrder(ApiUser apiUser, String workOrderOrganization, String workOrderDescription, String status, String equipmentCode, String equipmentOrganization, String department, String type ) {
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getWorkOrderRequestBuilder().postWorkOrder(apiUser, workOrderOrganization, workOrderDescription, status, equipmentCode, equipmentOrganization, department, type);
        response = requestSender.sendPostRequest(postRequest, host);
        Document xmlData = xmlParser.toDocument(response);

        return xmlData.getElementsByTagName("Message").item(0).getTextContent();
    }

    @SneakyThrows
    public String putWorkOrder(ApiUser apiUser, WorkOrder workOrder) {
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getWorkOrderRequestBuilder().putWorkOrder(apiUser, workOrder);
//        response = requestSender.sendPostRequest(postRequest, host);
//        Document xmlData = xmlParser.toDocument(response);

        return postRequest;
    }
}
