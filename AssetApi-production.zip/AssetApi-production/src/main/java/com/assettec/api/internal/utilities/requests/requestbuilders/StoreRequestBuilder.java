package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class StoreRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String getStore(String userName, String tenant, String passWord, String organization, String storeCode) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0230_GetStore_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"Store\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0230_001\">\n" +
                "            <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <STORECODE>" + storeCode + "</STORECODE>\n" +
                "            </STOREID>\n" +
                "        </MP0230_GetStore_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postStore(String userName, String tenant, String passWord, String organization, String storeCode, String storeOrganization, String storeDescription, String storeType, String autoApproveCode) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0231_AddStore_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Store\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0231_001\">\n" +
                "            <Store recordid=\"1\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" xmlns=\"http://schemas.datastream.net/MP_entities/Store_001\">\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + storeOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + storeDescription + "</DESCRIPTION>\n" +
                "                </STOREID>\n" +
                "                <PRICETYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + storeType + "</TYPECODE>\n" +
                "                </PRICETYPE>\n" +
                "                <AUTOAPPVSTATUSCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + autoApproveCode + "</AUTOAPPVSTATUSCODE>\n" +
                "            </Store>\n" +
                "        </MP0231_AddStore_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putStore(String userName, String tenant, String passWord, String organization, String storeCode, String storeOrganization, String storeDescription, String storeType, String autoApproveCode, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0232_SyncStore_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"Store\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0232_001\">\n" +
                "            <Store recordid=\"" + updatedCount + "\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" xmlns=\"http://schemas.datastream.net/MP_entities/Store_001\">\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + storeOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + storeDescription + "</DESCRIPTION>\n" +
                "                </STOREID>\n" +
                "                <PRICETYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + storeType + "</TYPECODE>\n" +
                "                </PRICETYPE>\n" +
                "                <AUTOAPPVSTATUSCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + autoApproveCode + "</AUTOAPPVSTATUSCODE>\n" +
                "            </Store>\n" +
                "        </MP0232_SyncStore_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteStore(String userName, String tenant, String passWord, String organization, String storeCode, String storeOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0233_DeleteStore_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"Store\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0233_001\">\n" +
                "            <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                 <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + storeOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>" +
                "            </STOREID>\n" +
                "        </MP0233_DeleteStore_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
