package com.assettec.api.internal.core.items.part.utilities;

import com.assettec.api.internal.core.items.part.Part;
import com.assettec.api.internal.core.user.info.area.UserDefinedAreaSetter;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFieldsSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

@Service
@AllArgsConstructor
public class PartSetter {

    private UserDefinedAreaSetter userDefinedAreaSetter;
    private UserDefinedFieldsSetter userDefinedFieldsSetter;

    public Part setPart(Document xmlData, Part part) {
        part.setUpdatedCount(Integer.parseInt(xmlData.getElementsByTagName("Part").item(0).getAttributes().getNamedItem("recordid").getTextContent()));
        part.setCode(xmlData.getElementsByTagName("PARTID").item(0).getFirstChild().getTextContent());
        part.setOrganization(xmlData.getElementsByTagName("PARTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent());
        part.setDescription(xmlData.getElementsByTagName("PARTID").item(0).getLastChild().getTextContent());

        part.setModel(xmlData.getElementsByTagName("MODEL").getLength() != 0 ? xmlData.getElementsByTagName("MODEL").item(0).getFirstChild().getTextContent() : "");
        part.setTrackMethod(xmlData.getElementsByTagName("TRACKMETHOD").getLength() != 0 ? xmlData.getElementsByTagName("TRACKMETHOD").item(0).getFirstChild().getTextContent() : "");
        part.setUnitOfMetric(xmlData.getElementsByTagName("UOMID").getLength() != 0 ? xmlData.getElementsByTagName("UOMID").item(0).getFirstChild().getTextContent() : "");

        NodeList parentNode = xmlData.getElementsByTagName("USERDEFINEDAREA");
        NodeList childNodes = parentNode.getLength() != 0 ? parentNode.item(0).getChildNodes() : parentNode;

        part.setUserDefinedArea(userDefinedAreaSetter.setUserDefinedArea(childNodes));

        parentNode = xmlData.getElementsByTagName("UserDefinedFields");
        childNodes = parentNode.getLength() != 0 ? parentNode.item(0).getChildNodes() : parentNode;

        part.setUserDefinedFields(userDefinedFieldsSetter.setUserDefinedFields(childNodes));
        return part;
    }
}
