package com.assettec.api.integration.IG.transactions.equipment;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGEquipmentTransferRequest {
    private String equipmentCode;
    private String oldOrganization;
    private String newOrganization;
    private String newDepartmentCode;
}
