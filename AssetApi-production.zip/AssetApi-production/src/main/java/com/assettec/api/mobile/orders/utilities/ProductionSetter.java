package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.ProductionMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class ProductionSetter {
    public void setProductionDetails(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        ProductionMobile productionMobile = new ProductionMobile();

        productionMobile.setProductionRequest(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getRequestCode() == null
                ? "" : workOrder.getProductionDetails().getRequestCode());

        productionMobile.setProductionRequestRevision(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getRequestRevision() == null
                ? "" : workOrder.getProductionDetails().getRequestRevision().toString());

        productionMobile.setProductionOrder(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getOrder() == null
                ? "" : workOrder.getProductionDetails().getOrder());

        productionMobile.setProductionPriority(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getPriority() == null
                ? "" : workOrder.getProductionDetails().getPriority());

        productionMobile.setProductionPriorityDescription(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getPriorityDescription() == null
                ? "" : workOrder.getProductionDetails().getPriorityDescription());

        productionMobile.setProductionStartDate(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getStartDate() == null
                ? "" : workOrder.getProductionDetails().getStartDate().toString(true));

        productionMobile.setProductionEndDate(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getEndDate() == null
                ? "" : workOrder.getProductionDetails().getEndDate().toString(true));

        productionMobile.setAccountingEntity(workOrder.getProductionDetails() == null
                || workOrder.getProductionDetails().getAccountingEntity() == null
                ? "" : workOrder.getProductionDetails().getAccountingEntity());


        workOrderDetails.setProductionDetails(productionMobile);
    }
}
