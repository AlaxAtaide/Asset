package com.assettec.api.internal.core.grid;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Row {
    private String id;
    private List<Field> fields;

    public String getDataByName(String name) {
        for (Field field : fields) {
            if (field.getName().equals(name)) {
                return field.getData();
            }
        }
        return null;
    }
}
