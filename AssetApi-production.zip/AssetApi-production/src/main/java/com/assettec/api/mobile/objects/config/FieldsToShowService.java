package com.assettec.api.mobile.objects.config;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class FieldsToShowService {

    private FieldsToShowRepository fieldsToShowRepository;

    public FieldsToShow getShownFields() {
        return fieldsToShowRepository.getFields();
    }

    public String saveFields(FieldsToShow fields) {
        return fieldsToShowRepository.saveFields(fields);
    }
}
