package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PackingSlipRequestBuilder {

    private XMLRequestHeader xmlRequestHeader;

    public String getPackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, int packingSlipLine) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2131_GetPackingSlip_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"PackingSlip\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2131_001\">\n" +
                "            <PACKINGSLIPID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTID>\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PORECEIPTID>\n" +
                "                <PACKINGSLIPLINE>" + packingSlipLine + "0</PACKINGSLIPLINE>\n" +
                "            </PACKINGSLIPID>\n" +
                "        </MP2131_GetPackingSlip_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String retrievePackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2132_RetrievePackingSlip_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Retrieve\" noun=\"PackingSlip\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2132_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP2132_RetrievePackingSlip_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deletePackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, int packingSlipLine) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2133_DeletePackingSlip_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"PackingSlip\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2133_001\">\n" +
                "            <PACKINGSLIPID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTID>\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PORECEIPTID>\n" +
                "                <PACKINGSLIPLINE>" + packingSlipLine + "0</PACKINGSLIPLINE>\n" +
                "            </PACKINGSLIPID>\n" +
                "        </MP2133_DeletePackingSlip_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String movePackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2136_MovePackingSlip_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Move\" noun=\"PackingSlip\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2136_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP2136_MovePackingSlip_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, String purchaseOrderCode, String purchaseOrderOrganization, String partCode, String partOrganization, String receivedQuantity, String packingSlipLine, String purchaseOrderLine, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2135_SyncPackingSlip_001>\n" +
                "            <PackingSlip recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/PackingSlip_001\">\n" +
                "                <PACKINGSLIPID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTID>\n" +
                "                        <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                        <ORGANIZATIONID entity=\"Organization\">\n" +
                "                            <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PORECEIPTID>\n" +
                "                    <PACKINGSLIPLINE>" + packingSlipLine + "</PACKINGSLIPLINE>\n" +
                "                </PACKINGSLIPID>\n" +
                "                <PURCHASEORDERLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERID>\n" +
                "                        <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE>\n" +
                "                        <ORGANIZATIONID entity=\"Organization\">\n" +
                "                            <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERLINENUM>" + purchaseOrderLine + "</PURCHASEORDERLINENUM>\n" +
                "                </PURCHASEORDERLINEID>\n" +
                "                <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Group\">\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PARTID>\n" +
                "                <PACKINGSLIPRECVQTY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + receivedQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">6</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </PACKINGSLIPRECVQTY>\n" +
                "                <CONVERSIONFACTOR qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">1</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">0</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">XXX</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </CONVERSIONFACTOR>\n" +
                "            </PackingSlip>\n" +
                "        </MP2135_SyncPackingSlip_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteAllPackingSlip(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2134_DeleteAllPackingSlips_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"AllPackingSlips\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2134_001\">\n" +
                "            <AllPackingSlips xmlns=\"http://schemas.datastream.net/MP_entities/AllPackingSlips_001\">\n" +
                "                <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PORECEIPTID>\n" +
                "            </AllPackingSlips>\n" +
                "        </MP2134_DeleteAllPackingSlips_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

}
