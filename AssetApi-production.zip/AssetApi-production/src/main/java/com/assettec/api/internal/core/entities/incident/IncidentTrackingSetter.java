package com.assettec.api.internal.core.entities.incident;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class IncidentTrackingSetter {
    public IncidentTracking setIncidentTracking(NodeList childNodes) {
        IncidentTracking incidentTracking = new IncidentTracking();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("PATIENT")) incidentTracking.setPatient(childNode.getTextContent());
            if (childNode.getNodeName().equals("STAFFINJURY")) incidentTracking.setStaffInjury(childNode.getTextContent());
            if (childNode.getNodeName().equals("SECURITYINCIDENT")) incidentTracking.setSecurityIncident(childNode.getTextContent());
            if (childNode.getNodeName().equals("PROPERTYDAMAGE")) incidentTracking.setPropertyDamage(childNode.getTextContent());
            if (childNode.getNodeName().equals("HAZARDOUSMATERIALSINCIDENT")) incidentTracking.setHazardousMaterialIncident(childNode.getTextContent());
            if (childNode.getNodeName().equals("FIRESAFETYINCIDENT")) incidentTracking.setFireSafetyIncident(childNode.getTextContent());
            if (childNode.getNodeName().equals("MEDICALEQUIPMENTINCIDENT")) incidentTracking.setMedicalEquipmentIncident(childNode.getTextContent());
            if (childNode.getNodeName().equals("UTILITYSYSTEMINCIDENT")) incidentTracking.setUtilitySystemIncident(childNode.getTextContent());

        }

        return incidentTracking;
    }
}
