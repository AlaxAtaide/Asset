package com.assettec.api.integration.IG.controllers.supplier;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGSupplier {
    private String http;
    private String message;

    private String supplierCode;
    private String supplierName;
    private String cnpj;
    private String language;
    private String currency;

    private String contactName;
    private String contactPhone;
    private String contactAddress1;
    private String contactAddress2;
    private String contactCity;
    private String contactState;
    private String contactCEP;
    private String contactEmail;
}
