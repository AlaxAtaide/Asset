package com.assettec.api.integration.IG.transactions;

import com.assettec.api.integration.IG.transactions.equipment.IGAssetEquipmentSend;
import com.assettec.api.integration.IG.transactions.equipment.IGAssetEquipmentSendList;
import com.assettec.api.integration.IG.transactions.equipment.IGEquipmentTransferRequest;
import com.assettec.api.integration.IG.transactions.equipment.IGFilteredEquipmentList;
import com.assettec.api.integration.IG.transactions.inventory.InventoryLineService;
import com.assettec.api.integration.IG.transactions.inventory.requests.InventoryExternalRequest;
import com.assettec.api.integration.IG.transactions.inventory.requests.InventorySend;
import com.assettec.api.integration.IG.transactions.position.*;
import com.assettec.api.integration.IG.transactions.receipt.IGPOReceiptRequest;
import com.assettec.api.integration.IG.transactions.receipt.IGPOReceiptService;
import com.assettec.api.integration.IG.transactions.store2store.*;
import com.assettec.api.integration.IG.transactions.system.IGAssetSystemSend;
import com.assettec.api.integration.IG.transactions.system.IGAssetSystemSendList;
import com.assettec.api.integration.IG.transactions.system.IGFilteredSystemList;
import com.assettec.api.integration.IG.transactions.system.IGSystemTransferRequest;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping
@AllArgsConstructor
public class IGTransactionsController {

    private IGStore2StoreIGService store2StoreIGService;
    private InventoryLineService inventoryLineService;
    private IGTransactionService transactionService;
    private IGPOReceiptService poReceiptService;
    private ApiUserService apiUserService;

    @SneakyThrows
    @PutMapping(path = "receivePart") @Async
    public CompletableFuture<IGStore2Store2SendHttp> receivePart(@RequestParam(name = "token") String token, @RequestBody IGStoreToStoreTransaction request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateStoreToStoreTransaction(apiUser, request, "TR"));
    }

    @SneakyThrows
    @PutMapping(path = "approvePart") @Async
    public CompletableFuture<IGStore2Store2SendHttp> approvePart(@RequestParam(name = "token") String token, @RequestBody IGStoreToStoreTransaction request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateStoreToStoreTransaction(apiUser, request, "A"));
    }

    @SneakyThrows
    @PutMapping(path = "receiveEquipment") @Async
    public CompletableFuture<IGAssetEquipmentSend> receiveEquipment(@RequestParam(name = "token") String token, @RequestBody IGEquipmentTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateEquipment(apiUser, request.getEquipmentCode(), "I"));
    }

    @SneakyThrows
    @PutMapping(path = "approveEquipment") @Async
    public CompletableFuture<IGAssetEquipmentSend> approveEquipment(@RequestParam(name = "token") String token, @RequestBody IGEquipmentTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateEquipment(apiUser, request.getEquipmentCode(), "ET"));
    }

    @SneakyThrows
    @PutMapping(path = "receivePosition") @Async
    public CompletableFuture<IGAssetPositionSend> receivePosition(@RequestParam(name = "token") String token, @RequestBody IGPositionTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updatePosition(apiUser, request.getPositionCode(), "I"));
    }

    @SneakyThrows
    @PutMapping(path = "approvePosition") @Async
    public CompletableFuture<IGAssetPositionSend> approvePosition(@RequestParam(name = "token") String token, @RequestBody IGPositionTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updatePosition(apiUser, request.getPositionCode(), "ET"));
    }

    @SneakyThrows
    @PutMapping(path = "receiveSystem") @Async
    public CompletableFuture<IGAssetSystemSend> receiveSystem(@RequestParam(name = "token") String token, @RequestBody IGSystemTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateSystem(apiUser, request.getSystemCode(), "I"));
    }

    @SneakyThrows
    @PutMapping(path = "approveSystem") @Async
    public CompletableFuture<IGAssetSystemSend> approveSystem(@RequestParam(name = "token") String token, @RequestBody IGSystemTransferRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        // todo mudar status
        return CompletableFuture.completedFuture(transactionService.updateSystem(apiUser, request.getSystemCode(), "ET"));
    }

    @SneakyThrows
    @PostMapping(path = "receipt") @Async
    public CompletableFuture<IGPOReceiptRequest> postPorReceipt(@RequestParam(name = "token") String token, @RequestBody IGPOReceiptRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(poReceiptService.postPOReceipt(apiUser, request));
    }

    @SneakyThrows
    @GetMapping(path = "inventory") @Async
    public CompletableFuture<InventorySend> findInventoryLines(@RequestParam(name = "token") String token, @RequestBody(required = false) InventoryExternalRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (request == null) request = new InventoryExternalRequest("","","");
        return CompletableFuture.completedFuture(
                new InventorySend("200", "Transação realizada com sucesso.",
                        inventoryLineService.requestRouter(request.getPartCode(),
                                request.getPartOrganization(),
                                request.getStore(),
                                inventoryLineService.getAllInventoryLines(apiUser))));
    }

    @SneakyThrows
    @GetMapping(path = "getPart") @Async
    public CompletableFuture<IGStore2Store2SendList> getStore2StorePart(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo mudar status
        return CompletableFuture.completedFuture(store2StoreIGService.returnStore2Store(apiUser, "NF"));
    }

    @SneakyThrows
    @GetMapping(path = "getPartByStatus") @Async
    public CompletableFuture<IGStore2Store2SendList> getStore2StoreTransactionByStatus(@RequestParam(name = "token") String token, @RequestParam(name = "status", required = false) String status) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (status == null) status = "";
        return CompletableFuture.completedFuture(store2StoreIGService.returnStore2Store(apiUser, status));
    }

    @SneakyThrows
    @GetMapping(path = "getEquipment") @Async
    public CompletableFuture<IGAssetEquipmentSendList> getEquipments(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo mudar status
        return CompletableFuture.completedFuture(transactionService.sendIGEquipmentInformation(apiUser, "NF2"));
    }

    @SneakyThrows
    @GetMapping(path = "getEquipmentByStatus")
    @Async
    public CompletableFuture<IGFilteredEquipmentList> getEquipmentsByStatus(@RequestParam(name = "token") String token, @RequestParam(name = "status", required = false) String status) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (status == null) status = "";
        return CompletableFuture.completedFuture(transactionService.sendFilterEquipment(apiUser, status));
    }

    @SneakyThrows
    @GetMapping(path = "getPosition") @Async
    public CompletableFuture<IGAssetPositionSendList> getPositions(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo mudar status
        return CompletableFuture.completedFuture(transactionService.sendIGPositionInformation(apiUser, "NF2"));
    }

    @SneakyThrows
    @GetMapping(path = "getPositionByStatus")
    @Async
    public CompletableFuture<IGFilteredPositionList> getPositionsByStatus(@RequestParam(name = "token") String token, @RequestParam(name = "status", required = false) String status) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (status == null) status = "";
        return CompletableFuture.completedFuture(transactionService.sendFilterPosition(apiUser, status));
    }

    @SneakyThrows
    @GetMapping(path = "getSystem") @Async
    public CompletableFuture<IGAssetSystemSendList> getSystems(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo mudar status
        return CompletableFuture.completedFuture(transactionService.sendIGSystemInformation(apiUser, "NF2"));
    }

    @SneakyThrows
    @GetMapping(path = "getSystemByStatus")
    @Async
    public CompletableFuture<IGFilteredSystemList> getSystemsByStatus(@RequestParam(name = "token") String token, @RequestParam(name = "status", required = false) String status) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (status == null) status = "";
        return CompletableFuture.completedFuture(transactionService.sendFilterSystem(apiUser, status));
    }
}
