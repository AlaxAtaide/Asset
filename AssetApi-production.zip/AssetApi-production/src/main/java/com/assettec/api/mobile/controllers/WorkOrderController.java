package com.assettec.api.mobile.controllers;

import com.assettec.api.internal.core.orders.workorder.WorkOrderService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.mobile.objects.grid.GridWorkOrder;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import com.assettec.api.mobile.services.WorkOrderMobileService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "mobile/workOrder")
@AllArgsConstructor
public class WorkOrderController {
    private WorkOrderService workOrderService;
    private WorkOrderMobileService workOrderMobileService;
    private ApiUserService apiUserService;

    @PostMapping()
    public CompletableFuture<String> postWorkOrder(@RequestParam(name = "token") String token, @RequestBody GridWorkOrder workOrder) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.postWorkOrder(apiUser,workOrder.getOrganization(),workOrder.getDescription(),workOrder.getWorkOrderStatus(),workOrder.getEquipment(),workOrder.getEquipmentOrganization(),workOrder.getDepartment(),workOrder.getWorkOrderType()));
    }

    @PutMapping()
    public CompletableFuture<String> putWorkOrder(@RequestParam(name = "token") String token, @RequestBody WorkOrderDetails workOrderDetails) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderMobileService.putMobileWorkOrder(apiUser, workOrderDetails));
    }
}
