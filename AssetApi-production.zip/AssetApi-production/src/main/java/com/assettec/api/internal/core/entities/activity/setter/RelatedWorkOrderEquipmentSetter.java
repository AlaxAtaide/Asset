package com.assettec.api.internal.core.entities.activity.setter;

import com.assettec.api.internal.core.entities.activity.ActivityId;
import com.assettec.api.internal.core.entities.activity.RelatedWorkOrderEquipment;
import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

@Component
@AllArgsConstructor
public class RelatedWorkOrderEquipmentSetter {

    private IdSetter idSetter;

    public RelatedWorkOrderEquipment setWorkOrderEquipment(NodeList childNodes) {

            RelatedWorkOrderEquipment workOrderEquipment = new RelatedWorkOrderEquipment(new Id("",new InforEamCode("",""),""),new ActivityId(new Id("",new InforEamCode("",""),""),"",""));
            NodeList workOrderEquipmentNodeList = childNodes.item(0).getChildNodes();

            for (int i = 0; i < workOrderEquipmentNodeList.getLength(); i++) {
                Node workOrderEquipmentNode = workOrderEquipmentNodeList.item(i);

                if (workOrderEquipmentNode.getNodeName().equals("EQUIPMENTID")) workOrderEquipment.setEquipmentId(idSetter.setId(workOrderEquipmentNode.getChildNodes()));

                if (workOrderEquipmentNode.getNodeName().equals("RELATEDWORKORDERACTID")) {
                    ActivityId activityId = new ActivityId();
                    NodeList activityNodeList = workOrderEquipmentNode.getFirstChild().getChildNodes();

                    for (int j = 0; j < activityNodeList.getLength(); j++) {
                        Node activityNode = activityNodeList.item(j);

                        if (activityNode.getNodeName().equals("WORKORDERID")) activityId.setWorkOrderId(idSetter.setId(activityNode.getChildNodes()));
                        if (activityNode.getNodeName().equals("ACTIVITYCODE")) activityId.setCode(activityNode.getTextContent());
                        if (activityNode.getNodeName().equals("ACTIVITYNOTE")) activityId.setNote(activityNode.getTextContent());

                    }

                    workOrderEquipment.setRelatedWorkOrderId(activityId);
                }
            }

            return workOrderEquipment;
    }
}
