package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class BasicDataSetter {

    public void setBasicData(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        workOrderDetails.setCode(workOrder.getId() == null || workOrder.getId().getCode() == null ? "" : workOrder.getId().getCode());
        workOrderDetails.setOrganization(workOrder.getId() == null || workOrder.getId().getOrganization() == null || workOrder.getId().getOrganization().getCode() == null ? "" : workOrder.getId().getOrganization().getCode());
        workOrderDetails.setDescription(workOrder.getId() == null || workOrder.getId().getDescription() == null ? "" : workOrder.getId().getDescription());

        workOrderDetails.setType(workOrder.getType() == null || workOrder.getType().getDescription() == null ? "" : workOrder.getType().getDescription());
        workOrderDetails.setStatus(workOrder.getStatus() == null || workOrder.getStatus().getDescription() == null ? "" : workOrder.getStatus().getDescription());

        workOrderDetails.setEquipmentCode(workOrder.getEquipmentId() == null || workOrder.getEquipmentId().getCode() == null ? "" : workOrder.getEquipmentId().getCode());
        workOrderDetails.setEquipmentDescription(workOrder.getEquipmentId() == null || workOrder.getEquipmentId().getDescription() == null ? "" : workOrder.getEquipmentId().getDescription());
        workOrderDetails.setEquipmentOrganization(workOrder.getEquipmentId() == null || workOrder.getEquipmentId().getOrganization() == null || workOrder.getEquipmentId().getOrganization().getCode() == null ? "" : workOrder.getEquipmentId().getOrganization().getCode());
        workOrderDetails.setEquipmentType(workOrder.getWorkOrderAdditionalInfo() == null ? "" : workOrder.getWorkOrderAdditionalInfo().getEquipmentInfo() == null ? "" : workOrder.getWorkOrderAdditionalInfo().getEquipmentInfo().getObjType() == null ? "" : workOrder.getWorkOrderAdditionalInfo().getEquipmentInfo().getObjType().getDescription() == null ? "" : workOrder.getWorkOrderAdditionalInfo().getEquipmentInfo().getObjType().getDescription());
        workOrderDetails.setMultipleEquipments(workOrder.getMultiEquip() == null ? "" : workOrder.getMultiEquip());
        workOrderDetails.setEquipmentAlias(workOrder.getEquipmentAlias() == null ? "" : workOrder.getEquipmentAlias());
        workOrderDetails.setEquipmentManufacturer(workOrder.getManufacturerCode() == null ? "" : workOrder.getManufacturerCode());

        workOrderDetails.setPrint(workOrder.getPrint() == null ? "" : workOrder.getPrint());
        workOrderDetails.setPrinted(workOrder.getPrinted() == null ? "" : workOrder.getPrinted());

        workOrderDetails.setLocationCode(workOrder.getLocationId() == null || workOrder.getLocationId().getCode() == null ? "" : workOrder.getLocationId().getCode());
        workOrderDetails.setLocationDescription(workOrder.getLocationId() == null || workOrder.getLocationId().getDescription() == null ? "" : workOrder.getLocationId().getDescription());

        workOrderDetails.setPositionCode(workOrder.getPositionId() == null || workOrder.getPositionId().getCode() == null ? "" : workOrder.getPositionId().getCode());
        workOrderDetails.setPositionDescription(workOrder.getPositionId() == null || workOrder.getPositionId().getDescription() == null ? "" : workOrder.getPositionId().getDescription());

        workOrderDetails.setWorkspace(workOrder.getWorkSpaceId() == null || workOrder.getWorkSpaceId().getCode() == null ? "" : workOrder.getWorkSpaceId().getCode());
        workOrderDetails.setOemSite(workOrder.getOemSite() == null ? "" : workOrder.getOemSite());
        workOrderDetails.setSupplier(workOrder.getVendor() == null ? "" : workOrder.getVendor());
        workOrderDetails.setCoverageType(workOrder.getCoverageType() == null || workOrder.getCoverageType().getCode() == null ? "" : workOrder.getCoverageType().getCode());
        workOrderDetails.setSafety(workOrder.getSafety() == null ? "" : workOrder.getSafety());
        workOrderDetails.setWarranty(workOrder.getWarranty() == null ? "" : workOrder.getWarranty());
        workOrderDetails.setDepend(workOrder.getDepend() == null ? "" : workOrder.getDepend());
        workOrderDetails.setSurvey(workOrder.getSurvey() == null ? "" : workOrder.getSurvey());

        workOrderDetails.setDepartment(workOrder.getDepartmentId() == null || workOrder.getDepartmentId().getCode() == null ? "" : workOrder.getDepartmentId().getCode());
        workOrderDetails.setDepartmentOrg(workOrder.getDepartmentId() == null || workOrder.getDepartmentId().getDescription() == null ? "" : workOrder.getDepartmentId().getDescription());

        workOrderDetails.setReliabilityRanking("");
        workOrderDetails.setReliabilityRankingIndex("");
        workOrderDetails.setReliabilityRankingScore("");

        workOrderDetails.setCreatedBy(workOrder.getCreatedBy() == null || workOrder.getCreatedBy().getCode() == null ? "" : workOrder.getCreatedBy().getCode());
        workOrderDetails.setCreatedDate(workOrder.getCreatedDate() == null ? "" : workOrder.getCreatedDate().toString(false));

        workOrderDetails.setESigner(workOrder.getESignatureDetail() == null || workOrder.getESignatureDetail().getESigner() == null || workOrder.getESignatureDetail().getESigner().getCode() == null ? "" : workOrder.getESignatureDetail().getESigner().getCode());
        workOrderDetails.setESignDate(workOrder.getESignatureDetail() == null || workOrder.getESignatureDetail().getESignatureDate() == null ? "" : workOrder.getESignatureDetail().getESignatureDate().toString(true));
        workOrderDetails.setESignType(workOrder.getESignatureDetail() == null || workOrder.getESignatureDetail().getSignatureType() == null ? "" : workOrder.getESignatureDetail().getSignatureType());
    }
}
