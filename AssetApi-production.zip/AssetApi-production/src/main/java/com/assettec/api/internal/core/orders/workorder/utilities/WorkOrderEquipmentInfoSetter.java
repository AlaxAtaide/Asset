package com.assettec.api.internal.core.orders.workorder.utilities;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.orders.workorder.WorkOrderEquipmentInfo;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class WorkOrderEquipmentInfoSetter {

    private IdSetter idSetter;
    private CodeSetter codeSetter;
    private CountSetter countSetter;

    public WorkOrderEquipmentInfo setWorkOrderEquipmentInfo(NodeList childNodes) {
        WorkOrderEquipmentInfo workOrderEquipmentInfo = new WorkOrderEquipmentInfo();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("EQUIPMENTID")) workOrderEquipmentInfo.setEquipmentId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CLASSID")) workOrderEquipmentInfo.setClassId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CATEGORYID")) workOrderEquipmentInfo.setCategory(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PREVENTWOCOMPLETION")) workOrderEquipmentInfo.setPreventWoCompletion(childNode.getTextContent());
            if (childNode.getNodeName().equals("OBJTYPE")) workOrderEquipmentInfo.setObjType(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("STATECODE")) workOrderEquipmentInfo.setStateCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("LINEARREFUOM")) workOrderEquipmentInfo.setLinearRefUom(childNode.getTextContent());
            if (childNode.getNodeName().equals("EQUIPMENTLENGTH")) workOrderEquipmentInfo.setEquipmentLength(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("GISOBJID")) workOrderEquipmentInfo.setGisObjId(childNode.getTextContent());
            if (childNode.getNodeName().equals("GISLAYER")) workOrderEquipmentInfo.setGisLayer(childNode.getTextContent());
            if (childNode.getNodeName().equals("SDMFLAG")) workOrderEquipmentInfo.setSdmFlag(childNode.getTextContent());
            if (childNode.getNodeName().equals("RELIABILITYRANKINGINDEXCODE")) workOrderEquipmentInfo.setReliabilityRankingIndexCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("RELIABILITYRANKINGID")) workOrderEquipmentInfo.setReliabilityRankingId(idSetter.setIdRevision(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("RELIABILITYRANKINGSCORE")) workOrderEquipmentInfo.setReliabilityRankingScore(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("STARTINGAT")) workOrderEquipmentInfo.setStartingAt(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LINEARDIRECTIONID")) workOrderEquipmentInfo.setLinearDirectionId(idSetter.setEntity(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ASSIGNEDTO")) workOrderEquipmentInfo.setAssignedTo(codeSetter.setCode(childNode.getChildNodes()));

        }

        return workOrderEquipmentInfo;
    }
}
