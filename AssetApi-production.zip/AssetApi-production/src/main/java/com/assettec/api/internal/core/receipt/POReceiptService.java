package com.assettec.api.internal.core.receipt;

import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.core.receipt.packingSlip.PackingSlip;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.receipt.utilities.POReceiptUpdater;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.internal.utilities.common.XMLParser;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class POReceiptService {

    private POReceiptUpdater poReceiptUpdater;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;

    @SneakyThrows
    public List<POReceipt> getReceiptsByPurchaseOrder(ApiUser apiUser, String code) {
        String postRequest, response, host = XMLParser.getInforHost();

        postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "SSRECV", "SSRECV","purchaseordercode",code,"=");
        response = requestSender.sendPostRequest(postRequest,host);

        List<Row> rows = gridService.getRows(response);
        List<POReceipt> poReceiptList = new ArrayList<>();

        for (Row row: rows) {
            String poReceiptCode = gridService.getDataByName("receiptcode",row);
            String poReceiptOrganization = gridService.getDataByName("receiptorganization",row);

            POReceipt poReceipt = getPOReceipt(apiUser,poReceiptCode,poReceiptOrganization);
            poReceipt.setPackingSlips(getPackingSlipLines(apiUser,poReceipt));
            poReceiptList.add(poReceipt);
        }

        return poReceiptList;
    }

    public POReceipt getPOReceipt(ApiUser apiUser, String poReceiptCode, String organization) {
        return poReceiptUpdater.getPOReceipt(apiUser, poReceiptCode, organization);
    }

    public List<PackingSlip> getPackingSlipLines(ApiUser apiUser, POReceipt poReceipt) {
        return poReceiptUpdater.getPackingSlipLines(apiUser,poReceipt);
    }
}
