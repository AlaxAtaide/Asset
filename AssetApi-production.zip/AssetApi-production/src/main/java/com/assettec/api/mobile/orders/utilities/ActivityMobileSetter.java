package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.ActivityMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class ActivityMobileSetter {
    public void setActivity(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        ActivityMobile activity = new ActivityMobile();

        activity.setActivityCode(workOrder.getActivities() == null
                || workOrder.getActivities().getActivityId() == null
                || workOrder.getActivities().getActivityId().getCode() == null
                ? "" : workOrder.getActivities().getActivityId().getCode());

        activity.setTradeCode(workOrder.getActivities() == null
                || workOrder.getActivities().getTradeId() == null
                || workOrder.getActivities().getTradeId().getCode() == null
                ? "" : workOrder.getActivities().getTradeId().getCode());

        activity.setTaskCode(workOrder.getActivities() == null
                || workOrder.getActivities().getTaskId() == null
                || workOrder.getActivities().getTaskId().getCode() == null
                ? "" : workOrder.getActivities().getTaskId().getCode());

        activity.setMaterialList(workOrder.getActivities() == null
                || workOrder.getActivities().getMatList() == null
                || workOrder.getActivities().getMatList().getCode() == null
                ? "" : workOrder.getActivities().getMatList().getCode());

        activity.setRepairReason(workOrder.getActivities() == null
                || workOrder.getActivities().getReasonForRepair() == null
                ? "" : workOrder.getActivities().getReasonForRepair());

        activity.setWorkAccomplished(workOrder.getActivities() == null
                || workOrder.getActivities().getWorkAccomplished() == null
                ? "" : workOrder.getActivities().getWorkAccomplished());

        activity.setTechnicianPartFailure(workOrder.getActivities() == null
                || workOrder.getActivities().getTechnicianPartFailure() == null
                ? "" : workOrder.getActivities().getTechnicianPartFailure());

        activity.setManufacturerCode(workOrder.getActivities() == null
                || workOrder.getActivities().getManufacturerId() == null
                || workOrder.getActivities().getManufacturerId().getCode() == null
                ? "" : workOrder.getActivities().getManufacturerId().getCode());

        activity.setActivityStartDate(workOrder.getActivities() == null
                || workOrder.getActivities().getStartDate() == null
                ? "" : workOrder.getActivities().getStartDate().toString(true));

        activity.setActivityEndDate(workOrder.getActivities() == null
                || workOrder.getActivities().getEndDate() == null
                ? "" : workOrder.getActivities().getEndDate().toString(true));

        activity.setEstimatedHours(workOrder.getActivities() == null
                || workOrder.getActivities().getEstimatedHours() == null
                ? "" : workOrder.getActivities().getEstimatedHours());

        activity.setHoursRemaining(workOrder.getActivities() == null
                || workOrder.getActivities().getHoursRemaining() == null
                ? "" : workOrder.getActivities().getHoursRemaining());

        activity.setPersons(workOrder.getActivities() == null
                || workOrder.getActivities().getPersons() == null
                ? "" : workOrder.getActivities().getPersons());

        activity.setSystemLevel(workOrder.getActivities() == null
                || workOrder.getActivities().getLevel() == null
                || workOrder.getActivities().getLevel().getCode() == null
                ? "" : workOrder.getActivities().getLevel().getCode());

        activity.setAssemblyLevel(workOrder.getActivities() == null
                || workOrder.getActivities().getLevel() == null
                || workOrder.getActivities().getLevel().getCode() == null
                ? "" : workOrder.getActivities().getLevel().getCode());

        activity.setComponentLevel(workOrder.getActivities() == null
                || workOrder.getActivities().getLevel() == null
                || workOrder.getActivities().getLevel().getCode() == null
                ? "" : workOrder.getActivities().getLevel().getCode());

        activity.setPartLocation(workOrder.getActivities() == null
                || workOrder.getActivities().getPartLocationCode() == null
                ? "" : workOrder.getActivities().getPartLocationCode());


        workOrderDetails.setActivity(activity);
    }
}
