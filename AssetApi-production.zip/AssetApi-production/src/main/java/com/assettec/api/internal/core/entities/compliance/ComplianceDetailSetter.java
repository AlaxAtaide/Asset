package com.assettec.api.internal.core.entities.compliance;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ComplianceDetailSetter {

    public ComplianceDetail setComplianceDetail(NodeList childNodes) {
        ComplianceDetail complianceDetail = new ComplianceDetail();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("ABOVECEILINGPERMIT")) complianceDetail.setAboveCeilingPermit(childNode.getTextContent());
            if (childNode.getNodeName().equals("INTERIMLIFESAFETY")) complianceDetail.setInterimLifeSafety(childNode.getTextContent());
            if (childNode.getNodeName().equals("INTERIMINFECTIONCONTROL")) complianceDetail.setInterimInfectionControl(childNode.getTextContent());
            if (childNode.getNodeName().equals("PRECONSTRUCTIONRISKASSESSMENT")) complianceDetail.setPreConstructionRiskAssessment(childNode.getTextContent());
            if (childNode.getNodeName().equals("PLANIMPROVEMENT")) complianceDetail.setPlanImprovement(childNode.getTextContent());
            if (childNode.getNodeName().equals("STATEMENTOFCOND")) complianceDetail.setStatementOfCondition(childNode.getTextContent());
            if (childNode.getNodeName().equals("BUILDMAINTPROGRAM")) complianceDetail.setBuildMainTProgram(childNode.getTextContent());
            if (childNode.getNodeName().equals("PERSONALPROTECTIVEEQUIP")) complianceDetail.setPersonalProtectiveEquipment(childNode.getTextContent());
            if (childNode.getNodeName().equals("LOCKOUT")) complianceDetail.setLockout(childNode.getTextContent());
            if (childNode.getNodeName().equals("BURNPERMIT")) complianceDetail.setBurnPermit(childNode.getTextContent());
            if (childNode.getNodeName().equals("CONFINEDSPACE")) complianceDetail.setConfinedSpace(childNode.getTextContent());
            if (childNode.getNodeName().equals("PATIENTSAFETY")) complianceDetail.setPatientSafety(childNode.getTextContent());
            if (childNode.getNodeName().equals("RECALLNOTICE")) complianceDetail.setRecallNotice(childNode.getTextContent());
            if (childNode.getNodeName().equals("SMDA")) complianceDetail.setSMDA(childNode.getTextContent());
            if (childNode.getNodeName().equals("HIPAACONFIDENTIALITY")) complianceDetail.setHipaaConfidentiality(childNode.getTextContent());

        }

        return complianceDetail;
    }
}
