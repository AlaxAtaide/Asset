package com.assettec.api.integration.IG.transactions.equipment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGFilteredEquipment {
    private String equipmentCode;
    private String equipmentStatus;
    private String equipmentDepartment;
    private String equipmentOrganization;
}
