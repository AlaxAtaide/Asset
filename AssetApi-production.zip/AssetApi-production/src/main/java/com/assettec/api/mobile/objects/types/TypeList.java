package com.assettec.api.mobile.objects.types;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TypeList {
    private int records;
    private int typeAuthRecords;
    private List<Type> list;
}
