package com.assettec.api.mobile.objects.config;

import com.assettec.api.internal.users.ApiUser;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Component
@AllArgsConstructor
public class FieldsToShowRepository {
    @SneakyThrows
    public String saveFields(FieldsToShow fields) {
        Path filePath = System.getProperty("os.name").contains("Windows") ? Paths.get(System.getProperty("user.dir"), "\\config\\mobileConfig") : Paths.get(System.getProperty("user.dir"), "/config/mobileConfig");
        File file = new File(String.valueOf(filePath));

        FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf(file));
        ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);

        outputStream.writeObject(fields);
        outputStream.flush();
        outputStream.close();
        return "Saved";
    }

    @SneakyThrows
    public FieldsToShow getFields() {
        Path filePath = System.getProperty("os.name").contains("Windows") ? Paths.get(System.getProperty("user.dir"), "\\config\\mobileConfig") : Paths.get(System.getProperty("user.dir"), "/config/mobileConfig");
        FileInputStream file = new FileInputStream(String.valueOf(filePath));
        ObjectInputStream fileInputStream = new ObjectInputStream(file);

        FieldsToShow fields = (FieldsToShow) fileInputStream.readObject();

        fileInputStream.close();
        file.close();

        return fields;
    }
}
