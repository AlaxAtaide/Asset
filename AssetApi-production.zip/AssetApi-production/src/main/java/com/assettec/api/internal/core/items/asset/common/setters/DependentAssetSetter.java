package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.DependentAsset;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class DependentAssetSetter {

    private IdSetter idSetter;
    private CodeSetter codeSetter;

    public DependentAsset setDependentAsset(NodeList childNodes) {
        DependentAsset dependentAsset = new DependentAsset();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("ID") && !childNode.getNodeName().contains("DEPARTMENT")) dependentAsset.setId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TYPE")) dependentAsset.setType(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("COSTROLLUP")) dependentAsset.setCostRollup(childNode.getTextContent());
            if (childNode.getNodeName().equals("DEPARTMENTID")) dependentAsset.setDepartment(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LOANEDTODEPARTMENTID")) dependentAsset.setLoanedToDepartment(idSetter.setId(childNode.getChildNodes()));

            if (!dependentAsset.getId().equals(new Id("", new InforEamCode("", ""), ""))) dependentAsset.setUpdatedCount(childNode.getParentNode().getAttributes().getNamedItem("recordid").getTextContent());
        }
        return dependentAsset;
    }
}
