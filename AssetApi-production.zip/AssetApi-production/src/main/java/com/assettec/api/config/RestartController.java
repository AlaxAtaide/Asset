package com.assettec.api.config;


import com.assettec.api.ApiApplication;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestartController {
    @PostMapping("/restart") @Async
    public void restart() {
        ApiApplication.restart();
    }
}
