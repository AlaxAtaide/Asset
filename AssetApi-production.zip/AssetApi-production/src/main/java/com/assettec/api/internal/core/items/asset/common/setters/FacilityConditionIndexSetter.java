package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.CurrencySetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.FacilityConditionIndex;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class FacilityConditionIndexSetter {

    private IdSetter idSetter;
    private CountSetter countSetter;
    private CodeSetter codeSetter;
    private CurrencySetter currencySetter;

    public FacilityConditionIndex setFacilityCondition(NodeList childNodes) {
        FacilityConditionIndex facilityConditionIndex = new FacilityConditionIndex();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("COSTOFNEEDEDREPAIRS")) facilityConditionIndex.setCostOfNeededRepairs(currencySetter.setCurrency(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("REPLACEMENTVALUE")) facilityConditionIndex.setReplacementValue(currencySetter.setCurrency(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("FACILITYCONDITIONINDEX")) facilityConditionIndex.setFacilityCondition(currencySetter.setCurrency(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("UTILITYBILLLEVEL")) facilityConditionIndex.setUtilityBillLevel(childNode.getTextContent());
            if (childNode.getNodeName().equals("GASTRACKED")) facilityConditionIndex.setGasTracked(childNode.getTextContent());
            if (childNode.getNodeName().equals("FLOORAREA")) facilityConditionIndex.setFloorArea(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("FLOORAREAUOM")) facilityConditionIndex.setFloorAreaUom(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ESTIMATEDREVENUE")) facilityConditionIndex.setEstimatedRevenue(currencySetter.setCurrency(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("REGION")) facilityConditionIndex.setRegion(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("REGIONID")) facilityConditionIndex.setRegionId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PRIMARYUSE")) facilityConditionIndex.setPrimaryUse(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("YEARBUILT")) facilityConditionIndex.setYearBuilt(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SERVICELIFE")) facilityConditionIndex.setServiceLife(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ENERGYSTARELIGIBLE")) facilityConditionIndex.setEnergyStarEligible(childNode.getTextContent());
            if (childNode.getNodeName().equals("ISFACILITY")) facilityConditionIndex.setIsFacility(childNode.getTextContent());
            if (childNode.getNodeName().equals("COUNTRYID")) facilityConditionIndex.setCountry(countSetter.setCount(childNode.getChildNodes()));
        }

        return facilityConditionIndex;
    }
}
