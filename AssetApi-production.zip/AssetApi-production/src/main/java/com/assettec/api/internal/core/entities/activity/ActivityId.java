package com.assettec.api.internal.core.entities.activity;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ActivityId {
    private Id workOrderId;
    private String code;
    private String note;

    public String buildRequest(String upper, String lower, String workOrderIdUpper, String workOrderIdLower, String workOrderIdOrganizationUpper, String workOrderIdOrganizationLower, String workOrderIdCodeLabel, String workOrderIdDescriptionLabel, String workOrderIdOrganizationCodeLabel, String workOrderIdOrganizationDescriptionLabel, String activityCodeLabel, String activityNoteLabel) {

        String workOrderId = getWorkOrderId() == null ? "" : getWorkOrderId().buildRequest(workOrderIdUpper,workOrderIdLower,workOrderIdOrganizationUpper,workOrderIdOrganizationLower,workOrderIdCodeLabel,workOrderIdDescriptionLabel,workOrderIdOrganizationCodeLabel,workOrderIdOrganizationDescriptionLabel);
        String activityCode = getCode() == null ? "" : "<" + activityCodeLabel + ">" + getCode() + "</" + activityCodeLabel + ">";
        String activityNote = getNote() == null ? "" : "<" + activityNoteLabel + ">" + getNote() + "</" + activityNoteLabel + ">";

        return upper + workOrderId + activityCode + activityNote + lower;
    }
}
