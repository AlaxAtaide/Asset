package com.assettec.api.internal.core.entities.callcenter;

import com.assettec.api.internal.core.entities.basic.setter.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class CallCenterSetter {

    private IdSetter idSetter;
    private DateSetter dateSetter;
    private CodeSetter codeSetter;
    private CountSetter countSetter;
    private CurrencySetter currencySetter;

    public CallCenter setCallCenter(NodeList childNodes) {
        CallCenter callCenter = new CallCenter();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("PROVIDERID")) callCenter.setProviderId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SUPPLIERID")) callCenter.setSupplierId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SERVICECATEGORYID")) callCenter.setServiceCategoryId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SERVICEPROBLEMID")) callCenter.setServiceProblemId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("EQUIPMENTUSABILITYID")) callCenter.setEquipmentUsabilityId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PERMANENTFIXPROMISEDATE")) callCenter.setPermanentFixPromiseDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TEMPFIXPROMISEDATE")) callCenter.setTemporaryFixPromiseDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TEMPFIXDATECOMPLETED")) callCenter.setTemporaryFixDateCompleted(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("WORKADDRESS")) callCenter.setWorkAddress(childNode.getTextContent());
            if (childNode.getNodeName().equals("CASEID")) callCenter.setCaseId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CASETYPE")) callCenter.setCaseType(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DUPLICATECASEID")) callCenter.setDuplicateCaseId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CONTACTRECORDID")) callCenter.setContactRecordId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SERVICEREQUESTSTATUS")) callCenter.setServiceRequestStatus(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ORIGINATINGCASEID")) callCenter.setOriginatingCaseId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ORIGINATINGCASETASKID")) callCenter.setOriginatingCaseTaskId(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PENALTYFACTOR")) callCenter.setPenaltyFactor(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PENALTYAMOUNT")) callCenter.setPenaltyAmount(currencySetter.setCurrency(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ORGCURRENCY")) callCenter.setOrgCurrency(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CALENDARGROUPID")) callCenter.setCalendarGroup(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SDMFLAG")) callCenter.setSdmFlag(childNode.getTextContent());
            if (childNode.getNodeName().equals("ENABLESDMCHECK")) callCenter.setEnableSdmCheck(childNode.getTextContent());

        }

        return callCenter;
    }
}
