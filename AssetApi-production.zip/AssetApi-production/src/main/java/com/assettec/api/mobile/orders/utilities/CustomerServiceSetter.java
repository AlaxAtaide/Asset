package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.CustomerServiceDetailsMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class CustomerServiceSetter {
    public void setCustomerService(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        CustomerServiceDetailsMobile customerService = new CustomerServiceDetailsMobile();

        customerService.setEquipmentUsability(workOrder.getCallCenterDetail() == null ||  workOrder.getCallCenterDetail().getEquipmentUsabilityId() == null ||  workOrder.getCallCenterDetail().getEquipmentUsabilityId().getCode() == null ? "" : workOrder.getCallCenterDetail().getEquipmentUsabilityId().getCode());
        customerService.setTempFixPromiseDate(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getTemporaryFixPromiseDate() == null ? "" : workOrder.getCallCenterDetail().getTemporaryFixPromiseDate().toString(true));
        customerService.setSupplierServiceCategoryCode(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getServiceCategoryId() == null || workOrder.getCallCenterDetail().getServiceCategoryId().getCode() == null ? "" : workOrder.getCallCenterDetail().getServiceCategoryId().getCode());
        customerService.setSupplierServiceCategoryOrganization(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getServiceCategoryId() == null || workOrder.getCallCenterDetail().getServiceCategoryId().getOrganization() == null ? "" : workOrder.getCallCenterDetail().getServiceCategoryId().getOrganization().getCode());
        customerService.setProviderServiceCategoryCode(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getProviderId() == null || workOrder.getCallCenterDetail().getProviderId().getCode() == null ? "" : workOrder.getCallCenterDetail().getProviderId().getCode());
        customerService.setProviderServiceCategoryOrganization(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getProviderId() == null  || workOrder.getCallCenterDetail().getProviderId().getOrganization() == null || workOrder.getCallCenterDetail().getProviderId().getOrganization().getCode() == null ? "" : workOrder.getCallCenterDetail().getProviderId().getOrganization().getCode());
        customerService.setWorkAddress(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getWorkAddress() == null ? "" : workOrder.getCallCenterDetail().getWorkAddress());
        customerService.setPermanentFixPromisedDate(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getPermanentFixPromiseDate() == null ? "" : workOrder.getCallCenterDetail().getPermanentFixPromiseDate().toString(true));
        customerService.setTemporaryFixDateCompleted(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getTemporaryFixDateCompleted() == null ? "" : workOrder.getCallCenterDetail().getTemporaryFixDateCompleted().toString(true));
        customerService.setServiceProblemCode(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getServiceProblemId() == null ? "" : workOrder.getCallCenterDetail().getServiceProblemId().getCode());
        customerService.setServiceProblemCodeOrganization(workOrder.getCallCenterDetail() == null || workOrder.getCallCenterDetail().getServiceProblemId() == null || workOrder.getCallCenterDetail().getServiceProblemId().getOrganization() == null || workOrder.getCallCenterDetail().getServiceProblemId().getOrganization().getCode() == null ? "" : workOrder.getCallCenterDetail().getServiceProblemId().getOrganization().getCode());

        customerService.setEstimatedLaborCost(workOrder.getActivities() == null || workOrder.getActivities().getEstimatedLaborCost() == null ? "" : workOrder.getActivities().getEstimatedLaborCost().toString());
        customerService.setEstimatedMaterialCost(workOrder.getActivities() == null || workOrder.getActivities().getEstimatedMaterialCost() == null ? "" : workOrder.getActivities().getEstimatedMaterialCost().toString());
        customerService.setEstimatedMiscellaneousCost(workOrder.getActivities() == null || workOrder.getActivities().getEstimatedMiscellaneousCost() == null ? "" : workOrder.getActivities().getEstimatedMiscellaneousCost().toString());
        customerService.setEstimatedTotalCost(workOrder.getActivities() == null || workOrder.getActivities().getEstimatedTotalCost() == null ? "" : workOrder.getActivities().getEstimatedTotalCost().toString());

        workOrderDetails.setCustomerServiceDetails(customerService);
    }
}
