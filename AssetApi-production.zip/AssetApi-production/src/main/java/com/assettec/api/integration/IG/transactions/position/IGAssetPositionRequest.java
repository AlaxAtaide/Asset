package com.assettec.api.integration.IG.transactions.position;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGAssetPositionRequest {
    private String positionStatus;
    private String positionCode;
    private String oldOrganization;
    private String newOrganization;
    private String newDepartmentCode;
}
