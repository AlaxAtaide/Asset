package com.assettec.api.internal.core.entities.production;

import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ProductionDetailsSetter {

    private DateSetter dateSetter;
    private CountSetter countSetter;

    public ProductionDetails setProductionDetails(NodeList childNodes) {
        ProductionDetails productionDetails = new ProductionDetails();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("PRODUCTIONREQUESTCODE")) productionDetails.setRequestCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("PRODUCTIONREQUESTREVISION")) productionDetails.setRequestRevision(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PRODUCTIONORDER")) productionDetails.setOrder(childNode.getTextContent());
            if (childNode.getNodeName().equals("PRODUCTIONPRIORITY")) productionDetails.setPriority(childNode.getTextContent());
            if (childNode.getNodeName().equals("PRODUCTIONPRIORITYDESC")) productionDetails.setPriorityDescription(childNode.getTextContent());
            if (childNode.getNodeName().equals("PRODUCTIONSTARTDATE")) productionDetails.setStartDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PRODUCTIONENDDATE")) productionDetails.setEndDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ACCOUNTINGENTITY")) productionDetails.setAccountingEntity(childNode.getTextContent());
        }

        return productionDetails;
    }
}
