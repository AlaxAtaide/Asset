package com.assettec.api.internal.core.entities.callcenter;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCurrency;
import com.assettec.api.internal.core.entities.basic.objects.InforEamDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CallCenter {
    private Id providerId;
    private Id supplierId;
    private Id serviceCategoryId;
    private Id serviceProblemId;
    private Id equipmentUsabilityId;
    private InforEamDate permanentFixPromiseDate;
    private InforEamDate temporaryFixPromiseDate;
    private InforEamDate temporaryFixDateCompleted;
    private String workAddress;
    private Id caseId;
    private InforEamCode caseType;
    private Id duplicateCaseId;
    private Id contactRecordId;
    private InforEamCode serviceRequestStatus;
    private Id originatingCaseId;
    private InforEamCode originatingCaseTaskId;
    private InforEamCount penaltyFactor;
    private InforEamCurrency penaltyAmount;
    private InforEamCode orgCurrency;
    private Id calendarGroup;
    private String sdmFlag;
    private String enableSdmCheck;

    public String buildRequest(String upper, String lower) {

        String providerId = getProviderId() == null ? "" : getProviderId().buildRequest("<PROVIDERID xmlns=\"http://schemas.datastream.net/MP_fields\">","</PROVIDERID>","<ORGANIZATIONID entity=\"LaborRequisition\">","</ORGANIZATIONID>","PROVIDERSERVICECATEGORYCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String supplierId = getSupplierId() == null ? "" : getSupplierId().buildRequest("<SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">","</SUPPLIERID>","<ORGANIZATIONID entity=\"CustomFields\">","</ORGANIZATIONID>","SUPPLIERCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String serviceCategoryId = getServiceCategoryId() == null ? "" : getServiceCategoryId().buildRequest("<SERVICECATEGORYID xmlns=\"http://schemas.datastream.net/MP_fields\">","</SERVICECATEGORYID>","<ORGANIZATIONID entity=\"EquipmentSummary\">","</ORGANIZATIONID>","PROVIDERSERVICECATEGORYCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String serviceProblemId = getServiceProblemId() == null ? "" : getServiceProblemId().buildRequest("<SERVICEPROBLEMID xmlns=\"http://schemas.datastream.net/MP_fields\">","</SERVICEPROBLEMID>","<ORGANIZATIONID entity=\"StorePart\">","</ORGANIZATIONID>","SERVICEPROBLEMCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String equipmentUsabilityId = getEquipmentUsabilityId() == null ? "" : getEquipmentUsabilityId().buildRequest("<EQUIPMENTUSABILITYID xmlns=\"http://schemas.datastream.net/MP_fields\">","</EQUIPMENTUSABILITYID>","<ORGANIZATIONID entity=\"BinStockDefault\">","</ORGANIZATIONID>","EQUIPMENTUSABILITY","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String permanentFixPromiseDate = getPermanentFixPromiseDate() == null ? "" : getPermanentFixPromiseDate().buildRequest("<PERMANENTFIXPROMISEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</PERMANENTFIXPROMISEDATE>");
        String tempFixPromiseDate = getTemporaryFixPromiseDate() == null ? "" : getTemporaryFixPromiseDate().buildRequest("<TEMPFIXPROMISEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</TEMPFIXPROMISEDATE>");
        String tempFixDateCompleted = getTemporaryFixDateCompleted() == null ? "" : getTemporaryFixDateCompleted().buildRequest("<TEMPFIXDATECOMPLETED qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</TEMPFIXDATECOMPLETED>");
        String workAddress = getWorkAddress() == null ? "" : "<WORKADDRESS xmlns=\"http://schemas.datastream.net/MP_fields\">" + getWorkAddress() + "</WORKADDRESS>";
        String caseId = getCaseId() == null ? "" : getCaseId().buildRequest("<CASEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</CASEID>","<ORGANIZATIONID entity=\"BinStock\">","</ORGANIZATIONID>","CASECODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String caseType = getCaseType() == null ? "" : getCaseType().buildRequest("<CASETYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</CASETYPE>","TYPECODE","DESCRIPTION");
        String duplicateCaseId = getDuplicateCaseId() == null ? "" : getDuplicateCaseId().buildRequest("<DUPLICATECASEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</DUPLICATECASEID>","<ORGANIZATIONID entity=\"LocationDefault\">","</ORGANIZATIONID>","CASECODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String contactRecordId = getContactRecordId() == null ? "" : getContactRecordId().buildRequest("<CONTACTRECORDID xmlns=\"http://schemas.datastream.net/MP_fields\">","</CONTACTRECORDID>","<ORGANIZATIONID entity=\"EquipmentHierarchy\">","</ORGANIZATIONID>","CONTACTRECORDCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String serviceRequestStatus = getServiceRequestStatus() == null ? "" : getServiceRequestStatus().buildRequest("<SERVICEREQUESTSTATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</SERVICEREQUESTSTATUS>","STATUSCODE","DESCRIPTION");
        String originatingCaseId = getOriginatingCaseId() == null ? "" : getOriginatingCaseId().buildRequest("<ORIGINATINGCASEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</ORIGINATINGCASEID>","<ORGANIZATIONID entity=\"PositionHierarchy\">","</ORGANIZATIONID>","CASECODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String originatingCaseTaskId = getOriginatingCaseTaskId() == null ? "" : getOriginatingCaseTaskId().buildRequest("<ORIGINATINGCASETASKID xmlns=\"http://schemas.datastream.net/MP_fields\">","</ORIGINATINGCASETASKID>","CASETASKCODE","DESCRIPTION");

        return upper + providerId + supplierId + serviceCategoryId + serviceProblemId + equipmentUsabilityId +
                permanentFixPromiseDate + tempFixPromiseDate + tempFixDateCompleted + workAddress + caseId + caseType +
                duplicateCaseId + contactRecordId + serviceRequestStatus + originatingCaseId + originatingCaseTaskId + lower;
    }
}
