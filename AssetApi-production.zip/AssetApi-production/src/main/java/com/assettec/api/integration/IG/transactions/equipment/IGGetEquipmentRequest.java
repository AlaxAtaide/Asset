package com.assettec.api.integration.IG.transactions.equipment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGGetEquipmentRequest {
    private String username;
    private String tenant;
    private String userOrganization;
    private String userPassword;

    private String equipmentCode;
}
