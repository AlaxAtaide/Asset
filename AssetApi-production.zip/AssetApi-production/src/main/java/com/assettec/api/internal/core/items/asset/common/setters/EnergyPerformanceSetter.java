package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.objects.InforEamDate;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import com.assettec.api.internal.core.items.asset.common.objects.EnergyPerformance;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class EnergyPerformanceSetter {

    private CountSetter countSetter;
    private CodeSetter codeSetter;
    private DateSetter dateSetter;

    public EnergyPerformance setEnergyPerformance(NodeList childNodes) {
        EnergyPerformance energyPerformance = new EnergyPerformance(new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCount("","","",""),new InforEamCode("",""), new InforEamCode("",""),new InforEamDate("","","","","","","",""));

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("TARGETPOWERFACTOR")) energyPerformance.setTargetPowerFactor(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TARGETPEAKDEMAND")) energyPerformance.setTargetPeakDemand(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("BILLINGPERIODSTARTDATE")) energyPerformance.setBillingPeriodStartDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("BILLEVERYPERIOD")) energyPerformance.setBillEveryPeriod(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("BILLEVERYUOM")) energyPerformance.setBillEveryUom(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PHASEIMBALANCEEFFICIENCYLOSS1")) energyPerformance.setPhaseInBalanceEfficiencyLost1(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PHASEIMBALANCEEFFICIENCYLOSS2")) energyPerformance.setPhaseInBalanceEfficiencyLost2(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PHASEIMBALANCEEFFICIENCYLOSS3")) energyPerformance.setPhaseInBalanceEfficiencyLost3(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PHASEIMBALANCEEFFICIENCYLOSS4")) energyPerformance.setPhaseInBalanceEfficiencyLost4(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PHASEIMBALANCEEFFICIENCYLOSS5")) energyPerformance.setPhaseInBalanceEfficiencyLost5(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PERFORMANCEMANAGER")) energyPerformance.setPerformanceManager(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ELECTRICSUBMETERINTERVAL")) energyPerformance.setElectricSubMeterInterval(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("ELECTRICUSAGETHRESHOLD")) energyPerformance.setElectricUsageThreshold(countSetter.setCount(childNode.getChildNodes()));
        }

        return energyPerformance;
    }
}
