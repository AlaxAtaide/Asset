package com.assettec.api.integration.IG.controllers.orders.purchase.send;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGSendPurchaseOrderList {
    private String http;
    private String message;
    private List<IGSendPurchaseOrder> sendPurchaseOrderList;
}
