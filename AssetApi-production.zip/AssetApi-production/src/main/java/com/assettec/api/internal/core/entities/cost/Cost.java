package com.assettec.api.internal.core.entities.cost;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Cost {
    private String code;
    private String description;
    private String organization;
}
