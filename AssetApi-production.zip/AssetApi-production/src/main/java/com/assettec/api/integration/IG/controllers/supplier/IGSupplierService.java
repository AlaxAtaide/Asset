package com.assettec.api.integration.IG.controllers.supplier;

import com.assettec.api.internal.core.entities.supplier.Supplier;
import com.assettec.api.internal.core.entities.supplier.SupplierService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.Validator;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@AllArgsConstructor
public class IGSupplierService {

    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private SupplierService supplierService;
    private IGPostSupplierRequestBuilder igPostSupplierRequestBuilder;

    @SneakyThrows
    public IGSupplier registerSupplier(ApiUser apiUser, IGSupplier request) {
        if (request.getSupplierCode() == null || request.getSupplierCode().isEmpty())
            throw new IllegalStateException("supplierCode não pode ser nulo ou estar em branco.");
        if (request.getSupplierName() == null || request.getSupplierName().isEmpty())
            throw new IllegalStateException("supplierName não pode ser nulo ou estar em branco.");

        if (request.getCurrency() == null || request.getCurrency().isEmpty()) request.setCurrency("BRL");
        if (request.getLanguage() == null || request.getLanguage().isEmpty()) request.setLanguage("PT");
        if (request.getCnpj() == null || request.getCnpj().isEmpty()) request.setCnpj("");
        if (request.getContactEmail() == null || request.getContactEmail().isEmpty()) request.setContactEmail("");
        if (request.getContactPhone() == null || request.getContactPhone().isEmpty()) request.setContactPhone("");
        else Validator.validateNumber(request.getContactPhone());
        if (request.getContactAddress1() == null || request.getContactAddress1().isEmpty()) request.setContactAddress1("");
        if (request.getContactAddress2() == null || request.getContactAddress2().isEmpty()) request.setContactAddress2("");
        if (request.getContactCity() == null || request.getContactCity().isEmpty()) request.setContactCity("");
        if (request.getContactState() == null || request.getContactState().isEmpty()) request.setContactState("");
        if (request.getContactCEP() == null || request.getContactCEP().isEmpty()) request.setContactCEP("");
        if (request.getContactName() == null || request.getContactName().isEmpty()) request.setContactName("");

        Supplier supplier = supplierService.getSupplier(apiUser, request);
        String host = XMLParser.getInforHost();
        String postRequest, response;

        if (supplier.getCode() == null || !supplier.getCode().equals(request.getSupplierCode())) {
            postRequest = igPostSupplierRequestBuilder.postIGSupplier(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*", request.getSupplierName(), request.getLanguage(), request.getCurrency(), request.getCnpj());
            requestSender.sendPostRequest(postRequest, host);
        }

        if (!Objects.equals(request.getContactName(), "")){
            int sequenceNumber = 1;
            String supplierContact = supplierService.getContact(apiUser, request, sequenceNumber);
            postRequest = requestBuilder.getSupplierRequestBuilder().postSupplierContact(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*", sequenceNumber, request.getContactName(), request.getContactPhone(), "PHON", "", request.getContactEmail(), request.getContactAddress1(), request.getContactAddress2(), request.getContactCity(), request.getContactState(), request.getContactCEP(), "", "", "");
            response = requestSender.sendPostRequest(postRequest, host);

            while (response.equals("registry already in use")) {
                if (supplierContact.equals(request.getContactName()))
                    throw new IllegalStateException("supplierContact already registered");

                sequenceNumber += 1;
                postRequest = requestBuilder.getSupplierRequestBuilder().postSupplierContact(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*", sequenceNumber, request.getContactName(), request.getContactPhone(), "PHON", "", request.getContactEmail(), request.getContactAddress1(), request.getContactAddress2(), request.getContactCity(), request.getContactState(), request.getContactCEP(), "", "", "");
                response = requestSender.sendPostRequest(postRequest, host);
                supplierContact = supplierService.getContact(apiUser, request, sequenceNumber);
            }
        }

        String fullAddress = "";

        if (!request.getContactAddress1().isEmpty()) fullAddress = request.getContactAddress1();
        if (!request.getContactAddress2().isEmpty() && !request.getContactAddress1().isEmpty()) fullAddress = fullAddress + ", " + request.getContactAddress2();
        else if (request.getContactAddress1().isEmpty()) fullAddress = request.getContactAddress2();
        if (!request.getContactCity().isEmpty()) fullAddress = fullAddress + " - " + request.getContactCity();
        else if (request.getContactAddress1().isEmpty() && request.getContactAddress2().isEmpty()) fullAddress = request.getContactCity();
        if (!request.getContactState().isEmpty()) fullAddress = fullAddress + " - " + request.getContactState();
        else if (request.getContactCity().isEmpty()) fullAddress = request.getContactState();
        if (!request.getContactCEP().isEmpty()) fullAddress = fullAddress + " - " + request.getContactCEP();
        else if (request.getContactState().isEmpty()) fullAddress = request.getContactCEP();

        if (!fullAddress.isEmpty()) {
            postRequest = requestBuilder.getSupplierRequestBuilder().postSupplierAddress(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*", "COMP", "M", fullAddress, request.getContactPhone());
            requestSender.sendPostRequest(postRequest, host);
        }

        if (Objects.equals(request.getContactName(), "") && fullAddress.equals("") && supplier.getCode() != null && supplier.getCode().equals(request.getSupplierCode())) throw new IllegalStateException("Supplier already registered");

        request.setMessage("Transação realizada com sucesso.");
        request.setHttp("200");
        return request;
    }

}
