package com.assettec.api.integration.technip.alerts;

import com.assettec.api.internal.core.installationcode.InstallationCodeService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class AlertsController {

    private AlertsService alertsService;
    private InstallationCodeService installationCodeService;

    @SneakyThrows @Async
    @Scheduled(cron = "00 00 06 * * ?")
    public void sendAlertEmail() {
        alertsService.sendAlertsEmails();
    }

}
