package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerServiceDetailsMobile {
    private String equipmentUsability;
    private String tempFixPromiseDate;
    private String supplierServiceCategoryCode;
    private String supplierServiceCategoryOrganization;
    private String providerServiceCategoryCode;
    private String providerServiceCategoryOrganization;
    private String workAddress;
    private String estimatedLaborCost;
    private String estimatedMaterialCost;
    private String estimatedMiscellaneousCost;
    private String estimatedTotalCost;
    private String permanentFixPromisedDate;
    private String temporaryFixDateCompleted;
    private String serviceProblemCode;
    private String serviceProblemCodeOrganization;

    public static CustomerServiceDetailsMobile createEmpty() {
        return new CustomerServiceDetailsMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
