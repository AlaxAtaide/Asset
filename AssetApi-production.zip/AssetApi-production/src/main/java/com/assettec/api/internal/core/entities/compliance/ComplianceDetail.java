package com.assettec.api.internal.core.entities.compliance;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceDetail {
    private String aboveCeilingPermit;
    private String interimLifeSafety;
    private String interimInfectionControl;
    private String preConstructionRiskAssessment;
    private String planImprovement;
    private String statementOfCondition;
    private String buildMainTProgram;
    private String personalProtectiveEquipment;
    private String Lockout;
    private String burnPermit;
    private String confinedSpace;
    private String patientSafety;
    private String recallNotice;
    private String SMDA;
    private String hipaaConfidentiality;
}
