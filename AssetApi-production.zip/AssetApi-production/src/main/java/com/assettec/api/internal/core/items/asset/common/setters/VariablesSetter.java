package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.items.asset.common.objects.Variables;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class VariablesSetter {
    public void setVariables(AssetEquipment asset, NodeList childNodes) {

        asset.setVariable1("");
        asset.setVariable2("");
        asset.setVariable3("");
        asset.setVariable4("");
        asset.setVariable5("");
        asset.setVariable6("");

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("VARIABLE1")) asset.setVariable1(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE2")) asset.setVariable2(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE3")) asset.setVariable3(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE4")) asset.setVariable4(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE5")) asset.setVariable5(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE6")) asset.setVariable6(childNode.getTextContent());
        }
    }

    public Variables setVariables(NodeList childNodes) {
        Variables variables = new Variables();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("VARIABLE1")) variables.setVariable1(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE2")) variables.setVariable2(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE3")) variables.setVariable3(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE4")) variables.setVariable4(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE5")) variables.setVariable5(childNode.getTextContent());
            if (childNode.getNodeName().equals("VARIABLE6")) variables.setVariable6(childNode.getTextContent());
        }
        return variables;
    }
}
