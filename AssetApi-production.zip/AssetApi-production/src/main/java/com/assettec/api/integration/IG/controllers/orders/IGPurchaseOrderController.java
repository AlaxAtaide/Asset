package com.assettec.api.integration.IG.controllers.orders;

import com.assettec.api.integration.IG.controllers.orders.purchase.IGPurchaseOrder;
import com.assettec.api.integration.IG.controllers.orders.purchase.send.IGSendPurchaseOrderList;
import com.assettec.api.integration.IG.controllers.orders.purchase.send.IGSendPurchaseOrderWithCode;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "purchase")
@AllArgsConstructor
public class IGPurchaseOrderController {

    private IGPurchaseOrderService igPurchaseOrderService;
    private ApiUserService apiUserService;

    // post para aprovar ordem de compra
    @PostMapping(path = "confirmSent")
    public IGSendPurchaseOrderWithCode confirmSentPurchaseOrder(@RequestParam(name = "token") String token, @RequestBody IGPurchaseOrder request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo: mudar status
        return new IGSendPurchaseOrderWithCode("200","Transação realizada com sucesso.",igPurchaseOrderService.confirmSentPurchaseOrder(apiUser,igPurchaseOrderService.returnPurchaseOrdersByStatus(apiUser,"R"),request));
    }

    @GetMapping() @SneakyThrows @Async
    public CompletableFuture<IGSendPurchaseOrderList> returnPurchaseOrder(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo: mudar status
        return CompletableFuture.completedFuture(new IGSendPurchaseOrderList("200","Transação realizada com sucesso.",igPurchaseOrderService.returnPurchaseOrdersByStatus(apiUser,"R")));
    }

    // get de ordem de compras enviadas
    @GetMapping(path = "getSent") @SneakyThrows @Async
    public CompletableFuture<IGSendPurchaseOrderList> returnSentPurchaseOrder(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        //todo: mudar status
        return CompletableFuture.completedFuture(new IGSendPurchaseOrderList("200","Transação realizada com sucesso.",igPurchaseOrderService.returnPurchaseOrdersByStatus(apiUser,"A")));
    }
}
