package com.assettec.api.internal.core.receipt.packingSlip;

import com.assettec.api.internal.core.entities.basic.setter.*;
import com.assettec.api.internal.utilities.common.XMLParser;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class PackingSlipUpdater {
    private XMLParser xmlParser;
    private IdSetter idSetter;
    private CodeSetter codeSetter;
    private DateSetter dateSetter;
    private CountSetter countSetter;
    private CurrencySetter currencySetter;

    @SneakyThrows
    public PackingSlip updatePackingSlip(String response) {
        Document xmlData = xmlParser.toDocument(response);
        Node resultData = xmlData.getElementsByTagName("ResultData").item(0);
        PackingSlip packingSlip = new PackingSlip();

        for (int i = 0; i < resultData.getChildNodes().getLength(); i++) {
            Node packingSlipNodes = resultData.getChildNodes().item(i);
            String nodeName = packingSlipNodes.getNodeName();

            if (nodeName.equals("PackingSlip")) packingSlip = setPackingSlip(packingSlipNodes.getChildNodes());
        }
        return packingSlip;
    }

    private PackingSlip setPackingSlip(NodeList childNodes) {
        PackingSlip packingSlip = new PackingSlip();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            String nodeName = childNode.getNodeName();

            if (nodeName.equals("PACKINGSLIPID")) packingSlip.setPackingSlipId(idSetter.setIdLineNum(childNode.getChildNodes()));
            if (nodeName.equals("PURCHASEORDERLINEID")) packingSlip.setPurchaseOrderLineId(idSetter.setIdLineNum(childNode.getChildNodes()));
            if (nodeName.equals("PARTID")) packingSlip.setPartId(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("PACKINGSLIPMANLOT")) packingSlip.setPackingSlipManLot(childNode.getTextContent());
            if (nodeName.equals("PACKINGSLIPMANLOTEXP")) packingSlip.setPackingSlipManLotExp(dateSetter.setDate(childNode.getChildNodes()));
            if (nodeName.equals("SUPPLIERREFERENCE")) packingSlip.setSupplierReference(childNode.getTextContent());
            if (nodeName.equals("UOMID")) packingSlip.setUomId(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("PACKINGSLIPDELQTY")) packingSlip.setDeliveredQuantity(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("PACKINGSLIPRECVQTY")) packingSlip.setReceivedQuantity(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("CONVERSIONFACTOR")) packingSlip.setConversionFactor(currencySetter.setCurrency(childNode.getChildNodes()));
            if (nodeName.equals("PACKINGSLIPCOMMENT")) packingSlip.setComment(childNode.getTextContent());
            if (nodeName.equals("OUTSTANDINGQTY")) packingSlip.setOutstandingQuantity(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("PURCHASEUOM")) packingSlip.setPurchaseUom(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("PARTUOM")) packingSlip.setPartUom(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("PENDINGQTY")) packingSlip.setPendingQuantity(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("QTYPERUOP")) packingSlip.setQuantityPerUop(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("PARTCONDITIONTEMPLATECONDITIONCODE")) packingSlip.setPartConditionTemplateCode(childNode.getTextContent());
        }

        return packingSlip;
    }
}
