package com.assettec.api.internal.utilities.common;

import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class Validator {
    public static void checkLimit(String string, int limit) {
        if (string.length() > limit) throw new IllegalStateException(string + " has exceeded it's limit: " + limit);
    }

    public static void checkLimit(int i, int limit) {
        String integers = String.valueOf(i);
        if (integers.length() > limit) throw new IllegalStateException("integers: " + integers + " has exceeded it's limit: " + limit);
    }

    public static void checkLimit(double d, int intLimit, int digLimit) {
        String[] dou = String.valueOf(d).split("\\.");
        String integers = dou[0];
        String digits = dou[1];

        if (integers.length() > intLimit) throw new IllegalStateException("integers: " + integers + " has exceeded it's limit: " + intLimit);
        if (digits.length() > digLimit) throw new IllegalStateException("digits: " + digits + " has exceeded it's limit: " + digLimit);
    }

    public static void validateNumber(String phone){
        long number = -99999L;
        phone = phone.replace("(","").replace(")","").replace("+","").replace(" ","").replace("-","");
        try {
            number = Long.parseLong(phone);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        if (number == -99999) throw new IllegalStateException("Phone Number is invalid: " + phone + " supported phoneNumber formatting examples: +12 (12) 12345-1234, 12 12 12345 1234, 12121234123451234.");
    }
}
