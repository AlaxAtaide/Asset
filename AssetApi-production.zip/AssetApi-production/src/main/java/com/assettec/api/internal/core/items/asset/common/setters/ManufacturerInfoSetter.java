package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.ManufacturerInfo;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ManufacturerInfoSetter {

    private CountSetter countSetter;
    private CodeSetter codeSetter;

    public void setManufacturerInfo(AssetEquipment asset, NodeList childNodes) {
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            String nodeName = childNode.getNodeName();

            if (nodeName.equals("MANUFACTURERCODE")) asset.setManufacturerCode(childNode.getTextContent());
            if (nodeName.equals("SERIALNUMBER")) asset.setSerialnumber(childNode.getTextContent());
            if (nodeName.equals("MODEL")) asset.setModel(childNode.getTextContent());
            if (nodeName.equals("MODELREVISION")) asset.setModelRevision(childNode.getTextContent());
            if (nodeName.equals("XCOORDINATE")) asset.setXCoordinate(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("YCOORDINATE")) asset.setYCoordinate(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("ZCOORDINATE")) asset.setZCoordinate(countSetter.setCount(childNode.getChildNodes()));
        }
    }

    public ManufacturerInfo setManufacturerInfo(NodeList childNodes) {
        ManufacturerInfo manufacturerInfo = new ManufacturerInfo();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            String nodeName = childNode.getNodeName();

            if (nodeName.equals("MANUFACTURERCODE")) manufacturerInfo.setManufacturerCode(childNode.getTextContent());
            if (nodeName.equals("SERIALNUMBER")) manufacturerInfo.setSerialNumber(childNode.getTextContent());
            if (nodeName.equals("MODEL")) manufacturerInfo.setModel(childNode.getTextContent());
            if (nodeName.equals("MODELREVISION")) manufacturerInfo.setModelRevision(childNode.getTextContent());
            if (nodeName.equals("HARDWAREVER")) manufacturerInfo.setHardwareVersion(childNode.getTextContent());
            if (nodeName.equals("SOFTWAREVER")) manufacturerInfo.setSoftwareVersion(childNode.getTextContent());
            if (nodeName.equals("PURCHASINGASSET")) manufacturerInfo.setPurchasingAsset(childNode.getTextContent());
            if (nodeName.equals("BIOMEDICALASSET")) manufacturerInfo.setBioMedicalAsset(childNode.getTextContent());
            if (nodeName.equals("UMDNS")) manufacturerInfo.setUmdNs(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("OEMSITE")) manufacturerInfo.setOemSite(childNode.getTextContent());
            if (nodeName.equals("VENDOR")) manufacturerInfo.setVendor(childNode.getTextContent());
            if (nodeName.equals("COVERAGETYPE")) manufacturerInfo.setCoverageType(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("XCOORDINATE")) manufacturerInfo.setXCoordinate(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("YCOORDINATE")) manufacturerInfo.setYCoordinate(countSetter.setCount(childNode.getChildNodes()));
            if (nodeName.equals("ZCOORDINATE")) manufacturerInfo.setZCoordinate(countSetter.setCount(childNode.getChildNodes()));
        }
        return manufacturerInfo;
    }
}
