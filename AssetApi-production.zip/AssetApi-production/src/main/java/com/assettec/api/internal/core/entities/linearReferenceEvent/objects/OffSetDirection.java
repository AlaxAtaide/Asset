package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OffSetDirection {
    private String uCodeEntity;
    private String uCode;
    private String description;

    public String buildRequest() {
        if ((uCodeEntity == null || uCodeEntity.isEmpty()) && (uCode == null || uCode.isEmpty()) && (description == null || description.isEmpty())) return "";

        String uCodeEntityString = uCodeEntity == null || uCodeEntity.isEmpty() ? "" : "<UCODEENTITY>" + uCodeEntity + "</UCODEENTITY>";
        String uCodeString = uCode == null || uCode.isEmpty() ? "" : "<UCODE>" + uCode + "</UCODE>";
        String descriptionString = description == null || description.isEmpty() ? "" : "<DESCRIPTION>" + description + "</DESCRIPTION>";

        return uCodeEntityString + uCodeString + descriptionString;
    }
}
