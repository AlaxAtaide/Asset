package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PurchaseOrderRequestBuilder {

    private XMLRequestHeader xmlRequestHeader;

    public String getPurchaseOrder(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0413_GetPurchaseOrder_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"PurchaseOrder\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0413_001\">\n" +
                "            <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PURCHASEORDERID>\n" +
                "        </MP0413_GetPurchaseOrder_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postPurchaseOrder(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, String purchaseOrderDescription, String purchaseOrderStatusCode, String purchaseOrderType, String supplierCode, String supplierOrganization, String storeCode, String originatorCode, String exchangeValue, String exchangeCurrency, String currency, int dueDateYear, int dueDateMonth, int dueDateDay, int orderDateYear, int orderDateMonth, int orderDateDay, String paymentTerm, String paymentMethod, String timeZone) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0414_AddPurchaseOrder_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" autoid=\"true\" verb=\"Add\" noun=\"PurchaseOrder\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0414_001\">\n" +
                "            <PurchaseOrder recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/PurchaseOrder_001\">\n" +
                "                <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + purchaseOrderDescription + "</DESCRIPTION>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + purchaseOrderStatusCode + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                </STOREID>\n" +
                "                <DUEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DUEDATE>\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "                <CURRENCYCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + currency + "</CURRENCYCODE> \n" +
                "                <EXCHANGE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </EXCHANGE>\n" +
                "                <ORDERDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">00</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">00</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">00</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">00</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </ORDERDATE>\n" +
                "                <TYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + purchaseOrderType + "</TYPECODE>\n" +
                "                </TYPE>\n" +
                "                <ORIGINATOR xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PERSONCODE>" + originatorCode + "</PERSONCODE>\n" +
                "                </ORIGINATOR>\n" +
                "                <PAYMENTTERM ordertermtype=\"PAY\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                        <ORDERTERMCODE>" + paymentTerm + "</ORDERTERMCODE> \n" +
                "                    </ORDERTERMID>\n" +
                "                </PAYMENTTERM>\n" +
                "                <PAYBYMETHOD ordertermtype=\"PYMT\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                        <ORDERTERMCODE>" + paymentMethod + "</ORDERTERMCODE> \n" +
                "                    </ORDERTERMID>\n" +
                "                </PAYBYMETHOD>\n" +
                "            </PurchaseOrder>\n" +
                "        </MP0414_AddPurchaseOrder_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPurchaseOrder(String userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, String purchaseOrderDescription, String purchaseOrderStatusCode, String purchaseOrderType, String supplierCode, String supplierOrganization, String storeCode, String originatorCode, String attentionTo, String exchangeValue, String exchangeDecimals, String exchangeCurrency, String currency, int dueDateYear, int dueDateMonth, int dueDateDay, int orderDateYear, int orderDateMonth, int orderDateDay, int orderDateHour, int orderDateMinute, int orderDateSecond, int orderDateSubSecond, String timeZone, String userDefinedString, int updatedCount, String sentToIG, String buyerCode, String defaultApproverCode, String paymentTerm, String paymentMethod, String delAddressCode, String shipViaCode, String shipViaOrganization, String fobPointCode, String fobPointOrganization, String freightTermCode, String freightTermOrganization, String originatorName, String classCode, String classOrganization) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0415_SyncPurchaseOrder_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"PurchaseOrder\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0415_001\">\n" +
                "            <PurchaseOrder recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/PurchaseOrder_001\">\n" +
                "                <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE>\n" +
                "                    <ORGANIZATIONID>\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + purchaseOrderDescription + "</DESCRIPTION>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <CLASSID entity=\"ent1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CLASSCODE>" + classCode + "</CLASSCODE> \n" +
                "                    <ORGANIZATIONID entity=\"Organization\">\n" +
                "                        <ORGANIZATIONCODE>" + classOrganization + "</ORGANIZATIONCODE> \n" +
                "                    </ORGANIZATIONID>\n" +
                "                </CLASSID>\n" +
                "                <STATUS xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + purchaseOrderStatusCode + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                </STOREID>\n" +
                "                <DUEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DUEDATE>\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID>\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "                <CURRENCYCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + currency + "</CURRENCYCODE>\n" +
                "                <EXCHANGE qualifier=\"ACTUAL\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeDecimals + "</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </EXCHANGE>\n" +
                "                <ORDERDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateHour + "</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateMinute + "</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateSecond + "</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + orderDateSubSecond + "</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </ORDERDATE>\n" +
                "                <TYPE xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + purchaseOrderType + "</TYPECODE>\n" +
                "                </TYPE>\n" +
                "                <BUYER xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                     <USERCODE>" + buyerCode + "</USERCODE> \n" +
                "                </BUYER>\n" +
                "                <ATTENTIONTO xmlns:ns52=\"http://schemas.datastream.net/MP_fields\">" + attentionTo + "</ATTENTIONTO>\n" +
                "                <DEFAULTAPPROVER xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <USERCODE>"+ defaultApproverCode +"</USERCODE>\n" +
                "                </DEFAULTAPPROVER>\n"+
                "                <PAYMENTTERM ordertermtype=\"PAY\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                        <ORDERTERMCODE>" + paymentTerm + "</ORDERTERMCODE> \n" +
                "                    </ORDERTERMID>\n" +
                "                </PAYMENTTERM>\n" +
                "                <PAYBYMETHOD ordertermtype=\"PYMT\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                        <ORDERTERMCODE>" + paymentMethod + "</ORDERTERMCODE> \n" +
                "                    </ORDERTERMID>\n" +
                "                </PAYBYMETHOD>\n" +
                "                <SHIPVIA ordertermtype=\"SHIP\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                       <ORDERTERMCODE>"+ shipViaCode +"</ORDERTERMCODE>\n" +
                "                       <ORGANIZATIONID entity=\"OrganizationValidity\">\n" +
                "                           <ORGANIZATIONCODE>"+shipViaOrganization+"</ORGANIZATIONCODE> \n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </ORDERTERMID>\n" +
                "                </SHIPVIA>\n"+
                "                <FOBPOINT ordertermtype=\"FOB\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                        <ORDERTERMCODE>"+fobPointCode+"</ORDERTERMCODE>\n" +
                "                        <ORGANIZATIONID entity=\"Equipment\">\n" +
                "                            <ORGANIZATIONCODE>"+fobPointOrganization+"</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </ORDERTERMID>\n" +
                "                </FOBPOINT>\n" +
                "                <FREIGHTTERM ordertermtype=\"FRTR\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <ORDERTERMID>\n" +
                "                         <ORDERTERMCODE>" + freightTermCode + "</ORDERTERMCODE> \n" +
                "                             <ORGANIZATIONID entity=\"Personnel\">\n" +
                "                                  <ORGANIZATIONCODE>" + freightTermOrganization + "</ORGANIZATIONCODE> \n" +
                "                              </ORGANIZATIONID>\n" +
                "                    </ORDERTERMID>\n" +
                "                 </FREIGHTTERM>\n"+
                "                <ORIGINATOR xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PERSONCODE>" + originatorCode + "</PERSONCODE> \n" +
                "                    <DESCRIPTION>" + originatorName + "</DESCRIPTION> \n" +
                "                </ORIGINATOR>\n" +
                "                <DELADDRESSCODE xmlns=\"http://schemas.datastream.net/MP_fields\">"+ delAddressCode +"</DELADDRESSCODE>\n"+
                "                <UserDefinedFields>\n" +
                "                    <UDFCHAR30 xmlns=\"http://schemas.datastream.net/MP_fields\">" + userDefinedString + "</UDFCHAR30>\n" +
                "                    <UDFCHKBOX05 xmlns=\"http://schemas.datastream.net/MP_fields\">" + sentToIG + "</UDFCHKBOX05>\n" +
                "                </UserDefinedFields>\n" +
                "            </PurchaseOrder>\n" +
                "        </MP0415_SyncPurchaseOrder_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deletePurchaseOrder(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0420_DeletePurchaseOrder_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"PurchaseOrder\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0420_001\">\n" +
                "            <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PURCHASEORDERID>\n" +
                "        </MP0420_DeletePurchaseOrder_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String getPurchaseOrderPart(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, String lineNum) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0422_GetPartForPO_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"PartForPO\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0422_001\">\n" +
                "            <PURCHASEORDERLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <PURCHASEORDERLINENUM>" + lineNum + "</PURCHASEORDERLINENUM>\n" +
                "            </PURCHASEORDERLINEID>\n" +
                "        </MP0422_GetPartForPO_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postPurchaseOrderPart(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, int partLineNum, String purchaseOrderType, String purchaseStatus, String partCode, String partOrganization, int purchaseQuantity, String partQuantity, String purchaseUnitOfMetric, String partUnitOfMetric, String conversionValue, String price, String exchangeValue, String conversionCurrency, String priceCurrency, String currency, int dueDateYear, int dueDateMonth, int dueDateDay, String timeZone) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0421_AddPartForPO_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"PartForPO\" version=\"001\" confirm_use_primary_manufacturerpartnumber=\"prompt\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0421_001\">\n" +
                "            <PartForPO recordid=\"1\" addplannedwopart=\"false\" xmlns=\"http://schemas.datastream.net/MP_entities/PartForPO_001\">\n" +
                "                <PURCHASEORDERLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERID>\n" +
                "                        <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                        <ORGANIZATIONID entity=\"User\">\n" +
                "                            <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERLINENUM>" + partLineNum + "</PURCHASEORDERLINENUM>\n" +
                "                </PURCHASEORDERLINEID>\n" +
                "                <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Group\">\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PARTID>\n" +
                "                <PURCHASEORDERTYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + purchaseOrderType + "</TYPECODE>\n" +
                "                </PURCHASEORDERTYPE>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + purchaseStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <PURCHASEQTY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + purchaseQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">1</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </PURCHASEQTY>\n" +
                "                <PURCHASEUOM xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + purchaseUnitOfMetric + "</UOMCODE>\n" +
                "                </PURCHASEUOM>\n" +
                "                <CONVERSIONFACTOR qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + conversionValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + conversionCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </CONVERSIONFACTOR>\n" +
                "                <PARTQUANTITY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + partQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">1</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </PARTQUANTITY>\n" +
                "                <PARTUOM xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + partUnitOfMetric + "</UOMCODE>\n" +
                "                </PARTUOM>\n" +
                "                <DUEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" +  dueDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DUEDATE>\n" +
                "                <PRICE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + price + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + priceCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </PRICE>\n" +
                "                <CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CURRENCYCODE>" + currency + "</CURRENCYCODE>\n" +
                "                </CURRENCYID>\n" +
                "                <EXCHRATE qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </EXCHRATE>\n" +
                "            </PartForPO>\n" +
                "        </MP0421_AddPartForPO_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPurchaseOrderPart(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, String partLineNum, String purchaseOrderType, String purchaseStatus, String partCode, String partOrganization, String purchaseQuantity, String partQuantity, String purchaseUnitOfMetric, String partUnitOfMetric, String conversionValue, String price, String exchangeValue, String conversionCurrency, String priceCurrency, String currency, String dueDateYear, String dueDateMonth, String dueDateDay, String timeZone, String updatedCount) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0423_SyncPartForPO_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"PartForPO\" version=\"001\" confirm_use_primary_manufacturerpartnumber=\"prompt\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0421_001\">\n" +
                "            <PartForPO recordid=\"" + updatedCount + "\" addplannedwopart=\"false\" xmlns=\"http://schemas.datastream.net/MP_entities/PartForPO_001\">\n" +
                "                <PURCHASEORDERLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERID>\n" +
                "                        <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                        <ORGANIZATIONID entity=\"User\">\n" +
                "                            <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERLINENUM>" + partLineNum + "</PURCHASEORDERLINENUM>\n" +
                "                </PURCHASEORDERLINEID>\n" +
                "                <PARTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Group\">\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>" +
                "                </PARTID>\n" +
                "                <PURCHASEORDERTYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + purchaseOrderType + "</TYPECODE>\n" +
                "                </PURCHASEORDERTYPE>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + purchaseStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <PURCHASEQTY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + purchaseQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">1</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </PURCHASEQTY>\n" +
                "                <PURCHASEUOM xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + purchaseUnitOfMetric + "</UOMCODE>\n" +
                "                </PURCHASEUOM>\n" +
                "                <CONVERSIONFACTOR qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + conversionValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + conversionCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </CONVERSIONFACTOR>\n" +
                "                <PARTQUANTITY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + partQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">1</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </PARTQUANTITY>\n" +
                "                <PARTUOM xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <UOMCODE>" + partUnitOfMetric + "</UOMCODE>\n" +
                "                </PARTUOM>\n" +
                "                <DUEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" +  dueDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dueDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DUEDATE>\n" +
                "                <PRICE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + price + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">" + priceCurrency + "</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </PRICE>\n" +
                "                <CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CURRENCYCODE>" + currency + "</CURRENCYCODE>\n" +
                "                </CURRENCYID>\n" +
                "                <EXCHRATE qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + exchangeValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </EXCHRATE>\n" +
                "            </PartForPO>\n" +
                "        </MP0423_SyncPartForPO_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deletePurchaseOrderPart(String  userName, String tenant, String passWord, String organization, String purchaseOrderCode, String purchaseOrderOrganization, String partLineNum) {
        return  "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0424_DeletePartForPO_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"PartForPO\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0424_001\">\n" +
                "            <PURCHASEORDERLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <PURCHASEORDERLINENUM>" + partLineNum + "</PURCHASEORDERLINENUM>\n" +
                "            </PURCHASEORDERLINEID>\n" +
                "        </MP0424_DeletePartForPO_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

}
