package com.assettec.api.internal.core.receipt.packingSlip;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.Id.IdLineNum;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCurrency;
import com.assettec.api.internal.core.entities.basic.objects.InforEamDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PackingSlip {
    private IdLineNum packingSlipId;
    private IdLineNum purchaseOrderLineId;
    private Id partId;
    private String packingSlipManLot;
    private InforEamDate packingSlipManLotExp;
    private String supplierReference;
    private InforEamCode uomId;
    private InforEamCount deliveredQuantity;
    private InforEamCount receivedQuantity;
    private InforEamCurrency conversionFactor;
    private String comment;
    private InforEamCount outstandingQuantity;
    private InforEamCode purchaseUom;
    private InforEamCode partUom;
    private InforEamCount pendingQuantity;
    private InforEamCount quantityPerUop;
    private String partConditionTemplateCode;
}
