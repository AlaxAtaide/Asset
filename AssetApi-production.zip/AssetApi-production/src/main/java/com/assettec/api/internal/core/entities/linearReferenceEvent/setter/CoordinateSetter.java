package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.Coordinate;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class CoordinateSetter {

    private CountSetter countSetter;

    public Coordinate setCoordinate(NodeList nodeList) {
        Coordinate coordinate = new Coordinate(new InforEamCount("","","",""),new InforEamCount("","","",""));

        coordinate.setX(countSetter.setCount(nodeList.item(0).getChildNodes()));
        coordinate.setY(countSetter.setCount(nodeList.item(1).getChildNodes()));

        return coordinate;
    }
}
