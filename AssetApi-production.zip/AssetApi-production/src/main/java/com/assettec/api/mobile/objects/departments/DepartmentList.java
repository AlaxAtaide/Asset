package com.assettec.api.mobile.objects.departments;

import com.assettec.api.internal.core.entities.department.Department;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentList {
    private int records;
    private List<Department> list;
}
