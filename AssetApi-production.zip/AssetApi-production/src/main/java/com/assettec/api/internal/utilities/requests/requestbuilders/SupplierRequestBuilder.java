package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class SupplierRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String getSupplier(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0295_GetSupplier_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"Supplier\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0295_001\">\n" +
                "            <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </SUPPLIERID>\n" +
                "        </MP0295_GetSupplier_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postSupplier(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String supplierDescription, String languageCode, String currencyCode) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0291_AddSupplier_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Supplier\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0291_001\">\n" +
                "            <Supplier recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/Supplier_001\">\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + supplierDescription + "</DESCRIPTION>\n" +
                "                </SUPPLIERID>\n" +
                "                <LANGUAGEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <LANGUAGECODE>" + languageCode + "</LANGUAGECODE>\n" +
                "                </LANGUAGEID>\n" +
                "                <CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CURRENCYCODE>" + currencyCode + "</CURRENCYCODE>\n" +
                "                </CURRENCYID>\n" +
                "            </Supplier>\n" +
                "        </MP0291_AddSupplier_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putSupplier(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String supplierDescription, String languageCode, String currencyCode, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0292_SyncSupplier_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"Supplier\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0292_001\">\n" +
                "            <Supplier recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/Supplier_001\">\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + supplierDescription + "</DESCRIPTION>\n" +
                "                </SUPPLIERID>\n" +
                "                <LANGUAGEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <LANGUAGECODE>" + languageCode + "</LANGUAGECODE>\n" +
                "                </LANGUAGEID>\n" +
                "                <CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CURRENCYCODE>" + currencyCode + "</CURRENCYCODE>\n" +
                "                </CURRENCYID>\n" +
                "            </Supplier>\n" +
                "        </MP0292_SyncSupplier_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteSupplier(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0293_DeleteSupplier_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"Supplier\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0293_001\">\n" +
                "            <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </SUPPLIERID>\n" +
                "        </MP0293_DeleteSupplier_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String getSupplierContact(String userName, String tenant, String passWord, String organization, String supplierCode, String supplierOrganization, int sequenceNumber) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1257_GetSupplierContact_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"SupplierContact\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1257_001\">\n" +
                "            <SUPPLIERCONTACTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <SEQUENCENUMBER>"+ sequenceNumber + "</SEQUENCENUMBER> \n" +
                "                <SUPPLIERID>\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "            </SUPPLIERCONTACTID>\n" +
                "        </MP1257_GetSupplierContact_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postSupplierContact(String userName, String tenant, String passWord, String organization, String supplierCode, String supplierOrganization, int sequenceNumber, String contactName, String phoneNumber, String contactMethodCode, String fax, String email, String streetAddress1, String streetAddress2, String city, String state, String zip, String secondaryEmail, String secondaryPhone, String terciaryPhone) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1258_AddSupplierContact_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"SupplierContact\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1258_001\">\n" +
                "            <SupplierContact recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/SupplierContact_001\">\n" +
                "                <SUPPLIERCONTACTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SEQUENCENUMBER>" + sequenceNumber + "</SEQUENCENUMBER>\n" +
                "                    <SUPPLIERID>\n" +
                "                        <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                        <ORGANIZATIONID entity=\"User\">\n" +
                "                            <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </SUPPLIERID>\n" +
                "                </SUPPLIERCONTACTID>\n" +
                "                <CONTACTINFO xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CONTACTNAME>" + contactName + "</CONTACTNAME>\n" +
                "                    <PHONE>" + phoneNumber + "</PHONE>\n" +
                "                    <FAX>" + fax + "</FAX>\n" +
                "                    <EMAIL>" + email + "</EMAIL>\n" +
                "                </CONTACTINFO>\n" +
                "                <STREETADDRESS1 xmlns=\"http://schemas.datastream.net/MP_fields\">" + streetAddress1 + "</STREETADDRESS1>\n" +
                "                <STREETADDRESS2 xmlns=\"http://schemas.datastream.net/MP_fields\">" + streetAddress2 + "</STREETADDRESS2>\n" +
                "                <CITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + city + "</CITY>\n" +
                "                <STATE xmlns=\"http://schemas.datastream.net/MP_fields\">" + state + "</STATE>\n" +
                "                <ZIP xmlns=\"http://schemas.datastream.net/MP_fields\">" + zip + "</ZIP>\n" +
                "                <SECONDARYEMAIL xmlns=\"http://schemas.datastream.net/MP_fields\">" + secondaryEmail + "</SECONDARYEMAIL>\n" +
                "                <SECONDARYPHONE xmlns=\"http://schemas.datastream.net/MP_fields\">" + secondaryPhone + "</SECONDARYPHONE>\n" +
                "                <TERTIARYPHONE xmlns=\"http://schemas.datastream.net/MP_fields\">" + terciaryPhone + "</TERTIARYPHONE>\n" +
                // contactMethodCode may be PHON = telephone, FAX, EML = email , EMLF = email and fax
                "                <PREFERREDCONTACTMETHOD xmlns=\"http://schemas.datastream.net/MP_fields\">" + contactMethodCode + "</PREFERREDCONTACTMETHOD>\n" +
                "            </SupplierContact>\n" +
                "        </MP1258_AddSupplierContact_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putSupplierContact(String userName, String tenant, String passWord, String organization, String supplierCode, String supplierOrganization, String sequenceNumber, String contactName, String phoneNumber, String contactMethodCode, String fax, String email, String streetAddress1, String streetAddress2, String city, String state, String zip, String secondaryEmail, String secondaryPhone, String terciaryPhone, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1259_SyncSupplierContact_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"SupplierContact\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1259_001\">\n" +
                "            <SupplierContact recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/SupplierContact_001\">\n" +
                "                <SUPPLIERCONTACTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SEQUENCENUMBER>" + sequenceNumber + "</SEQUENCENUMBER>\n" +
                "                    <SUPPLIERID>\n" +
                "                        <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                        <ORGANIZATIONID entity=\"User\">\n" +
                "                            <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </SUPPLIERID>\n" +
                "                </SUPPLIERCONTACTID>\n" +
                "                <CONTACTINFO xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CONTACTNAME>" + contactName + "</CONTACTNAME>\n" +
                "                    <PHONE>" + phoneNumber + "</PHONE>\n" +
                "                    <FAX>" + fax + "</FAX>\n" +
                "                    <EMAIL>" + email + "</EMAIL>" +
                "                </CONTACTINFO>\n" +
                "                <STREETADDRESS1 xmlns=\"http://schemas.datastream.net/MP_fields\">" + streetAddress1 + "</STREETADDRESS1>\n" +
                "                <STREETADDRESS2 xmlns=\"http://schemas.datastream.net/MP_fields\">" + streetAddress2 + "</STREETADDRESS2>\n" +
                "                <CITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + city + "</CITY>\n" +
                "                <STATE xmlns=\"http://schemas.datastream.net/MP_fields\">" + state + "</STATE>\n" +
                "                <ZIP xmlns=\"http://schemas.datastream.net/MP_fields\">" + zip + "</ZIP>\n" +
                "                <SECONDARYEMAIL xmlns=\"http://schemas.datastream.net/MP_fields\">" + secondaryEmail + "</SECONDARYEMAIL>\n" +
                "                <SECONDARYPHONE xmlns=\"http://schemas.datastream.net/MP_fields\">" + secondaryPhone + "</SECONDARYPHONE>\n" +
                "                <TERTIARYPHONE xmlns=\"http://schemas.datastream.net/MP_fields\">" + terciaryPhone + "</TERTIARYPHONE>" +
                // contactMethodCode may be PHON = telephone, FAX, EML = email , EMLF = email and fax
                "                <PREFERREDCONTACTMETHOD xmlns=\"http://schemas.datastream.net/MP_fields\">" + contactMethodCode + "</PREFERREDCONTACTMETHOD>\n" +
                "            </SupplierContact>\n" +
                "        </MP1259_SyncSupplierContact_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteSupplierContact(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String sequenceNumber) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1260_DeleteSupplierContact_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"SupplierContact\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1260_001\">\n" +
                "            <SUPPLIERCONTACTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <SEQUENCENUMBER>" + sequenceNumber + "</SEQUENCENUMBER>\n" +
                "                <SUPPLIERID>\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "            </SUPPLIERCONTACTID>\n" +
                "        </MP1260_DeleteSupplierContact_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String getSupplierAddress(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String entityCode, String addressType) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0641_GetAddresses_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"Addresses\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0641_001\">\n" +
                "            <ADDRESSID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <CODE>" + supplierCode + "#" + supplierOrganization + "</CODE>\n" +
                "                <ENTITY>" + entityCode + "</ENTITY>\n" +
                "                <TYPE>" + addressType + "</TYPE>\n" +
                "            </ADDRESSID>\n" +
                "        </MP0641_GetAddresses_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postSupplierAddress(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String entityCode, String addressType, String addressDescription, String addressPhone) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0642_AddAddresses_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Addresses\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0642_001\">\n" +
                "            <Addresses updatecount=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/Addresses_001\">\n" +
                "                <ADDRESSID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CODE>" + supplierCode + "#" + supplierOrganization + "</CODE>\n" +
                "                    <ENTITY>" + entityCode + "</ENTITY>\n" +
                //Address types are M, I and there is one more that I can't remember
                "                    <TYPE>" + addressType + "</TYPE>\n" +
                "                </ADDRESSID>\n" +
                "                <TEXT>" + addressDescription + "</TEXT>\n" +
                "                <PHONE>" + addressPhone + "</PHONE> \n" +
                "            </Addresses>\n" +
                "        </MP0642_AddAddresses_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putSupplierAddress(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String entityCode, String addressType, String addressDescription, String addressPhone, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0643_SyncAddresses_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"Addresses\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0643_001\">\n" +
                "            <Addresses updatecount=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/Addresses_001\">\n" +
                "                <ADDRESSID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CODE>" + supplierCode + "#" + supplierOrganization + "</CODE>\n" +
                "                    <ENTITY>" + entityCode + "</ENTITY>\n" +
                "                    <TYPE>" + addressType + "</TYPE>\n" +
                "                </ADDRESSID>\n" +
                "                <TEXT>" + addressDescription + "</TEXT>\n" +
                "                <PHONE>" + addressPhone + "</PHONE> \n" +
                "            </Addresses>\n" +
                "        </MP0643_SyncAddresses_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteSupplierAddress(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String entityCode, String addressType) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0644_DeleteAddresses_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"Addresses\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0644_001\">\n" +
                "            <ADDRESSID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <CODE>" + supplierCode + "#" + supplierOrganization + "</CODE>\n" +
                "                <ENTITY>" + entityCode + "</ENTITY>\n" +
                "                <TYPE>" + addressType + "</TYPE>\n" +
                "            </ADDRESSID>\n" +
                "        </MP0644_DeleteAddresses_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

}
