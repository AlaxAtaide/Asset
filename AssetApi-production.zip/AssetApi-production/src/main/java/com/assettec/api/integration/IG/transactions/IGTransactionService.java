package com.assettec.api.integration.IG.transactions;

import com.assettec.api.integration.IG.transactions.equipment.*;
import com.assettec.api.integration.IG.transactions.position.*;
import com.assettec.api.integration.IG.transactions.store2store.IGStore2Store2SendHttp;
import com.assettec.api.integration.IG.transactions.store2store.IGStore2Store2SendSetter;
import com.assettec.api.integration.IG.transactions.store2store.IGStoreToStoreTransaction;
import com.assettec.api.integration.IG.transactions.system.*;
import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.core.items.asset.AssetService;
import com.assettec.api.internal.core.items.asset.position.AssetPosition;
import com.assettec.api.internal.core.items.asset.system.AssetSystem;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import com.assettec.api.internal.core.transactions.Store2StoreService;
import com.assettec.api.internal.core.transactions.StoreToStore;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.internal.utilities.common.XMLParser;

import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class IGTransactionService {

    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;
    private XMLParser xmlParser;
    private AssetService assetService;
    private Store2StoreService store2StoreService;
    private IGStore2Store2SendSetter store2Store2SendSetter;
    private final Logger logger = LoggerFactory.getLogger(IGTransactionService.class);

    @SneakyThrows
    public IGStore2Store2SendHttp updateStoreToStoreTransaction(ApiUser apiUser, IGStoreToStoreTransaction request, String newStatus) {
        // todo mudar status
        if (request.getTransactionCode() == null || request.getTransactionCode().isEmpty())
            throw new IllegalStateException("Transaction code não pode ser nulo ou estar em branco");

        String host = XMLParser.getInforHost();
        StoreToStore storeTransaction = store2StoreService.getStore2StoreReceipt(apiUser, request.getTransactionCode());

        if (Objects.equals(newStatus, "TR") && !Objects.equals(storeTransaction.getTransactionStatus().getCode(), "NF"))
            throw new IllegalStateException("Store2StoreTransaction status não é: NF.");
        if (Objects.equals(newStatus, "A") && !Objects.equals(storeTransaction.getTransactionStatus().getCode(), "TR"))
            throw new IllegalStateException("Store2StoreTransaction status não é: TR.");

        storeTransaction.getTransactionStatus().setCode(newStatus);
        String postRequest = requestBuilder.getStoreTransactionsRequestBuilder().putStoreToStoreReceipt(apiUser, storeTransaction);
        System.out.println(postRequest);
        requestSender.sendPostRequest(postRequest, host);

        storeTransaction = store2StoreService.getStore2StoreReceipt(apiUser, request.getTransactionCode());
        storeTransaction.setStore2StoreParts(store2StoreService.getStore2StoreParts(apiUser, storeTransaction));

        return new IGStore2Store2SendHttp("200","Transação realizada com sucesso.",store2Store2SendSetter.setStore2Store2Send(apiUser, request.getTransactionCode(), storeTransaction, newStatus));
    }

    @SneakyThrows
    public IGAssetEquipmentSend updateEquipment(ApiUser apiUser, String equipmentCode, String newStatus) {
        if (equipmentCode == null || equipmentCode.isEmpty()) throw new IllegalStateException("EquipmentCode não pode ser nulo ou estar em branco");
        String postRequest, host = XMLParser.getInforHost();

        IGAssetEquipmentSendGetRequest getRequest = getEquipmentData(apiUser, equipmentCode, true);
        AssetEquipment asset = assetService.getAsset(apiUser, equipmentCode, getRequest.getNewOrganization());

        // todo mudar os status
        if (asset.getStatus().equals("I")) throw new IllegalStateException("Equipamento já está instalado.");
            // todo mudar status
        else if (newStatus.equals("ET") && !asset.getStatus().equals("NF2"))
            throw new IllegalStateException("Equipment status não é: NF2.");
            // todo mudar status
        else if (newStatus.equals("I") && !asset.getStatus().equals("ET"))
            throw new IllegalStateException("Equipment status não é: ET.");

        asset.setStatus(newStatus);
        postRequest = requestBuilder.getAssetRequestBuilder().putEquipment(apiUser,asset);
        requestSender.sendPostRequest(postRequest, host);

        IGAssetEquipmentRequest assetEquipment = new IGAssetEquipmentRequest();

        assetEquipment.setEquipmentStatus(newStatus);
        assetEquipment.setEquipmentCode(getRequest.getEquipmentCode());
        assetEquipment.setOldOrganization(getRequest.getOldOrganization());
        assetEquipment.setNewOrganization(getRequest.getNewOrganization());
        assetEquipment.setNewDepartmentCode(getRequest.getEquipmentDepartment());

        return new IGAssetEquipmentSend("200","Transação realizada com sucesso.",assetEquipment);
    }

    @SneakyThrows
    public IGAssetEquipmentSendGetRequest getEquipmentData(ApiUser apiUser, String equipmentCode, boolean getFromOtherSources) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJA", "OSOBJA", "equipmentno", equipmentCode, "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        AssetEquipment activeAsset = new AssetEquipment();
        AssetEquipment withdrawnAsset;
        List<AssetEquipment> withdrawnAssets = new ArrayList<>();
        StringBuilder message = new StringBuilder("Não foi possível determinar de que organização o equipamento foi transferido. Possíveis organizações: ");
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentOrganization = gridService.getDataByName("organization",row);
            //todo verificar no lugar certo
            String equipmentStatus = gridService.getDataByName("assetstatus",row);

            if (getFromOtherSources) {
                // todo mudar status
                if (equipmentStatus.equals("ET") || equipmentStatus.equals("I") || equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getAsset(apiUser, equipmentCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getAsset(apiUser, equipmentCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            } else {
                // todo mudar status
                if (equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getAsset(apiUser, equipmentCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getAsset(apiUser, equipmentCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            }
        }

        AssetEquipment newestAsset = new AssetEquipment();
        for (AssetEquipment withdrawn : withdrawnAssets) {
            if (newestAsset.getWithdrawalDate() == null || newestAsset.getWithdrawalDate().isAfter(withdrawn.getWithdrawalDate())) {
                activeAsset.setOldOrganization(withdrawn.getOrganization());
                newestAsset.setWithdrawalDate(withdrawn.getWithdrawalDate());
                message.append(withdrawn.getOrganization());
            } else if (newestAsset.getWithdrawalDate().isEqual(withdrawn.getWithdrawalDate())) {
                message.append(", ").append(withdrawn.getOrganization());
                activeAsset.setOldOrganization(String.valueOf(message));
                newestAsset.setWithdrawalDate(withdrawn.getWithdrawalDate());
            }
        }

        IGAssetEquipmentSendGetRequest sendRequest = new IGAssetEquipmentSendGetRequest();
        sendRequest.setEquipmentCode(activeAsset.getCode());
        sendRequest.setCodeIGERP(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar02() != null ? activeAsset.getUserDefinedFields().getUdfChar02() : "" : "");
        sendRequest.setCodeIGPAT(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar01() != null ? activeAsset.getUserDefinedFields().getUdfChar01() : "" : "");
        sendRequest.setCodeBEMIG(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar09() != null ? activeAsset.getUserDefinedFields().getUdfChar09() : "" : "");
        sendRequest.setEquipmentDepartment(activeAsset.getDepartment());
        sendRequest.setEquipmentDescription(activeAsset.getDescription());
        sendRequest.setEquipmentStatus(activeAsset.getStatus());
        sendRequest.setEquipmentType(activeAsset.getType());
        sendRequest.setEquipmentModel(activeAsset.getModel());
        sendRequest.setEquipmentState(activeAsset.getEquipmentState().getCode());
        sendRequest.setOldOrganization(activeAsset.getOldOrganization());
        sendRequest.setNewOrganization(activeAsset.getOrganization());
        sendRequest.setEquipmentSerialNumber(activeAsset.getSerialnumber());
        sendRequest.setPurchaseDate(activeAsset.getPurchaseDate());
        sendRequest.setSent(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar03() != null ? activeAsset.getUserDefinedFields().getUdfChar03() : "" : "");

        if (activeAsset.getPurchaseCostValue() != null && !activeAsset.getPurchaseCostValue().equals("") && activeAsset.getPurchaseCostDecimals() != null && !activeAsset.getPurchaseCostDecimals().equals("")) {
            sendRequest.setPurchaseCost(Double.parseDouble(activeAsset.getPurchaseCostValue()) / Math.pow(10, Integer.parseInt(activeAsset.getPurchaseCostDecimals())));
        } else sendRequest.setPurchaseCost(0);
        if (activeAsset.getValue() != null && !activeAsset.getValue().equals("") && activeAsset.getValueDecimals() != null && !activeAsset.getValueDecimals().equals(""))
            sendRequest.setEquipmentValue(Double.parseDouble(activeAsset.getValue()) / Math.pow(10, Integer.parseInt(activeAsset.getValueDecimals())));
        else sendRequest.setEquipmentValue(0);

        return sendRequest;
    }

    @SneakyThrows
    public IGAssetEquipmentSendList sendIGEquipmentInformation(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJA", "OSOBJA", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);


        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGAssetEquipmentRequest> assetEquipmentList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentCode = gridService.getDataByName("equipmentno",row);

            IGAssetEquipmentSendGetRequest activeAsset = getEquipmentData(apiUser, equipmentCode, false);
            IGAssetEquipmentRequest assetEquipment = new IGAssetEquipmentRequest();

            assetEquipment.setEquipmentCode(activeAsset.getEquipmentCode());
            assetEquipment.setNewOrganization(activeAsset.getNewOrganization());
            assetEquipment.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
            assetEquipment.setNewDepartmentCode(activeAsset.getEquipmentDepartment());
            assetEquipment.setEquipmentStatus(activeAsset.getEquipmentStatus());

            assetEquipmentList.add(assetEquipment);
        }

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJA", "OSOBJA", position, "assetstatus", "ANF", "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    IGAssetEquipmentSendGetRequest activeAsset = getEquipmentData(apiUser, equipmentCode, false);
                    IGAssetEquipmentRequest assetEquipment = new IGAssetEquipmentRequest();

                    assetEquipment.setEquipmentCode(activeAsset.getEquipmentCode());
                    assetEquipment.setNewOrganization(activeAsset.getNewOrganization());
                    assetEquipment.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
                    assetEquipment.setNewDepartmentCode(activeAsset.getEquipmentDepartment());
                    assetEquipment.setEquipmentStatus(activeAsset.getEquipmentStatus());

                    assetEquipmentList.add(assetEquipment);
                }
            }
        }
        return new IGAssetEquipmentSendList("200","Transação realizada com sucesso.",assetEquipmentList);
    }

    @SneakyThrows
    public IGFilteredEquipmentList sendFilterEquipment(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJA", "OSOBJA", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGFilteredEquipment> filteredEquipmentList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        logger.info("[FilteredEquipments][ Successfully Adding Equipments to Array ]");
        for (Row row : rows) {
            IGFilteredEquipment filteredEquipment = new IGFilteredEquipment();

            String equipmentCode = gridService.getDataByName("equipmentno",row);
            String equipmentStatus = gridService.getDataByName("assetstatus",row);
            String equipmentDepartment = gridService.getDataByName("department",row);
            String equipmentOrganization = gridService.getDataByName("organization",row);

            filteredEquipment.setEquipmentCode(equipmentCode);
            filteredEquipment.setEquipmentStatus(equipmentStatus);
            filteredEquipment.setEquipmentDepartment(equipmentDepartment);
            filteredEquipment.setEquipmentOrganization(equipmentOrganization);

            filteredEquipmentList.add(filteredEquipment);
        }
        logger.info("[FilteredEquipments][ Successfully Added Equipments to Array ]");

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJA", "OSOBJA", position, "assetstatus", status, "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                logger.info("[FilteredEquipments][ Successfully Adding Equipments to Array from position: " + position + " to: " + lastRowNumber + " ]");
                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    IGFilteredEquipment filteredEquipment = new IGFilteredEquipment();

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    String equipmentStatus = gridService.getDataByName("assetstatus",row);
                    String equipmentDepartment = gridService.getDataByName("department",row);
                    String equipmentOrganization = gridService.getDataByName("organization",row);

                    filteredEquipment.setEquipmentCode(equipmentCode);
                    filteredEquipment.setEquipmentStatus(equipmentStatus);
                    filteredEquipment.setEquipmentDepartment(equipmentDepartment);
                    filteredEquipment.setEquipmentOrganization(equipmentOrganization);

                    filteredEquipmentList.add(filteredEquipment);
                }
                logger.info("[FilteredEquipments][ Successfully Added Equipments to Array from position: " + position + " to: " + lastRowNumber + " ]");
            }
        }

        return new IGFilteredEquipmentList("200","Transação realizada com sucesso", filteredEquipmentList);
    }

    @SneakyThrows
    public IGAssetPositionSend updatePosition(ApiUser apiUser, String positionCode, String newStatus) {
        if (positionCode == null || positionCode.isEmpty()) throw new IllegalStateException("PositionCode não pode ser nulo ou estar em branco");
        String postRequest, host = XMLParser.getInforHost();

        IGAssetPositionSendGetRequest getRequest = getPositionData(apiUser, positionCode, true);
        AssetPosition asset = assetService.getPosition(apiUser, positionCode, getRequest.getNewOrganization());

        // todo mudar os status
        if (asset.getStatus().getCode().equals("I")) throw new IllegalStateException("Posição já está instalada.");
            // todo mudar status
        else if (newStatus.equals("ET") && !asset.getStatus().getCode().equals("NF2"))
            throw new IllegalStateException("Position status não é: NF2.");
            // todo mudar status
        else if (newStatus.equals("I") && !asset.getStatus().getCode().equals("ET"))
            throw new IllegalStateException("Position status não é: ET.");

        asset.getStatus().setCode(newStatus);
        postRequest = requestBuilder.getAssetRequestBuilder().putPosition(apiUser,asset);
        requestSender.sendPostRequest(postRequest, host);

        IGAssetPositionRequest assetPosition = new IGAssetPositionRequest();

        assetPosition.setPositionStatus(newStatus);
        assetPosition.setPositionCode(getRequest.getPositionCode());
        assetPosition.setOldOrganization(getRequest.getOldOrganization());
        assetPosition.setNewOrganization(getRequest.getNewOrganization());
        assetPosition.setNewDepartmentCode(getRequest.getPositionDepartment());

        return new IGAssetPositionSend("200","Transação realizada com sucesso.",assetPosition);
    }

    @SneakyThrows
    private IGAssetPositionSendGetRequest getPositionData(ApiUser apiUser, String positionCode, boolean getFromOtherSources) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJP", "OSOBJP", "equipmentno", positionCode, "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        AssetPosition activeAsset = new AssetPosition();
        AssetPosition withdrawnAsset;
        List<AssetPosition> withdrawnAssets = new ArrayList<>();
        StringBuilder message = new StringBuilder("Não foi possível determinar de que organização o equipamento foi transferido. Possíveis organizações: ");
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentOrganization = gridService.getDataByName("organization",row);
            //todo verificar no lugar certo
            String equipmentStatus = gridService.getDataByName("assetstatus",row);

            if (getFromOtherSources) {
                // todo mudar status
                if (equipmentStatus.equals("ET") || equipmentStatus.equals("I") || equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getPosition(apiUser, positionCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getPosition(apiUser, positionCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            } else {
                // todo mudar status
                if (equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getPosition(apiUser, positionCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getPosition(apiUser, positionCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            }
        }

        AssetEquipment newestAsset = new AssetEquipment();
        for (AssetPosition withdrawn : withdrawnAssets) {
            LocalDateTime withdrawalDate = LocalDateTime.of(Integer.parseInt(withdrawn.getWithdrawalDate().getYear()),Integer.parseInt(withdrawn.getWithdrawalDate().getMonth()),Integer.parseInt(withdrawn.getWithdrawalDate().getDay()),Integer.parseInt(withdrawn.getWithdrawalDate().getHour()),Integer.parseInt(withdrawn.getWithdrawalDate().getMinute()),Integer.parseInt(withdrawn.getWithdrawalDate().getSecond()),Integer.parseInt(withdrawn.getWithdrawalDate().getNano()));

            if (newestAsset.getWithdrawalDate() == null || newestAsset.getWithdrawalDate().isAfter(withdrawalDate)) {
                activeAsset.setOldOrganization(withdrawn.getPositionId().getOrganization().getCode());
                newestAsset.setWithdrawalDate(withdrawalDate);
                message.append(withdrawn.getPositionId().getOrganization().getCode());
            } else if (newestAsset.getWithdrawalDate().isEqual(withdrawalDate)) {
                message.append(", ").append(withdrawn.getPositionId().getOrganization().getCode());
                activeAsset.setOldOrganization(String.valueOf(message));
                newestAsset.setWithdrawalDate(withdrawalDate);
            }
        }

        IGAssetPositionSendGetRequest sendRequest = new IGAssetPositionSendGetRequest();
        sendRequest.setPositionCode(activeAsset.getPositionId().getCode());
        sendRequest.setCodeIGERP(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar02() != null ? activeAsset.getUserDefinedFields().getUdfChar02() : "" : "");
        sendRequest.setCodeIGPAT(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar01() != null ? activeAsset.getUserDefinedFields().getUdfChar01() : "" : "");
        sendRequest.setCodeBEMIG(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar09() != null ? activeAsset.getUserDefinedFields().getUdfChar09() : "" : "");
        sendRequest.setPositionDepartment(activeAsset.getDepartmentId().getCode());
        sendRequest.setPositionDescription(activeAsset.getPositionId().getDescription());
        sendRequest.setPositionStatus(activeAsset.getStatus().getCode());
        sendRequest.setPositionType(activeAsset.getType().getCode());
        sendRequest.setPositionModel(activeAsset.getManufacturerInfo().getModel());
        sendRequest.setOldOrganization(activeAsset.getOldOrganization());
        sendRequest.setNewOrganization(activeAsset.getPositionId().getOrganization().getCode());
        sendRequest.setPositionSerialNumber(activeAsset.getManufacturerInfo().getSerialNumber());
        LocalDateTime purchaseDate = activeAsset.getPurchaseDate() == null ? null : LocalDateTime.of(Integer.parseInt(activeAsset.getPurchaseDate().getYear()),Integer.parseInt(activeAsset.getPurchaseDate().getMonth()),Integer.parseInt(activeAsset.getPurchaseDate().getDay()),Integer.parseInt(activeAsset.getPurchaseDate().getHour()),Integer.parseInt(activeAsset.getPurchaseDate().getMinute()),Integer.parseInt(activeAsset.getPurchaseDate().getSecond()),Integer.parseInt(activeAsset.getPurchaseDate().getNano()));
        sendRequest.setPurchaseDate(purchaseDate);
        sendRequest.setSent(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar03() != null ? activeAsset.getUserDefinedFields().getUdfChar03() : "" : "");

        if (activeAsset.getPurchaseCost() != null) {
            sendRequest.setPurchaseCost(Double.parseDouble(activeAsset.getPurchaseCost().getValue()) / Math.pow(10, Integer.parseInt(activeAsset.getPurchaseCost().getDecimals())));
        } else sendRequest.setPurchaseCost(0);
        if (activeAsset.getAssetValue() != null)
            sendRequest.setPositionValue(Double.parseDouble(activeAsset.getAssetValue().getValue()) / Math.pow(10, Integer.parseInt(activeAsset.getAssetValue().getDecimals())));
        else sendRequest.setPositionValue(0);

        return sendRequest;
    }

    @SneakyThrows
    public IGAssetSystemSend updateSystem(ApiUser apiUser, String systemCode, String newStatus) {
        if (systemCode == null || systemCode.isEmpty()) throw new IllegalStateException("SystemCode não pode ser nulo ou estar em branco");
        String postRequest, host = XMLParser.getInforHost();

        IGAssetSystemSendGetRequest getRequest = getSystemData(apiUser, systemCode, true);
        AssetSystem asset = assetService.getSystem(apiUser, systemCode, getRequest.getNewOrganization());

        // todo mudar os status
        if (asset.getStatus().getCode().equals("I")) throw new IllegalStateException("Sistema já está instalado.");
            // todo mudar status
        else if (newStatus.equals("ET") && !asset.getStatus().getCode().equals("NF2"))
            throw new IllegalStateException("System status não é: NF2.");
            // todo mudar status
        else if (newStatus.equals("I") && !asset.getStatus().getCode().equals("ET"))
            throw new IllegalStateException("System status não é: ET.");

        asset.getStatus().setCode(newStatus);
        postRequest = requestBuilder.getAssetRequestBuilder().putSystem(apiUser,asset);
        requestSender.sendPostRequest(postRequest, host);

        IGAssetSystemRequest assetSystem = new IGAssetSystemRequest();

        assetSystem.setSystemStatus(newStatus);
        assetSystem.setSystemCode(getRequest.getSystemCode());
        assetSystem.setOldOrganization(getRequest.getOldOrganization());
        assetSystem.setNewOrganization(getRequest.getNewOrganization());
        assetSystem.setNewDepartmentCode(getRequest.getSystemDepartment());

        return new IGAssetSystemSend("200","Transação realizada com sucesso.",assetSystem);
    }

    @SneakyThrows
    private IGAssetSystemSendGetRequest getSystemData(ApiUser apiUser, String systemCode, boolean getFromOtherSources) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJS", "OSOBJS", "equipmentno", systemCode, "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        AssetSystem activeAsset = new AssetSystem();
        AssetSystem withdrawnAsset;
        List<AssetSystem> withdrawnAssets = new ArrayList<>();
        StringBuilder message = new StringBuilder("Não foi possível determinar de que organização o equipamento foi transferido. Possíveis organizações: ");
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentOrganization = gridService.getDataByName("organization",row);
            //todo verificar no lugar certo
            String equipmentStatus = gridService.getDataByName("assetstatus",row);

            if (getFromOtherSources) {
                // todo mudar status
                if (equipmentStatus.equals("ET") || equipmentStatus.equals("I") || equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getSystem(apiUser, systemCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getSystem(apiUser, systemCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            } else {
                // todo mudar status
                if (equipmentStatus.equals("NF2")) {
                    activeAsset = assetService.getSystem(apiUser, systemCode, equipmentOrganization);
                } else if (equipmentStatus.equals("D")) {
                    withdrawnAsset = assetService.getSystem(apiUser, systemCode, equipmentOrganization);
                    if (withdrawnAsset.getWithdrawalDate() != null) withdrawnAssets.add(withdrawnAsset);
                }
            }
        }

        AssetEquipment newestAsset = new AssetEquipment();
        for (AssetSystem withdrawn : withdrawnAssets) {
            LocalDateTime withdrawalDate = LocalDateTime.of(Integer.parseInt(withdrawn.getWithdrawalDate().getYear()),Integer.parseInt(withdrawn.getWithdrawalDate().getMonth()),Integer.parseInt(withdrawn.getWithdrawalDate().getDay()),Integer.parseInt(withdrawn.getWithdrawalDate().getHour()),Integer.parseInt(withdrawn.getWithdrawalDate().getMinute()),Integer.parseInt(withdrawn.getWithdrawalDate().getSecond()),Integer.parseInt(withdrawn.getWithdrawalDate().getNano()));

            if (newestAsset.getWithdrawalDate() == null || newestAsset.getWithdrawalDate().isAfter(withdrawalDate)) {
                activeAsset.setOldOrganization(withdrawn.getSystemId().getOrganization().getCode());
                newestAsset.setWithdrawalDate(withdrawalDate);
                message.append(withdrawn.getSystemId().getOrganization().getCode());
            } else if (newestAsset.getWithdrawalDate().isEqual(withdrawalDate)) {
                message.append(", ").append(withdrawn.getSystemId().getOrganization().getCode());
                activeAsset.setOldOrganization(String.valueOf(message));
                newestAsset.setWithdrawalDate(withdrawalDate);
            }
        }

        IGAssetSystemSendGetRequest sendRequest = new IGAssetSystemSendGetRequest();
        sendRequest.setSystemCode(activeAsset.getSystemId().getCode());
        sendRequest.setCodeIGERP(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar02() != null ? activeAsset.getUserDefinedFields().getUdfChar02() : "" : "");
        sendRequest.setCodeIGPAT(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar01() != null ? activeAsset.getUserDefinedFields().getUdfChar01() : "" : "");
        sendRequest.setCodeBEMIG(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar09() != null ? activeAsset.getUserDefinedFields().getUdfChar09() : "" : "");
        sendRequest.setSystemDepartment(activeAsset.getDepartmentId().getCode());
        sendRequest.setSystemDescription(activeAsset.getSystemId().getDescription());
        sendRequest.setSystemStatus(activeAsset.getStatus().getCode());
        sendRequest.setSystemType(activeAsset.getType().getCode());
        sendRequest.setSystemModel(activeAsset.getManufacturerInfo().getModel());
        sendRequest.setOldOrganization(activeAsset.getOldOrganization());
        sendRequest.setNewOrganization(activeAsset.getSystemId().getOrganization().getCode());
        sendRequest.setSystemSerialNumber(activeAsset.getManufacturerInfo().getSerialNumber());
        LocalDateTime purchaseDate = activeAsset.getPurchaseDate() == null ? null : LocalDateTime.of(Integer.parseInt(activeAsset.getPurchaseDate().getYear()),Integer.parseInt(activeAsset.getPurchaseDate().getMonth()),Integer.parseInt(activeAsset.getPurchaseDate().getDay()),Integer.parseInt(activeAsset.getPurchaseDate().getHour()),Integer.parseInt(activeAsset.getPurchaseDate().getMinute()),Integer.parseInt(activeAsset.getPurchaseDate().getSecond()),Integer.parseInt(activeAsset.getPurchaseDate().getNano()));
        sendRequest.setPurchaseDate(purchaseDate);
        sendRequest.setSent(activeAsset.getUserDefinedFields() != null ? activeAsset.getUserDefinedFields().getUdfChar03() != null ? activeAsset.getUserDefinedFields().getUdfChar03() : "" : "");

        if (activeAsset.getPurchaseCost() != null) {
            sendRequest.setPurchaseCost(Double.parseDouble(activeAsset.getPurchaseCost().getValue()) / Math.pow(10, Integer.parseInt(activeAsset.getPurchaseCost().getDecimals())));
        } else sendRequest.setPurchaseCost(0);
        if (activeAsset.getAssetValue() != null)
            sendRequest.setSystemValue(Double.parseDouble(activeAsset.getAssetValue().getValue()) / Math.pow(10, Integer.parseInt(activeAsset.getAssetValue().getDecimals())));
        else sendRequest.setSystemValue(0);

        return sendRequest;
    }

    @SneakyThrows
    public IGAssetPositionSendList sendIGPositionInformation(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJP", "OSOBJP", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGAssetPositionRequest> assetPositionList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentCode = gridService.getDataByName("equipmentno",row);

            IGAssetPositionSendGetRequest activeAsset = getPositionData(apiUser, equipmentCode, false);
            IGAssetPositionRequest assetPosition = new IGAssetPositionRequest();

            assetPosition.setPositionCode(activeAsset.getPositionCode());
            assetPosition.setNewOrganization(activeAsset.getNewOrganization());
            assetPosition.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
            assetPosition.setNewDepartmentCode(activeAsset.getPositionDepartment());
            assetPosition.setPositionStatus(activeAsset.getPositionStatus());

            assetPositionList.add(assetPosition);
        }

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJP", "OSOBJP", position, "assetstatus", "ANF", "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    IGAssetPositionSendGetRequest activeAsset = getPositionData(apiUser, equipmentCode, false);
                    IGAssetPositionRequest assetPosition = new IGAssetPositionRequest();

                    assetPosition.setPositionCode(activeAsset.getPositionCode());
                    assetPosition.setNewOrganization(activeAsset.getNewOrganization());
                    assetPosition.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
                    assetPosition.setNewDepartmentCode(activeAsset.getPositionDepartment());
                    assetPosition.setPositionStatus(activeAsset.getPositionStatus());

                    assetPositionList.add(assetPosition);
                }
            }
        }
        return new IGAssetPositionSendList("200","Transação realizada com sucesso.",assetPositionList);
    }

    @SneakyThrows
    public IGFilteredPositionList sendFilterPosition(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJP", "OSOBJP", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGFilteredPosition> filteredPositionList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        logger.info("[FilteredPositions][ Successfully Adding Positions to Array ]");
        for (Row row : rows) {
            IGFilteredPosition filteredPosition = new IGFilteredPosition();

            String equipmentCode = gridService.getDataByName("equipmentno",row);
            String equipmentStatus = gridService.getDataByName("assetstatus",row);
            String equipmentDepartment = gridService.getDataByName("department",row);
            String equipmentOrganization = gridService.getDataByName("organization",row);

            filteredPosition.setPositionCode(equipmentCode);
            filteredPosition.setPositionStatus(equipmentStatus);
            filteredPosition.setPositionDepartment(equipmentDepartment);
            filteredPosition.setPositionOrganization(equipmentOrganization);

            filteredPositionList.add(filteredPosition);
        }
        logger.info("[FilteredPositions][ Successfully Added Positions to Array ]");

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJP", "OSOBJP", position, "assetstatus", status, "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                logger.info("[FilteredPositions][ Successfully Adding Positions to Array from position: " + position + " to: " + lastRowNumber + " ]");
                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    IGFilteredPosition filteredPosition = new IGFilteredPosition();

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    String equipmentStatus = gridService.getDataByName("assetstatus",row);
                    String equipmentDepartment = gridService.getDataByName("department",row);
                    String equipmentOrganization = gridService.getDataByName("organization",row);

                    filteredPosition.setPositionCode(equipmentCode);
                    filteredPosition.setPositionStatus(equipmentStatus);
                    filteredPosition.setPositionDepartment(equipmentDepartment);
                    filteredPosition.setPositionOrganization(equipmentOrganization);

                    filteredPositionList.add(filteredPosition);
                }
                logger.info("[FilteredPositions][ Successfully Added Positions to Array from position: " + position + " to: " + lastRowNumber + " ]");
            }
        }

        return new IGFilteredPositionList("200","Transação realizada com sucesso", filteredPositionList);
    }

    @SneakyThrows
    public IGAssetSystemSendList sendIGSystemInformation(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJS", "OSOBJS", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGAssetSystemRequest> assetSystemList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String equipmentCode = gridService.getDataByName("equipmentno",row);

            IGAssetSystemSendGetRequest activeAsset = getSystemData(apiUser, equipmentCode, false);
            IGAssetSystemRequest assetSystem = new IGAssetSystemRequest();

            assetSystem.setSystemCode(activeAsset.getSystemCode());
            assetSystem.setNewOrganization(activeAsset.getNewOrganization());
            assetSystem.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
            assetSystem.setNewDepartmentCode(activeAsset.getSystemDepartment());
            assetSystem.setSystemStatus(activeAsset.getSystemStatus());

            assetSystemList.add(assetSystem);
        }

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJS", "OSOBJS", position, "assetstatus", "ANF", "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    IGAssetSystemSendGetRequest activeAsset = getSystemData(apiUser, equipmentCode, false);
                    IGAssetSystemRequest assetSystem = new IGAssetSystemRequest();

                    assetSystem.setSystemCode(activeAsset.getSystemCode());
                    assetSystem.setNewOrganization(activeAsset.getNewOrganization());
                    assetSystem.setOldOrganization(activeAsset.getOldOrganization() != null ? activeAsset.getOldOrganization() : "Registro antigo foi removido ou teve seu status mudado antes que a API pudesse ler sua organização");
                    assetSystem.setNewDepartmentCode(activeAsset.getSystemDepartment());
                    assetSystem.setSystemStatus(activeAsset.getSystemStatus());

                    assetSystemList.add(assetSystem);
                }
            }
        }
        return new IGAssetSystemSendList("200","Transação realizada com sucesso.",assetSystemList);
    }

    @SneakyThrows
    public IGFilteredSystemList sendFilterSystem(ApiUser apiUser, String status) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "OSOBJS", "OSOBJS", "assetstatus", status , "=");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum resultado.");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGFilteredSystem> filteredSystemList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        logger.info("[FilteredSystems][ Successfully Adding Systems to Array ]");
        for (Row row : rows) {
            IGFilteredSystem filteredSystem = new IGFilteredSystem();

            String equipmentCode = gridService.getDataByName("equipmentno",row);
            String equipmentStatus = gridService.getDataByName("assetstatus",row);
            String equipmentDepartment = gridService.getDataByName("department",row);
            String equipmentOrganization = gridService.getDataByName("organization",row);

            filteredSystem.setSystemCode(equipmentCode);
            filteredSystem.setSystemStatus(equipmentStatus);
            filteredSystem.setSystemDepartment(equipmentDepartment);
            filteredSystem.setSystemOrganization(equipmentOrganization);

            filteredSystemList.add(filteredSystem);
        }
        logger.info("[FilteredSystems][ Successfully Added Systems to Array ]");

        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "OSOBJS", "OSOBJS", position, "assetstatus", status, "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                logger.info("[FilteredSystems][ Successfully Adding Systems to Array from position: " + position + " to: " + lastRowNumber + " ]");
                for (Row row : rows) {
                    xmlData = xmlParser.toDocument(response);
                    data = xmlData.getElementsByTagName("DATA");

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    IGFilteredSystem filteredSystem = new IGFilteredSystem();

                    String equipmentCode = gridService.getDataByName("equipmentno",row);
                    String equipmentStatus = gridService.getDataByName("assetstatus",row);
                    String equipmentDepartment = gridService.getDataByName("department",row);
                    String equipmentOrganization = gridService.getDataByName("organization",row);

                    filteredSystem.setSystemCode(equipmentCode);
                    filteredSystem.setSystemStatus(equipmentStatus);
                    filteredSystem.setSystemDepartment(equipmentDepartment);
                    filteredSystem.setSystemOrganization(equipmentOrganization);

                    filteredSystemList.add(filteredSystem);
                }
                logger.info("[FilteredSystems][ Successfully Added Systems to Array from position: " + position + " to: " + lastRowNumber + " ]");
            }
        }

        return new IGFilteredSystemList("200","Transação realizada com sucesso", filteredSystemList);
    }
}
