package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.DetailsMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class DetailsMobileSetter {
    public void setDetails(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        DetailsMobile details = new DetailsMobile();

        details.setClassId(workOrder.getClassId() == null
                ? "" : workOrder.getClassId().getCode());

        details.setProblemCode(workOrder.getProblem() == null
                ? "" : workOrder.getProblem().getCode());

        details.setCriticality(workOrder.getCriticality() == null
                ? "" : workOrder.getCriticality().getCode());

        details.setPpmCode(workOrder.getPpm() == null
                ? "" : workOrder.getPpm().getCode());

        details.setMaintenancePatternCode(workOrder.getMaintenancePatternId() == null
                ? "" : workOrder.getMaintenancePatternId().getCode());

        details.setMaintenancePatterDescription(workOrder.getMaintenancePatternId() == null
                ? "" : workOrder.getMaintenancePatternId().getDescription());

        details.setParentWorkOrder(workOrder.getParentWorkOrder() == null
                ? "" : workOrder.getParentWorkOrder().getCode());

        details.setCnNumber(workOrder.getCnNumber() == null
                ? "" : workOrder.getCnNumber());

        details.setMsProject(workOrder.getMsProject() == null
                ? "" : workOrder.getMsProject());

        details.setSchedulingSessionType(workOrder.getSchedulingSessionType() == null
                ? "" : workOrder.getSchedulingSessionType().getCode());

        details.setCauseCode(workOrder.getCause() == null
                ? "" : workOrder.getCause().getCode());

        details.setCustomerCode(workOrder.getCustomerId() == null
                ? "" : workOrder.getCustomerId().getCode());

        details.setLevel1(workOrder.getLevel1() == null
                ? "" : workOrder.getLevel1());

        details.setCallerName(workOrder.getCallerName() == null
                ? "" : workOrder.getCallerName());

        details.setRejectionReason(workOrder.getRejectionReason() == null
                ? "" : workOrder.getRejectionReason());

        details.setReOpened(workOrder.getReOpened() == null
                ? "" : workOrder.getReOpened());

        details.setCustomerContractCode(workOrder.getCustomerContractId() == null
                ? "" : workOrder.getCustomerContractId().getCode());

        details.setWorkPackage(workOrder.getWorkPackage() == null
                ? "" : workOrder.getWorkPackage());

        details.setAlertCode(workOrder.getAlert() == null
                ? "" : workOrder.getAlert().getCode());

        details.setSafetyReviewedBy(workOrder.getSafetyReviewedBy() == null
                ? "" : workOrder.getSafetyReviewedBy().getCode());

        details.setPermitReviewedBy(workOrder.getPermitReviewedBy() == null
                ? "" : workOrder.getPermitReviewedBy().getCode());

        details.setStandardWo(workOrder.getStandardWorkOrder() == null
                ? "" : workOrder.getStandardWorkOrder().getCode());

        details.setPriorityCode(workOrder.getPriority() == null
                ? "" : workOrder.getPriority().getCode());

        details.setCostCode(workOrder.getCostCodeId() == null
                ? "" : workOrder.getCostCodeId().getCode());

        details.setTargetValue(workOrder.getTargetValue() == null
                ? "" : workOrder.getTargetValue().toString());

        details.setLastMeterRating(workOrder.getLastMeterReading() == null
                ? "" : workOrder.getLastMeterReading().toString());

        details.setTriggerEvent(workOrder.getTriggerEvent() == null
                ? "" : workOrder.getTriggerEvent().getCode());

        details.setFailureCode(workOrder.getFailure() == null
                ? "" : workOrder.getFailure().getCode());

        details.setActionCode(workOrder.getAcdCode() == null
                ? "" : workOrder.getAcdCode());

        details.setRouteCode(workOrder.getRoute() == null
                ? "" : workOrder.getRoute().getCode());

        details.setRouteStatus(workOrder.getRouteStatus() == null
                ? "" : workOrder.getRouteStatus().getCode());

        details.setDownTimeCost(workOrder.getDownTimeCost() == null
                ? "" : workOrder.getDownTimeCost().toString());

        details.setDownTimeHours(workOrder.getDownTimeHours() == null
                ? "" : workOrder.getDownTimeHours().toString());

        details.setOriginalWorkOrder(workOrder.getOriginalWorkOrderActivityId() == null
                ? "" : workOrder.getOriginalWorkOrderActivityId().getCode());

        details.setCalculatedPriority(workOrder.getCalculatedPriority() == null
                ? "" : workOrder.getCalculatedPriority().toString());

        details.setCategoryCode(workOrder.getWorkOrderTypeCategory() == null
                ? "" : workOrder.getWorkOrderTypeCategory().getCode());

        details.setMinor(workOrder.getMinor() == null
                ? "" : workOrder.getMinor());

        details.setPreserveCalculatedPriority(workOrder.getPreserveCalculatedPriority() == null
                ? "" : workOrder.getPreserveCalculatedPriority());

        details.setLatitude(workOrder.getLatitude() == null
                ? "" : workOrder.getLatitude().toString());

        details.setLongitude(workOrder.getLongitude() == null
                ? "" : workOrder.getLongitude().toString());


        workOrderDetails.setDetails(details);
    }
}
