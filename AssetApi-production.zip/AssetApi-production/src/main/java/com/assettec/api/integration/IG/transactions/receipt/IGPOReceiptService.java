package com.assettec.api.integration.IG.transactions.receipt;

import com.assettec.api.internal.core.installationcode.InstallationCode;
import com.assettec.api.internal.core.installationcode.InstallationCodeService;
import com.assettec.api.internal.core.orders.purchaseorder.PartForPurchase;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrder;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrderService;
import com.assettec.api.internal.core.receipt.POReceipt;
import com.assettec.api.internal.core.receipt.POReceiptService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.Validator;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class IGPOReceiptService {

    private InstallationCodeService installationCodeService;
    private PurchaseOrderService purchaseOrderService;
    private POReceiptService poReceiptService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public IGPOReceiptRequest postPOReceipt(ApiUser apiUser, IGPOReceiptRequest request) {
        if (request.getPurchaseOrderCode() == null || request.getPurchaseOrderCode().isEmpty()) throw new IllegalStateException("PurchaseOrderCode não pode ser nulo ou estar em branco");
        if (request.getPurchaseOrderOrganization() == null || request.getPurchaseOrderOrganization().isEmpty()) throw new IllegalStateException("PurchaseOrderOrganization não pode ser nulo ou estar em branco");

        if (request.getReceiptDescription() == null || request.getReceiptDescription().isEmpty()) request.setReceiptDescription("{api-generated-receipt-description}");
        if (request.getReceiptOrganization() == null || request.getReceiptOrganization().isEmpty()) request.setReceiptOrganization(request.getPurchaseOrderOrganization());
        if (request.getReceiptStatus() == null || request.getReceiptStatus().isEmpty()) request.setReceiptStatus("U");

        String host = XMLParser.getInforHost();
        PurchaseOrder purchaseOrder = purchaseOrderService.getPurchaseOrder(apiUser, request.getPurchaseOrderCode(), request.getPurchaseOrderOrganization());
        InstallationCode installationCode = installationCodeService.getInstallationCode(apiUser,"POSTALLR");

        if (purchaseOrder.getPartsForPurchase().size() == 0) throw new IllegalStateException("Não há linhas para receber.");
        if (purchaseOrder.getStatus().equals(installationCode.getValue())) throw new IllegalStateException("Não é possível receber ordem de compra com status: " + installationCode.getValue());
        if (request.getPartReceiptLines() != null && request.getPartReceiptLines().size() != 0 && request.getPartReceiptLines().size() > purchaseOrder.getPartsForPurchase().size())
            throw new IllegalStateException("Não é possivel receber mais peças do que a quantidade comprada. Quantidade de peças do request: " + request.getPartReceiptLines().size() + " quantidade de peças da ordem de compra: " + purchaseOrder.getPartsForPurchase().size());

        // adds partCodes and duplicates to arrays
        List<String> partCodes = new ArrayList<>(), duplicates = new ArrayList<>(), duplicateLines = new ArrayList<>();
        for (PartForPurchase forPurchase : purchaseOrder.getPartsForPurchase()) {
            for (String partCode : partCodes) if (partCode.equals(forPurchase.getPart().getCode())) {
                duplicates.add(forPurchase.getPart().getCode());
            }
            partCodes.add(forPurchase.getPart().getCode());
        }

        // adds parts4purchase lineNum to duplicateLines
        for (PartForPurchase forPurchase : purchaseOrder.getPartsForPurchase()) {
            for (String partCode : duplicates) if (partCode.equals(forPurchase.getPart().getCode())) {
                if (!duplicateLines.contains(forPurchase.getLineNum())) duplicateLines.add(forPurchase.getLineNum());
            }
        }

        List<String> requestPartCodes = new ArrayList<>();
        if (request.getPartReceiptLines() != null && request.getPartReceiptLines().size() != 0) {

            // Checks if duplicates are without partLines
            for (IGPartReceiptLines partReceiptLine : request.getPartReceiptLines()) {
                requestPartCodes.add(partReceiptLine.getPartCode());
                for (String duplicate : duplicates) if (Objects.equals(duplicate, partReceiptLine.getPartCode()) && partReceiptLine.getPartLine() == 0) {
                    StringBuilder partLinesString = new StringBuilder();
                    for (int i = 0; i < duplicateLines.size(); i++) {
                        if (i == 0) partLinesString.append(Long.parseLong(duplicateLines.get(i))/10);
                        else if (i == duplicateLines.size()-1) partLinesString.append(" or ").append(Long.parseLong(duplicateLines.get(i))/10);
                        else partLinesString.append(", ").append(Long.parseLong(duplicateLines.get(i))/10);
                    }
                    throw new IllegalStateException("Detectada duplicata de: " + partReceiptLine.getPartCode() + " sem o campo partLine, adicione o campo partLine com um número para filtrar a peça que deve ser recebida. Escolha a partir das partLines disponíveis: " + partLinesString);
                }
            }

            // Checks if partCodes are null or blank
            for (int i = 0; i < request.getPartReceiptLines().size(); i++) {
                IGPartReceiptLines partReceiptLine = request.getPartReceiptLines().get(i);
                if (partReceiptLine.getPartCode() == null || partReceiptLine.getPartCode().isEmpty()) throw new IllegalStateException("PartReceiptLine: " + i + " partCode não pode ser nulo ou estar em branco");

                // Checks if request does not contain required partCodes
                if (!partCodes.contains(partReceiptLine.getPartCode())) {
                    StringBuilder partCodesString = new StringBuilder();
                    for (int j = 0; j < purchaseOrder.getPartsForPurchase().size(); j++) {
                        if (j == 0) partCodesString.append(purchaseOrder.getPartsForPurchase().get(j).getPart().getCode());
                        else if (j == purchaseOrder.getPartsForPurchase().size()-1) partCodesString.append(" and ").append(purchaseOrder.getPartsForPurchase().get(j).getPart().getCode());
                        else partCodesString.append(" ,").append(purchaseOrder.getPartsForPurchase().get(j).getPart().getCode());
                    }
                    throw new IllegalStateException("partReceiptLine de código: " + partReceiptLine.getPartCode() + " não foi encontrada na ordem de compra: " + purchaseOrder.getCode() + " partCodes que podem ser recebidas: " + partCodesString);
                }

                // Checks if ReceivedQuantity is equal to 0
                if (partReceiptLine.getReceivedQuantity() == 0.0) throw new IllegalStateException("Não pode receber peça: " + partReceiptLine.getPartCode() + " com quantidade igual a: " + partReceiptLine.getReceivedQuantity());
                Validator.checkLimit(partReceiptLine.getReceivedQuantity(), 24,6);

                // Replaces request partLines making it an optional field
                for (int j = 0; j < purchaseOrder.getPartsForPurchase().size(); j++) {
                    PartForPurchase partForPurchase = purchaseOrder.getPartsForPurchase().get(j);
                    if (partReceiptLine.getPartLine() == 0 && Objects.equals(partReceiptLine.getPartCode(), partForPurchase.getPart().getCode())) request.getPartReceiptLines().get(i).setPartLine(Integer.parseInt(partForPurchase.getLineNum())/10);
                }
            }
        }

        //registers POReceipt
        String postRequest = requestBuilder.getPoReceiptRequestBuilder().postPOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getReceiptOrganization(), request.getReceiptDescription(), request.getReceiptStatus(), purchaseOrder.getCode(), purchaseOrder.getOrganization(), purchaseOrder.getSupplier().getCode(), purchaseOrder.getSupplier().getOrganization(), purchaseOrder.getStore().getCode(), purchaseOrder.getStore().getOrganization(), String.valueOf(LocalDateTime.now().getYear()), String.valueOf(LocalDateTime.now().getMonthValue()), String.valueOf(LocalDateTime.now().getDayOfMonth()), "-0300");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlResponse = xmlParser.toDocument(response);
        String message = xmlResponse.getElementsByTagName("Message").item(0).getTextContent();
        String poReceiptCode = message.replace("Recebimento de OC ", "").replace(" foi salvo com êxito.", "");

        //retrieves all lines
        postRequest = requestBuilder.getPackingSlipRequestBuilder().retrievePackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, request.getReceiptOrganization());
        requestSender.sendPostRequest(postRequest, host);
        POReceipt poReceipt = poReceiptService.getPOReceipt(apiUser, poReceiptCode, request.getReceiptOrganization());

        if (request.getPartReceiptLines() != null && request.getPartReceiptLines().size() != 0) {
            // gets packingSlip information
            int line = 1;
            postRequest = requestBuilder.getPackingSlipRequestBuilder().getPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization(), line);
            response = requestSender.sendPostRequest(postRequest, host);

            //checks if it has lines
            if (Objects.equals(response, "Unable to locate registry")) {
                //deletes poReceipt
                postRequest = requestBuilder.getPackingSlipRequestBuilder().deleteAllPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
                requestSender.sendPostRequest(postRequest, host );
                postRequest = requestBuilder.getPoReceiptRequestBuilder().deletePOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
                requestSender.sendPostRequest(postRequest, host );
                throw new IllegalStateException("Ordem de compra já recebida.");
            }

            // reads xmlResponseData
            while (!Objects.equals(response, "Unable to locate registry")) {

                String partCode = xmlParser.toDocument(response).getElementsByTagName("PARTCODE").item(0).getTextContent();
                String partOrganization = xmlParser.toDocument(response).getElementsByTagName("PARTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent();
                String packingSlipLine = xmlParser.toDocument(response).getElementsByTagName("PACKINGSLIPLINE").item(0).getTextContent();
                String purchaseOrderLine = xmlParser.toDocument(response).getElementsByTagName("PURCHASEORDERLINENUM").item(0).getTextContent();
                String pendingQuantityValue = xmlParser.toDocument(response).getElementsByTagName("PENDINGQTY").item(0).getFirstChild().getTextContent();
                String pendingQuantityDecimals = xmlParser.toDocument(response).getElementsByTagName("PENDINGQTY").item(0).getChildNodes().item(1).getTextContent();
                int realPendingQuantity = (int) (Integer.parseInt(pendingQuantityValue) / Math.pow(10, Integer.parseInt(pendingQuantityDecimals)));

                String updatedCount = xmlParser.toDocument(response).getElementsByTagName("PackingSlip").item(0).getAttributes().getNamedItem("recordid").getNodeValue();

                //deletes undesired lines
                if (!requestPartCodes.contains(partCode)) {
                    postRequest = requestBuilder.getPackingSlipRequestBuilder().deletePackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization(), line);
                    requestSender.sendPostRequest(postRequest, host);
                } else {
                    // starts updating lines
                    for (int i = 0; i < request.getPartReceiptLines().size(); i++) {
                        IGPartReceiptLines part = request.getPartReceiptLines().get(i);
                        if (part.getReceivedQuantity() > realPendingQuantity) {
                            //deletes poReceipt
                            postRequest = requestBuilder.getPackingSlipRequestBuilder().deleteAllPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
                            System.out.println(postRequest);
                            requestSender.sendPostRequest(postRequest, host );
                            requestSender.sendPostRequest(requestBuilder.getPoReceiptRequestBuilder().deletePOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode,poReceipt.getOrganization()),host);
                            throw new IllegalStateException("Não é possível receber mais peças do que a quantidade pendente. Tentativa de receber de " + part.getPartCode() + ": " + part.getReceivedQuantity() + " quantidade pendente: " + realPendingQuantity);
                        }
                        // updates desired lines
                        if (Objects.equals(part.getPartCode(), partCode) && (part.getPartLine() * 10) == Integer.parseInt(packingSlipLine)) {

                            String receivedQuantity;
                            if (part.getReceivedQuantity() == 0.0) receivedQuantity = "0000000";
                            else receivedQuantity = BigDecimal.valueOf(part.getReceivedQuantity() * Math.pow(10, 6)).toPlainString().replace(".0","");

                            postRequest = requestBuilder.getPackingSlipRequestBuilder().putPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization(), purchaseOrder.getCode(), purchaseOrder.getOrganization(), partCode, partOrganization, receivedQuantity, packingSlipLine, purchaseOrderLine, updatedCount);
                            requestSender.sendPostRequest(postRequest, host);
                        }
                    }
                }
                line += 1;
                postRequest = requestBuilder.getPackingSlipRequestBuilder().getPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization(), line);
                response = requestSender.sendPostRequest(postRequest, host);
            }
        }

        //Move lines to active
        postRequest = requestBuilder.getPackingSlipRequestBuilder().movePackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
        response = requestSender.sendPostRequest(postRequest, host);
        if (response.equals("Não é possível gravar a guia de remessa porque ela não tem nenhuma linha associada.")) {
            postRequest = requestBuilder.getPackingSlipRequestBuilder().deleteAllPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
            requestSender.sendPostRequest(postRequest, host);
            requestSender.sendPostRequest(requestBuilder.getPoReceiptRequestBuilder().deletePOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode,poReceipt.getOrganization()),host);
            throw new IllegalStateException("Linhas de compra já recebidas.");
        }

        //Updates Active Lines bin
        int activeLine = 1;

        postRequest = requestBuilder.getPoReceiptRequestBuilder().getPOReceiptActiveLine(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, activeLine);
        response = requestSender.sendPostRequest(postRequest, host);

        while (!Objects.equals(response, "Cannot find the POReceiptActiveLine record.")) {

            Document responseXML = xmlParser.toDocument(response);
            String purchaseOrderLineNum = responseXML.getElementsByTagName("PURCHASEORDERLINENUM").item(0).getTextContent();
            String poReceiptLineStatus = responseXML.getElementsByTagName("PORECEIPTLINESTATUS").item(0).getFirstChild().getTextContent();
            String purchaseOrderType = responseXML.getElementsByTagName("PURCHASEORDERTYPE").item(0).getFirstChild().getTextContent();
            String partCode = responseXML.getElementsByTagName("PARTCODE").item(0).getTextContent();
            String partOrganization = responseXML.getElementsByTagName("PARTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent();
            String inspectionStatus = responseXML.getElementsByTagName("INSPECTIONSTATUS").item(0).getFirstChild().getTextContent();
            String receiptQuantity = responseXML.getElementsByTagName("RECEIPTUOPQUANTITY").item(0).getFirstChild().getTextContent();
            String receivedQuantity = responseXML.getElementsByTagName("RECEIVEDQUANTITY").item(0).getFirstChild().getTextContent();
            String updatedCount = xmlParser.toDocument(response).getElementsByTagName("POReceiptActiveLine").item(0).getAttributes().getNamedItem("recordid").getNodeValue();

            if (request.getPartReceiptLines() != null && request.getPartReceiptLines().size() != 0) {
                for (int i = 0; i < request.getPartReceiptLines().size(); i++) {
                    IGPartReceiptLines part = request.getPartReceiptLines().get(i);
                    if (Objects.equals(part.getPartCode(), partCode)) {
                        if (part.getPartBin() == null || part.getPartBin().isEmpty()) part.setPartBin("*");
                        postRequest = requestBuilder.getPoReceiptRequestBuilder().putPOReceiptActiveLine(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, activeLine, purchaseOrderLineNum, request.getPurchaseOrderCode(), request.getPurchaseOrderOrganization(), poReceiptLineStatus, purchaseOrderType, partCode, part.getPartBin(), partOrganization, inspectionStatus, receiptQuantity, receivedQuantity, updatedCount);
                        requestSender.sendPostRequest(postRequest, host);
                    }
                    part.setPartOrganization(partOrganization);
                    request.getPartReceiptLines().set(i,part);
                }
            }

            activeLine += 1;
            postRequest = requestBuilder.getPoReceiptRequestBuilder().getPOReceiptActiveLine(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, activeLine);
            response = requestSender.sendPostRequest(postRequest, host);
        }

        //Approves all lines
        postRequest = requestBuilder.getPoReceiptRequestBuilder().approvePOReceiptActiveLine(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), poReceiptCode, poReceipt.getOrganization());
        requestSender.sendPostRequest(postRequest, host);

        //Approves receipt
        postRequest = requestBuilder.getPoReceiptRequestBuilder().putPOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(),poReceipt.getCode(),poReceipt.getOrganization(),poReceipt.getDescription(),"A",poReceipt.getPurchaseOrder().getCode(),poReceipt.getPurchaseOrder().getOrganization(),poReceipt.getPurchaseOrder().getSupplier().getCode(),poReceipt.getPurchaseOrder().getSupplier().getOrganization(),poReceipt.getPurchaseOrder().getStore().getCode(),poReceipt.getPurchaseOrder().getStore().getOrganization(),poReceipt.getDateReceived().getYear(),poReceipt.getDateReceived().getMonthValue(),poReceipt.getDateReceived().getDayOfMonth(),poReceipt.getDateReceivedTimeZone(),poReceipt.getUpdateCount());
        requestSender.sendPostRequest(postRequest,host);

        if (request.getPartReceiptLines() == null) request.setPartReceiptLines(new ArrayList<>());
        request.setMessage("Transação realizada com sucesso.");
        request.setHttp("200");
        return request;
    }
}
