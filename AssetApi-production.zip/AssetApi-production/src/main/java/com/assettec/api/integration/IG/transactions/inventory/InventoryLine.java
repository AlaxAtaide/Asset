package com.assettec.api.integration.IG.transactions.inventory;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class InventoryLine {
    Long id;

    String partCode;
    String partName;
    String partOrganization;
    String store;
    String lastPrice;
    String basePrice;
    String averagePrice;
    String standardPrice;
    double quantityInStore;
}
