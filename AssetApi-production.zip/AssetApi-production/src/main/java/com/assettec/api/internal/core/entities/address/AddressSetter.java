package com.assettec.api.internal.core.entities.address;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class AddressSetter {

    public Address setAddress(NodeList childNodes) {
        Address address = new Address();
        address.setUpdatedCount(childNodes.item(0).getParentNode().getAttributes().getNamedItem("updatecount").getTextContent());

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("ADDRESSID")) setAddressId(address, childNode.getChildNodes());
            if (childNode.getNodeName().equals("TEXT")) address.setText(childNode.getTextContent());
            if (childNode.getNodeName().equals("ADDRESS1")) address.setAddress1(childNode.getTextContent());
            if (childNode.getNodeName().equals("ADDRESS2")) address.setAddress2(childNode.getTextContent());
            if (childNode.getNodeName().equals("ADDRESS3")) address.setAddress3(childNode.getTextContent());
            if (childNode.getNodeName().equals("CITY")) address.setCity(childNode.getTextContent());
            if (childNode.getNodeName().equals("STATE")) address.setState(childNode.getTextContent());
            if (childNode.getNodeName().equals("ZIP")) address.setZip(childNode.getTextContent());
            if (childNode.getNodeName().equals("COUNTRY")) address.setCountry(childNode.getTextContent());
            if (childNode.getNodeName().equals("PHONE")) address.setPhone(childNode.getTextContent());
            if (childNode.getNodeName().equals("PHONEEXT")) address.setPhoneExt(childNode.getTextContent());
            if (childNode.getNodeName().equals("FAX")) address.setFax(childNode.getTextContent());
            if (childNode.getNodeName().equals("EMAIL")) address.setEmail(childNode.getTextContent());

        }

        return address;
    }

    private void setAddressId(Address address, NodeList childNodes) {
        for (int j = 0; j < childNodes.getLength(); j++) {
            Node addressIdNode = childNodes.item(j);

            if (addressIdNode.getNodeName().equals("CODE")) address.setCode(addressIdNode.getTextContent());
            if (addressIdNode.getNodeName().equals("ENTITY")) address.setEntity(addressIdNode.getTextContent());
            if (addressIdNode.getNodeName().equals("TYPE")) address.setType(addressIdNode.getTextContent());
        }
    }
}
