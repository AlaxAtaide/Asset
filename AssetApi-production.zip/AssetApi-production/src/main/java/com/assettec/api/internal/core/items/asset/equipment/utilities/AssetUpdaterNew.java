package com.assettec.api.internal.core.items.asset.equipment.utilities;

import com.assettec.api.internal.core.entities.address.AddressSetter;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class AssetUpdaterNew {

    private AddressSetter addressSetter;
    private AssetSetterNew assetSetterNew;

    public AssetEquipment updateAsset(AssetEquipment asset, NodeList resultDataChildNodes) {
        for (int i = 0; i < resultDataChildNodes.getLength(); i++) {
            Node childNode = resultDataChildNodes.item(i);
            if (childNode.getNodeName().equals("AssetEquipment")) asset = assetSetterNew.setAsset(asset, childNode.getChildNodes());
            if (childNode.getNodeName().equals("Addresses")) asset.setAddresses(addressSetter.setAddress(childNode.getChildNodes()));
        }
        return asset;
    }
}