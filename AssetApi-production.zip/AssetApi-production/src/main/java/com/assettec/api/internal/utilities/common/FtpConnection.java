package com.assettec.api.internal.utilities.common;


import lombok.SneakyThrows;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;

@Component
public class FtpConnection {

    @SneakyThrows
    public static FTPClient connect(String url, String user, String password, int port) {

        FTPClient ftpClient = new FTPClient();
        ftpClient.connect( url,port );
        ftpClient.login( user, password );

        return ftpClient;
    }

    @SneakyThrows
    public static FTPSClient connectFTPS(String url, String user, String password, int port, boolean implicit) {

        FTPSClient ftpsClient = new FTPSClient(implicit);
        ftpsClient.connect( url,port );
        ftpsClient.login( user, password );

        return ftpsClient;
    }

    @SneakyThrows
    public static void listFiles(FTPClient ftpClient) {
        String[] arq = ftpClient.listNames();

        if (arq != null) {
            for (String f : arq){
                System.out.println(f);
            }
        }
    }

}



