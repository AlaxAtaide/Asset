package com.assettec.api.internal.core.entities.basic.setter;

import com.assettec.api.internal.core.entities.basic.objects.Id.*;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.task.TaskId;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.Arrays;
import java.util.List;

@Component
@AllArgsConstructor
public class IdSetter {

    private CodeSetter codeSetter;
    private CountSetter countSetter;

    public Id setCostCodeId(NodeList nodeList) {
        Id id = new Id();

        id.setCode(nodeList.item(0).getTextContent());
        id.setDescription(nodeList.item(1).getTextContent());
        id.setOrganization(codeSetter.setCode(nodeList.item(2).getChildNodes()));

        return id;
    }

    public Id setId(NodeList nodeList) {
        Id id = new Id();

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node childNode = nodeList.item(i);
            String nodeName = childNode.getNodeName();
            if (checkAcceptedIdList(nodeName)) id.setCode(childNode.getTextContent());
            if (nodeName.equals("DESCRIPTION")) id.setDescription(childNode.getTextContent());
            if (nodeName.contains("ORGANIZATION")) id.setOrganization(codeSetter.setOrganization(childNode.getChildNodes()));
        }

        return id;
    }

    public TaskId setTaskId(NodeList childNodes) {
        TaskId taskId = new TaskId();

        for (int j = 0; j < childNodes.getLength(); j++) {
            Node childNode = childNodes.item(j);

            if (childNode.getNodeName().equals("TASKCODE")) taskId.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("TASKREVISION")) taskId.setRevision(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) taskId.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) taskId.setDescription(childNode.getTextContent());
            if (childNode.getNodeName().equals("TASKQUANTITY")) taskId.setTaskQuantity(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TASKUOM")) taskId.setTaskUom(codeSetter.setCode(childNode.getChildNodes()));
        }

        return taskId;
    }

    public IdRevision setIdRevision(NodeList childNodes) {
        IdRevision idRevision = new IdRevision();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("CODE")) idRevision.setCode(childNode.getTextContent());
            if (childNode.getNodeName().contains("REVISION")) idRevision.setRevision(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) idRevision.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) idRevision.setDescription(childNode.getTextContent());
        }

        return idRevision;
    }

    public IdNumber setIdNumber(NodeList childNodes) {
        IdNumber idNumber = new IdNumber();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("CODE")) idNumber.setCode(childNode.getTextContent());
            if (childNode.getNodeName().contains("NUMBER")) idNumber.setNumber(childNode.getTextContent());
            if (childNode.getNodeName().equals("ORGANIZATIONID")) idNumber.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESCRIPTION")) idNumber.setDescription(childNode.getTextContent());
        }

        return idNumber;
    }

    public IdEntity setEntity(NodeList childNodes) {
        IdEntity inforEamEntity = new IdEntity();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("ENTITY")) inforEamEntity.setEntity(childNode.getTextContent());
            if (childNode.getNodeName().contains("CODE")) inforEamEntity.setCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("DESCRIPTION")) inforEamEntity.setDescription(childNode.getTextContent());
        }

        return inforEamEntity;
    }

    public IdPk setIdPk(NodeList childNodes) {
        IdPk idPk = new IdPk();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("PK")) idPk.setPk(childNode.getTextContent());
            if (childNode.getNodeName().contains("CODE")) idPk.setCode(childNode.getTextContent());
            if (childNode.getNodeName().contains("DESCRIPTION")) idPk.setDescription(childNode.getTextContent());
            if (childNode.getNodeName().contains("ORGANIZATION")) idPk.setOrganization(codeSetter.setCode(childNode.getChildNodes()));
        }
        return idPk;
    }

    private boolean checkAcceptedIdList(String nodeName) {
        String[] acceptedList = {"JOBNUM","EQUIPMENTUSABILITY"};
        List<String> stringList = Arrays.asList(acceptedList);

        if (stringList.contains(nodeName) || nodeName.contains("CODE")) return true;
        if (nodeName.equals("DESCRIPTION") || nodeName.contains("ORGANIZATION")) return false;
        else throw new IllegalStateException("node: " + nodeName + " is not in acceptedCodeList.");
    }

    public IdLineNum setIdLineNum(NodeList childNodes) {
        IdLineNum idLineNum = new IdLineNum();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().contains("ID")) idLineNum.setId(setId(childNode.getChildNodes()));
            if (childNode.getNodeName().contains("LINE")) idLineNum.setLineNum(childNode.getTextContent());
        }

        return idLineNum;
    }
}
