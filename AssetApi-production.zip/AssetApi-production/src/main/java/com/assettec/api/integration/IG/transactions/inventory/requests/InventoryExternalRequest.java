package com.assettec.api.integration.IG.transactions.inventory.requests;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class InventoryExternalRequest {
    private String partCode;
    private String partOrganization;
    private String store;
}
