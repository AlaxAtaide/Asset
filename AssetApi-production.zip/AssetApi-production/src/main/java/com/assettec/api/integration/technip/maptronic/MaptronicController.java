package com.assettec.api.integration.technip.maptronic;

import com.assettec.api.internal.core.items.asset.AssetService;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import com.assettec.api.internal.core.orders.workorder.WorkOrderService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "workorder/equipment")
@AllArgsConstructor
public class MaptronicController {
    private ApiUserService apiUserService;
    private WorkOrderService workOrderService;
    private AssetService assetService;
    @Operation(summary = "Creates WorkOrder upon receiving alert")
    @PostMapping() @SneakyThrows
    public CompletableFuture<String> postEquipmentWorkOrder(@RequestParam(name = "token") String token, @RequestParam(name = "equipmentCode") String equipmentCode, @RequestParam(name = "equipmentOrganization") String equipmentOrganization, @RequestParam(name = "workOrderDescription") String workOrderDescription, @RequestParam(name = "workOrderType", required = false) String workOrderType, @RequestParam(name = "workOrderStatus", required = false) String workOrderStatus) {
        if (equipmentCode == null) throw new IllegalAccessException("Code must not be null");
        if (equipmentOrganization == null) throw new IllegalAccessException("Organization must not be null");
        if (workOrderDescription == null) throw new IllegalAccessException("Description must not be null");
        if (workOrderType == null || workOrderType.isEmpty()) workOrderType = "PFMC";
        if (workOrderStatus == null || workOrderStatus.isEmpty()) workOrderStatus = "PFAB";

        ApiUser apiUser = apiUserService.findByToken(token);
        AssetEquipment assetEquipment = assetService.getAsset(apiUser, equipmentCode, equipmentOrganization);
        if (Objects.equals(assetEquipment.getStatus(), "D")) throw new IllegalAccessException("Equipment is not installed in this organization: " + equipmentOrganization);

        return CompletableFuture.completedFuture(workOrderService.postWorkOrder(apiUser, assetEquipment.getOrganization(), workOrderDescription, workOrderStatus,assetEquipment.getCode(),assetEquipment.getOrganization(),assetEquipment.getDepartment(),workOrderType));
    }
}
