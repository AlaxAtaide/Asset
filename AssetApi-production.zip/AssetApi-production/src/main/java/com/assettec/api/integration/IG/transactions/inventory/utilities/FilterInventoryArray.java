package com.assettec.api.integration.IG.transactions.inventory.utilities;

import com.assettec.api.integration.IG.transactions.inventory.InventoryLine;
import com.assettec.api.integration.IG.transactions.inventory.InventoryLineService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
@AllArgsConstructor
public class FilterInventoryArray {

    public List<InventoryLine> byStoreCodeAndOrganization(String store, String partCode, String partOrganization, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getStore(), store) && Objects.equals(inventoryLine.getPartCode(), partCode) && Objects.equals(inventoryLine.getPartOrganization(), partOrganization))
                inventoryLines.add(inventoryLine);
        }
        InventoryLine inventoryLine = new InventoryLine();
        InventoryLineService.joinSimilarLines(inventoryLines, inventoryLine);
        inventoryLines.clear();
        inventoryLines.add(inventoryLine);

        return inventoryLines;
    }

    public List<InventoryLine> byStore(String store, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getStore(), store))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }

    public List<InventoryLine> byPartCode(String partCode, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getPartCode(), partCode))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }

    public List<InventoryLine> byOrganization(String partOrganization, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getPartOrganization(), partOrganization))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }

    public List<InventoryLine> byCodeStore(String partCode, String store, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getStore(), store) && Objects.equals(inventoryLine.getPartCode(), partCode))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }

    public List<InventoryLine> byStoreOrganization(String store, String partOrganization, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getStore(), store) && Objects.equals(inventoryLine.getPartOrganization(), partOrganization))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }

    public List<InventoryLine> byCodeOrg(String partCode, String partOrganization, List<InventoryLine> allInventoryLines) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        for (InventoryLine inventoryLine : allInventoryLines) {
            if (Objects.equals(inventoryLine.getPartCode(), partCode) && Objects.equals(inventoryLine.getPartOrganization(), partOrganization))
                inventoryLines.add(inventoryLine);
        }
        return inventoryLines;
    }
}
