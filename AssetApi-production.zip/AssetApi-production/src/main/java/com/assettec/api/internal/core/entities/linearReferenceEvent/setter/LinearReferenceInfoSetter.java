package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.LinearReferenceInfo;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class LinearReferenceInfoSetter {

    private LinearReferenceEventSetter linearReferenceEventSetter;

    public LinearReferenceInfo setLinearReferenceInfo(NodeList childNodes) {
        LinearReferenceInfo linearReferenceInfo = new LinearReferenceInfo();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("LINEARREFERENCEEVENT")) linearReferenceInfo.setLinearReferenceEvent(linearReferenceEventSetter.setLinearReferenceEvent(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("INSPECTIONDIRECTIONCODE")) linearReferenceInfo.setInspectionDirectionCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("FLOWCODE")) linearReferenceInfo.setFlowCode(childNode.getTextContent());
        }

        return linearReferenceInfo;
    }
}
