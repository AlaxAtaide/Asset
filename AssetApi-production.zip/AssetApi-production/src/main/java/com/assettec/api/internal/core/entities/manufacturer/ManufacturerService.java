package com.assettec.api.internal.core.entities.manufacturer;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

@Service
@AllArgsConstructor
public class ManufacturerService {
    private ManufacturerSetter manufacturerSetter;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public Manufacturer getManufacturer(ApiUser apiUser, String manufacturerCode, String manufacturerOrganization) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getManufacturerRequestBuilder().getManufacturer(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), manufacturerCode, manufacturerOrganization);
        String response = requestSender.sendPostRequest(postRequest,host);

        Document xmlData = xmlParser.toDocument(response);
        return manufacturerSetter.setManufacturer(xmlData, new Manufacturer());
    }
}
