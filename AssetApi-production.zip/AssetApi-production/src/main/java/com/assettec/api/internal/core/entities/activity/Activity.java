package com.assettec.api.internal.core.entities.activity;

import com.assettec.api.internal.core.entities.basic.objects.*;
import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.LinearReferenceEvent;
import com.assettec.api.internal.core.entities.task.TaskId;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Activity {
    private ActivityId activityId;

    private Id tradeId;
    private String multipleTrades;
    private String planningLevel;

    private Id departmentId;
    private String estimatedHours;
    private String HoursRemaining;

    private String persons;
    private InforEamCount totalEstimatedHours;
    private InforEamCount totalHoursRemaining;

    private InforEamCount totalPeopleRequired;
    private TaskId taskId;
    private CodeRevision matList;

    private String completed;
    private String completedPercentage;
    private InforEamDate startDate;

    private InforEamDate endDate;
    private InforEamDate lastScheduledDate;
    private String scheduledHours;

    private String hiredLabor;
    private InforEamCode laborType;
    private Id supplierId;

    private InforEamCurrency normalWorkedHours;
    private InforEamCurrency overTimeWorkHours;
    private String sourceSystem;

    private String sourceCode;
    private String reasonForRepair;
    private String workAccomplished;
    private String technicianPartFailure;

    private InforEamCode level;
    private Id manufacturerId;
    private String warranty;

    private String activityComment;
    private Id relatedWorkOrderId;
    private String deferMaintenance;

    private String deferActDirectMats;
    private ActivityId originalWorkOrderActivityId;
    private String partLocationCode;

    private InforEamCount dbSessionId;
    private InforEamCode schedulingSessionType;
    private RelatedWorkOrderEquipment workOrderEquipments;

    private UserDefinedFields userDefinedFields;
    private String linearReferenceUOM;

    private LinearReferenceEvent linearReferenceEvent;
    private Id headerEquipmentId;
    private String topParentActivityCode;

    private String parentActivityCode;
    private String jobSequence;
    private String oldJobSequence;

    private String isWorkOrderJob;
    private String reusable;
    private InforEamCode currency;

    private InforEamCurrency estimatedLaborCost;
    private InforEamCurrency estimatedMaterialCost;
    private InforEamCurrency estimatedMiscellaneousCost;
    private InforEamCurrency estimatedTotalCost;

    private InforEamCode assignmentStatus;
    private Id preferredSupplier;

    public String buildRequest() {

        String activityId = getActivityId() == null ? "" : getActivityId().buildRequest("<ACTIVITYID xmlns=\"http://schemas.datastream.net/MP_fields\">","</ACTIVITYID>","<WORKORDERID auto_generated=\"true\">","</WORKORDERID>","<ORGANIZATIONID entity=\"RequisitionDefault\">","</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION","ACTIVITYCODE","ACTIVITYNOTE");
        String tradeId = getTradeId() == null ? "" : getTradeId().buildRequest("<TRADEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</TRADEID>","<ORGANIZATIONID entity=\"RequisitionLine\">","</ORGANIZATIONID>","TRADECODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String multipleTrades = getMultipleTrades() == null || getMultipleTrades().isEmpty() ? "" : "<MULTIPLETRADES xmlns=\"http://schemas.datastream.net/MP_fields\">" + getMultipleTrades() + "</MULTIPLETRADES>";
        String planningLevel = getPlanningLevel() == null || getPlanningLevel().isEmpty() ? "" : "<PLANNINGLEVEL xmlns=\"http://schemas.datastream.net/MP_fields\">" + getPlanningLevel() + "</PLANNINGLEVEL>";

        String departmentId = getDepartmentId() == null ? "" : getDepartmentId().buildRequest("<DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">","</DEPARTMENTID>","<ORGANIZATIONID entity=\"RequisitionLineDefault\">","</ORGANIZATIONID>","DEPARTMENTCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String estimatedHours = getEstimatedHours() == null || getEstimatedHours().isEmpty() ? "" : "<ESTIMATEDHOURS xmlns=\"http://schemas.datastream.net/MP_fields\">" + getEstimatedHours() + "</ESTIMATEDHOURS>";
        String hoursRemaining = getHoursRemaining() == null || getHoursRemaining().isEmpty() ? "" : "<HOURSREMAINING xmlns=\"http://schemas.datastream.net/MP_fields\">" + getHoursRemaining() + "</HOURSREMAINING>";
        String persons = getPersons() == null || getPersons().isEmpty() ? "" : "<PERSONS xmlns=\"http://schemas.datastream.net/MP_fields\">" + getPersons() + "</PERSONS>";

        String totalEstimatedHours = getTotalEstimatedHours() == null ? "" : "<TOTALESTIMATEDHOURS qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                getTotalEstimatedHours().buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</TOTALESTIMATEDHOURS>";

        String totalHoursRemaining = getTotalHoursRemaining() == null ? "" : "<TOTALHOURSREMAINING qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                getTotalHoursRemaining().buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</TOTALHOURSREMAINING>";

        String totalPeopleRequired = getTotalPeopleRequired() == null ? "" : "<TOTALPEOPLEREQUIRED qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                getTotalPeopleRequired().buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</TOTALPEOPLEREQUIRED>";

        String taskId = getTaskId() == null ? "" : getTaskId().buildRequest("<TASKSID xmlns=\"http://schemas.datastream.net/MP_fields\">","</TASKSID>");
        String matList = getMatList() == null ? "" : getMatList().buildRequest("<MATLIST xmlns=\"http://schemas.datastream.net/MP_fields\">","</MATLIST>","MTLCODE","MTLREVISION","DESCRIPTION");

        String completed = getCompleted() == null ? "" : "<COMPLETED xmlns=\"http://schemas.datastream.net/MP_fields\">" + getCompleted() + "</COMPLETED>";
        String percentCompleted = getCompletedPercentage() == null ? "" : "<PERCENTCOMPLETED xmlns=\"http://schemas.datastream.net/MP_fields\">" + getCompletedPercentage() + "</PERCENTCOMPLETED>";

        String activityStartDate = getStartDate() == null ? "" : getStartDate().buildRequest("<ACTIVITYSTARTDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ACTIVITYSTARTDATE>");
        String activityEndDate = getEndDate() == null ? "" : getEndDate().buildRequest("<ACTIVITYENDDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ACTIVITYENDDATE>");

        String dateLastScheduled = getLastScheduledDate() == null ? "" : getLastScheduledDate().buildRequest("<DATELASTSCHEDULED qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</DATELASTSCHEDULED>");

        String scheduledHours = getScheduledHours() == null ? "" : "<SCHEDULEDHOURS xmlns=\"http://schemas.datastream.net/MP_fields\">" + getScheduledHours() + "</SCHEDULEDHOURS>";
        String hiredLabor = getHiredLabor() == null ? "" : "<HIREDLABOR xmlns=\"http://schemas.datastream.net/MP_fields\">" + getHiredLabor() + "</HIREDLABOR>";

        String laborType = getLaborType() == null ? "" : getLaborType().buildRequest("<LABORTYPE xmlns=\"http://schemas.datastream.net/MP_fields\">","</LABORTYPE>","LABORTYPECODE","DESCRIPTION");
        String supplierId = getSupplierId() == null ? "" : getSupplierId().buildRequest("<SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">","</SUPPLIERID>","<ORGANIZATIONID entity=\"WorkOrder\">","</ORGANIZATIONID>","SUPPLIERCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String normalWorkedHours = getNormalWorkedHours() == null ? "" : getNormalWorkedHours().buildRequest("<NORMALHOURSWORKED qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</NORMALHOURSWORKED>");
        String overTimeHoursWorked = getOverTimeWorkHours() == null ? "" : getOverTimeWorkHours().buildRequest( "<OVERTIMEHOURSWORKED qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</OVERTIMEHOURSWORKED>");

        String sourceSystem = getSourceSystem() == null ? "" : "<SOURCESYSTEM xmlns=\"http://schemas.datastream.net/MP_fields\">" + getSourceSystem() + "</SOURCESYSTEM>";
        String sourceCode = getSourceCode() == null ? "" : "<SOURCECODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getSourceCode() + "</SOURCECODE>";
        String reasonForRepair = getReasonForRepair() == null ? "" : "<REASONFORREPAIR xmlns=\"http://schemas.datastream.net/MP_fields\">" + getReasonForRepair() + "</REASONFORREPAIR>";
        String workAccomplished = getWorkAccomplished() == null ? "" : "<WORKACCOMPLISHED xmlns=\"http://schemas.datastream.net/MP_fields\">" + getWorkAccomplished() + "</WORKACCOMPLISHED>";
        String technicalFailure = getTechnicianPartFailure() == null ? "" : "<TECHNICIANPARTFAILURE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getTechnicianPartFailure() + "</TECHNICIANPARTFAILURE>";
        String vmrsCode = getLevel() == null ? "" : getLevel().buildRequest("<VMRSCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + "<SYSTEMLEVELID>","</SYSTEMLEVELID>" + "</VMRSCODE>","SYSTEMLEVELCODE","DESCRIPTION");
        String manufacturerId = getManufacturerId() == null ? "" : getManufacturerId().buildRequest("<MANUFACTURERID xmlns=\"http://schemas.datastream.net/MP_fields\">","</MANUFACTURERID>","<ORGANIZATIONID entity=\"Part\">","</ORGANIZATIONID>","MANUFACTURERCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String warranty = getWarranty() == null ? "" : "<WARRANTY xmlns=\"http://schemas.datastream.net/MP_fields\">" + getWarranty() + "</WARRANTY>";
        String activityComment = getActivityComment() == null ? "" : "<ACTIVITYCOMMENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + getActivityComment() + "</ACTIVITYCOMMENT>";
        String relatedWorkOrder = getRelatedWorkOrderId() == null ? "" : getRelatedWorkOrderId().buildRequest("<RELATEDWORKORDERID auto_generated=\"true\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</RELATEDWORKORDERID>","<ORGANIZATIONID entity=\"PartDefault\">","</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String deferMaintenance = getDeferMaintenance() == null ? "" : "<DEFERMAINTENANCE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getDeferMaintenance() + "</DEFERMAINTENANCE>";
        String deferActDirectMats = getDeferActDirectMats() == null ? "" : "<DEFERACTDIRECTMATS xmlns=\"http://schemas.datastream.net/MP_fields\">" + getDeferActDirectMats() + "</DEFERACTDIRECTMATS>";

        String originalWorkOrderAct = getOriginalWorkOrderActivityId() == null ? "" : getOriginalWorkOrderActivityId().buildRequest("<ORIGINALWORKORDERACTID xmlns=\"http://schemas.datastream.net/MP_fields\">" + "<ACTIVITYID>","</ORIGINALWORKORDERACTID>" + "</ACTIVITYID>","<WORKORDERID auto_generated=\"false\">", "</WORKORDERID>","<ORGANIZATIONID entity=\"PurchaseOrder\">", "</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION","ACTIVITYCODE","ACTIVITYNOTE");

        String partLocationCode = getPartLocationCode() == null ? "" : "<PARTLOCATIONCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getPartLocationCode() + "</PARTLOCATIONCODE>";
        String dbSessionId = getDbSessionId() == null ? "" : getDbSessionId().buildRequest("<DBSESSIONID qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</DBSESSIONID>");
        String schedulingSessionType = getSchedulingSessionType() == null ? "" : getSchedulingSessionType().buildRequest("<SCHEDULINGSESSIONTYPE entity=\"Organization\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</SCHEDULINGSESSIONTYPE>","TYPECODE","DESCRIPTION");

        String workOrderEquipments = getWorkOrderEquipments() == null ? "" : getWorkOrderEquipments().buildRequest("<WorkOrderEquipments>" + "<WorkOrderEquipment>","</WorkOrderEquipment>" + "</WorkOrderEquipments>");

        String userDefinedFields = getUserDefinedFields() == null ? "" : getUserDefinedFields().buildRequest("<UserDefinedFields>","</UserDefinedFields>");
        String linearReferenceUOM = getLinearReferenceUOM() == null ? "" : "<LINEARREFUOM xmlns=\"http://schemas.datastream.net/MP_fields\">" + getLinearReferenceUOM() + "</LINEARREFUOM>";

        String linearReferenceEvent = getLinearReferenceEvent() == null ? "" : getLinearReferenceEvent().buildRequest("<LINEARREFERENCEEVENT xmlns=\"http://schemas.datastream.net/MP_fields\">","</LINEARREFERENCEEVENT>");

        String headerEquipment = getHeaderEquipmentId() == null ? "" : getHeaderEquipmentId().buildRequest("<HEADEREQUIPMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">","</HEADEREQUIPMENTID>","<ORGANIZATIONID entity=\"Store\">","</ORGANIZATIONID>","EQUIPMENTCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String topParentActivity = getTopParentActivityCode() == null ? "" : "<TOPPARENTACTIVITYCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getTopParentActivityCode() + "</TOPPARENTACTIVITYCODE>";
        String parentActivity = getParentActivityCode() == null ? "" : "<PARENTACTIVITYCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getParentActivityCode() + "</PARENTACTIVITYCODE>";
        String jobSequence = getJobSequence() == null ? "" : "<JOBSEQUENCE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getJobSequence() + "</JOBSEQUENCE>";
        String oldJobSequence = getOldJobSequence() == null ? "" : "<OLDJOBSEQUENCE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getOldJobSequence() + "</OLDJOBSEQUENCE>";
        String isWorkOrderJob = getIsWorkOrderJob() == null ? "" : "<ISWORKORDERJOB xmlns=\"http://schemas.datastream.net/MP_fields\">" + getIsWorkOrderJob() + "</ISWORKORDERJOB>";
        String reusable = getReusable() == null ? "" : "<REUSABLE xmlns=\"http://schemas.datastream.net/MP_fields\">" + getReusable() + "</REUSABLE>";
        String currencyId = getCurrency() == null ? "" : getCurrency().buildRequest("<CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">","</CURRENCYID>","CURRENCYCODE","DESCRIPTION");

        String estimatedLaborCost = getEstimatedLaborCost() == null ? "" : getEstimatedLaborCost().buildRequest("<ESTIMATEDLABORCOST qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ESTIMATEDLABORCOST>");
        String estimatedMaterialCost = getEstimatedMaterialCost() == null ? "" : getEstimatedMaterialCost().buildRequest("<ESTIMATEDMATERIALCOST qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ESTIMATEDMATERIALCOST>");

        String estimatedMiscellaneousCost = getEstimatedMiscellaneousCost() == null ? "" : getEstimatedMiscellaneousCost().buildRequest("<ESTIMATEDMISCELLANEOUSCOST qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ESTIMATEDMISCELLANEOUSCOST>");
        String estimatedTotalCost = getEstimatedTotalCost() == null ? "" : getEstimatedTotalCost().buildRequest("<ESTIMATEDTOTALCOST qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ESTIMATEDTOTALCOST>");

        String assignmentStatus = getAssignmentStatus() == null ? "" : getAssignmentStatus().buildRequest("<ASSIGNMENTSTATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ASSIGNMENTSTATUS>","STATUSCODE","DESCRIPTION");
        String preferredSupplier = getPreferredSupplier() == null ? "" : getPreferredSupplier().buildRequest("<PREFERREDSUPPLIER xmlns=\"http://schemas.datastream.net/MP_fields\">","</PREFERREDSUPPLIER>","<ORGANIZATIONID entity=\"StoreDefault\">","</ORGANIZATIONID>","SUPPLIERCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        return  "<Activities>" +
                "<Activity recordid=\"-1\" copyvmrsfields=\"false\" is_new=\"true\" has_transaction=\"has_1\" has_active_po=\"has_1\" has_active_req=\"has_1\" has_booked_hours=\"has_1\" is_ppm_act=\"is_p1\" is_warranty_claim=\"is_w1\" has_checklistitems_updated=\"false\" has_wo_act_detail_records=\"false\" has_wo_act_detail_records_including_qual=\"false\" task_has_enhanced_planning=\"false\" has_jobs_or_multiple_trades=\"false\" number_of_plan_labor_records=\"0\" xmlns=\"http://schemas.datastream.net/MP_entities/Activity_001\">" +
                activityId +
                tradeId +
                multipleTrades +
                planningLevel +
                departmentId +
                estimatedHours +
                hoursRemaining +
                persons +
                totalEstimatedHours +
                totalHoursRemaining +
                totalPeopleRequired +
                taskId +
                matList +
                completed +
                percentCompleted +
                activityStartDate +
                activityEndDate +
                dateLastScheduled +
                scheduledHours +
                hiredLabor +
                laborType +
                supplierId +
                normalWorkedHours +
                overTimeHoursWorked +
                sourceSystem +
                sourceCode +
                reasonForRepair +
                workAccomplished +
                technicalFailure +
                vmrsCode +
                manufacturerId +
                warranty +
                activityComment +
                relatedWorkOrder +
                deferMaintenance +
                deferActDirectMats +
                originalWorkOrderAct +
                partLocationCode +
                dbSessionId +
                schedulingSessionType +
                workOrderEquipments +
                userDefinedFields +
                linearReferenceUOM +
                linearReferenceEvent +
                headerEquipment +
                topParentActivity +
                parentActivity +
                jobSequence +
                oldJobSequence +
                isWorkOrderJob +
                reusable +
                currencyId +
                estimatedLaborCost +
                estimatedMaterialCost +
                estimatedMiscellaneousCost +
                estimatedTotalCost +
                assignmentStatus +
                preferredSupplier +
                "</Activity>" +
                "</Activities>";
    }
}
