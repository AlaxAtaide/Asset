package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EquipmentRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String getEquipment(String userName, String tenant, String passWord, String organization, String equipmentCode, String equipmentOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0302_GetAssetEquipment_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"AssetEquipment\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0302_001\">\n" +
                "            <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <EQUIPMENTCODE>" + equipmentCode + "</EQUIPMENTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + equipmentOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </ASSETID>\n" +
                "        </MP0302_GetAssetEquipment_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postEquipment(String userName, String tenant,  String passWord, String organization, String equipmentCode, String equipmentOrganization, String equipmentDescription, String equipmentType, String equipmentStatus, String departmentCode, String equipmentValue, String year, String month, String day, String timeZone, String cost, String serialNumber) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0301_AddAssetEquipment_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"AssetEquipment\" version=\"001\" confirm_availability_status=\"confirm_availability_status1\" confirmaddlinearreferences=\"confirmaddlinearreferences1\" confirmnewequipmentlength=\"confirmnewequipmentlength1\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0301_001\">\n" +
                "            <AssetEquipment recordid=\"1\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" autonumber=\"default\" creategis=\"true\" has_department_security=\"has_1\" has_readonly_department_security_for_createwo=\"has_1\" is_gis_webservice_request=\"false\" is_associated_to_current_consist=\"false\" is_default_rankings_available=\"false\" instructure=\"false\" haswo=\"false\" confirm_delete_surveryanswers=\"confirmed\" xmlns=\"http://schemas.datastream.net/MP_entities/AssetEquipment_001\">\n" +
                "                <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <EQUIPMENTCODE>" + equipmentCode + "</EQUIPMENTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + equipmentOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + equipmentDescription + "</DESCRIPTION>\n" +
                "                </ASSETID>\n" +
                "                <TYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + equipmentType + "</TYPECODE>\n" +
                "                </TYPE>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + equipmentStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <DEPARTMENTCODE>" + departmentCode + "</DEPARTMENTCODE>\n" +
                "                </DEPARTMENTID>\n" +
                "                <ASSETVALUE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + equipmentValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">XXX</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </ASSETVALUE>\n" +
                "                <PURCHASEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + year + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + month + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + day + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">1</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">1</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">1</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">1</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </PURCHASEDATE>\n" +
                "                <PURCHASECOST qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + cost + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">2</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">XXX</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </PURCHASECOST>\n" +
                "                <ManufacturerInfo>\n" +
                "                    <SERIALNUMBER xmlns=\"http://schemas.datastream.net/MP_fields\">" + serialNumber + "</SERIALNUMBER>\n" +
                "                </ManufacturerInfo>\n" +
                "            </AssetEquipment>\n" +
                "        </MP0301_AddAssetEquipment_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putEquipment(String userName, String tenant,  String passWord, String organization, String equipmentCode, String equipmentOrganization, String equipmentDescription, String equipmentType, String equipmentStatus, String departmentCode, String updatedCount, String year, String month, String day, String timeZone) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0303_SyncAssetEquipment_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"AssetEquipment\" version=\"001\" confirm_availability_status=\"confirm_availability_status1\" confirmaddlinearreferences=\"confirmaddlinearreferences1\" confirmnewequipmentlength=\"confirmnewequipmentlength1\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0303_001\">\n" +
                "            <AssetEquipment recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/AssetEquipment_001\">\n" +
                "                <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <EQUIPMENTCODE>" + equipmentCode + "</EQUIPMENTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + equipmentOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + equipmentDescription + "</DESCRIPTION>\n" +
                "                </ASSETID>\n" +
                "                <TYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + equipmentType + "</TYPECODE>\n" +
                "                </TYPE>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + equipmentStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <DEPARTMENTCODE>" + departmentCode + "</DEPARTMENTCODE>\n" +
                "                </DEPARTMENTID>\n" +
                "                <COMMISSIONDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + year + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + month + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + day + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </COMMISSIONDATE>\n" +
                "            </AssetEquipment>\n" +
                "        </MP0303_SyncAssetEquipment_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteEquipment(String userName, String tenant, String passWord, String organization, String equipmentCode, String equipmentOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0304_DeleteAssetEquipment_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"AssetEquipment\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0304_001\">\n" +
                "            <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <EQUIPMENTCODE>" + equipmentCode + "</EQUIPMENTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + equipmentOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </ASSETID>\n" +
                "        </MP0304_DeleteAssetEquipment_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
