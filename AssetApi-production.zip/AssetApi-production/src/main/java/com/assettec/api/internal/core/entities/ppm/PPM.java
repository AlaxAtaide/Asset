package com.assettec.api.internal.core.entities.ppm;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PPM {
    private String code;
    private String revision;
    private InforEamCode organization;
    private String description;

    public String buildRequest(String upper, String lower, String organizationUpper, String organizationLower, String codeLabel, String revisionLabel, String descriptionLabel, String organizationCodeLabel, String organizationDescriptionLabel) {

        String code = getCode() == null ? "" : "<" + codeLabel + ">" + getCode() + "</" + codeLabel + ">";
        String ppmRevision = getCode() == null ? "" : "<" + revisionLabel + ">" + getRevision() + "</" + revisionLabel + ">";
        String description = getDescription() == null ? "" : "<" + descriptionLabel + ">" + getDescription() + "</" + descriptionLabel + ">";
        String organization = getOrganization() == null ? "" : getOrganization().buildRequest(organizationUpper,organizationLower,organizationCodeLabel,organizationDescriptionLabel);

        return upper + code + ppmRevision + description + organization + lower;
    }
}
