package com.assettec.api.integration.IG.transactions.equipment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGAssetEquipmentSendGetRequest {
    private String equipmentCode;
    private String oldOrganization;
    private String newOrganization;
    private String equipmentDescription;
    private String equipmentType;
    private String equipmentStatus;
    private String equipmentDepartment;
    private double equipmentValue;
    private String equipmentSerialNumber;
    private String equipmentModel;
    private String equipmentState;
    private LocalDateTime purchaseDate;
    private double purchaseCost;
    private String codeIGERP;
    private String codeIGPAT;
    private String codeBEMIG;
    private String sent;
}
