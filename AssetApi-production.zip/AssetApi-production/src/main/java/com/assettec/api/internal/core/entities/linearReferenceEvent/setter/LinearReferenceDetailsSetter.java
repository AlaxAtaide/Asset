package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.LinearReferenceDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class LinearReferenceDetailsSetter {

    private CountSetter countSetter;
    private CodeSetter codeSetter;
    private OffsetDirectionSetter offsetDirectionSetter;

    public LinearReferenceDetails setLinearReferenceDetails(NodeList childNodes) {
        LinearReferenceDetails linearReferenceDetails = new LinearReferenceDetails();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("EQUIPMENTLENGTH")) linearReferenceDetails.setEquipmentLength(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("EQUIPMENTLENGTHUOM")) linearReferenceDetails.setEquipmentLengthUom(childNode.getTextContent());
            if (childNode.getNodeName().equals("LINEARREFUOM")) linearReferenceDetails.setLinearReferenceUom(childNode.getTextContent());
            if (childNode.getNodeName().equals("LINEARREFPRECISION")) linearReferenceDetails.setLinearReferencePrecision(childNode.getTextContent());
            if (childNode.getNodeName().equals("GEOGRAPHICALREFERENCE")) linearReferenceDetails.setGeographicalReference(childNode.getTextContent());
            if (childNode.getNodeName().equals("INSPECTIONDIRECTIONCODE")) linearReferenceDetails.setInspectionDirectionCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("FLOWCODE")) linearReferenceDetails.setFlowCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("LINEARCOSTWEIGHT")) linearReferenceDetails.setLinearCostWeight(childNode.getTextContent());
            if (childNode.getNodeName().equals("LRFFROMPOINT")) linearReferenceDetails.setLrfFromPoint(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LRFTOPOINT")) linearReferenceDetails.setLrfToPoint(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LINEARDIRECTIONID")) linearReferenceDetails.setLinearDirection(offsetDirectionSetter.setOffsetDirection(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LINEAREQUIPMENTTYPE")) linearReferenceDetails.setLinearEquipmentType(codeSetter.setCode(childNode.getChildNodes()));
        }

        return linearReferenceDetails;
    }
}
