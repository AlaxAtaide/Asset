package com.assettec.api.internal.core.entities.campaign;

import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class CampaignIdSetter {
    private IdSetter idSetter;

    public CampaignId setCampaignId(NodeList childNodes) {
        CampaignId campaignId = new CampaignId();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("CAMPAIGNID")) campaignId.setCampaignEventId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CAMPAIGNEVENT")) campaignId.setCampaignEvent(childNode.getTextContent());

        }

        return campaignId;
    }
}
