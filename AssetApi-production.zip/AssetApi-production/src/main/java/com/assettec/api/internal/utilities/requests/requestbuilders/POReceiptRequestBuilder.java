package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class POReceiptRequestBuilder {

    private XMLRequestHeader xmlRequestHeader;

    public String getPOReceipt(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1265_GetPOReceipt_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"POReceipt\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1265_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP1265_GetPOReceipt_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postPOReceipt(String userName, String tenant, String passWord, String organization, String poReceiptOrganization, String poReceiptDescription, String poReceiptStatus, String purchaseOrderCode, String purchaseOrderOrganization, String supplierCode, String supplierOrganization, String storeCode, String storeOrganization, String dateReceivedYear, String dateReceivedMonth, String dateReceivedDay, String timeZone) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1261_AddPOReceipt_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"POReceipt\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1261_001\">\n" +
                "            <POReceipt recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/POReceipt_001\">\n" +
                "                <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTCODE>*</PORECEIPTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + poReceiptDescription + "</DESCRIPTION>\n" +
                "                </PORECEIPTID>\n" +
                "                <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"Group\">\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Organization\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                    <ORGANIZATIONID entity=\"Class\">\n" +
                "                        <ORGANIZATIONCODE>" + storeOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </STOREID>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + poReceiptStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <DATERECEIVED qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DATERECEIVED>\n" +
                "            </POReceipt>\n" +
                "        </MP1261_AddPOReceipt_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPOReceipt(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, String poReceiptDescription, String poReceiptStatus, String purchaseOrderCode, String purchaseOrderOrganization, String supplierCode, String supplierOrganization, String storeCode, String storeOrganization, int dateReceivedYear, int dateReceivedMonth, int dateReceivedDay, String timeZone, int updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1262_SyncPOReceipt_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"POReceipt\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1262_001\">\n" +
                "            <POReceipt recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/POReceipt_001\">\n" +
                "                <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + poReceiptDescription + "</DESCRIPTION>\n" +
                "                </PORECEIPTID>\n" +
                "                <PURCHASEORDERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Group\">\n" +
                "                        <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PURCHASEORDERID>\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"Organization\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </SUPPLIERID>\n" +
                "                <STOREID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STORECODE>" + storeCode + "</STORECODE>\n" +
                "                    <ORGANIZATIONID entity=\"Class\">\n" +
                "                        <ORGANIZATIONCODE>" + storeOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </STOREID>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + poReceiptStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <DATERECEIVED qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + dateReceivedDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </DATERECEIVED>\n" +
                "            </POReceipt>\n" +
                "        </MP1262_SyncPOReceipt_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deletePOReceipt(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1263_DeletePOReceipt_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"POReceipt\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1263_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP1263_DeletePOReceipt_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String getPOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, int poReceiptLineNum) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1278_GetPOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1278_001\">\n" +
                "            <PORECEIPTLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTID>\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                </PORECEIPTID>\n" +
                "                <PORECEIPTLINENUM>" + poReceiptLineNum + "0</PORECEIPTLINENUM>\n" +
                "            </PORECEIPTLINEID>\n" +
                "        </MP1278_GetPOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String retrievePOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1279_RetrievePOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Retrieve\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1279_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP1279_RetrievePOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putPOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, int poReceiptLineNum, String purchaseOrderLineNum, String purchaseOrderCode, String purchaseOrderOrganization, String poReceiptLineStatus, String purchaseOrderType, String partCode, String partBin, String partOrganization, String inspectionStatus, String receiptQuantity, String receivedQuantity, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1276_SyncPOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"POReceiptActiveLine\" version=\"001\" confirm_returnqty_notequal_rejectqty=\"not_needed\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1276_001\">\n" +
                "                <POReceiptActiveLine xmlns:ns2=\"http://schemas.datastream.net/MP_entities/POReceiptActiveLine_001\" recordid=\"" + updatedCount + "\">\n" +
                "                <PORECEIPTLINEID xmlns:ns3=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTID>\n" +
                "                        <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                    </PORECEIPTID>\n" +
                "                    <PORECEIPTLINENUM>" + poReceiptLineNum + "0</PORECEIPTLINENUM>\n" +
                "                </PORECEIPTLINEID>\n" +
                "                <PARTID xmlns:ns4=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PARTCODE>" + partCode + "</PARTCODE>\n" +
                "                    <ORGANIZATIONID>\n" +
                "                        <ORGANIZATIONCODE>" + partOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PARTID>\n" +
                "                <BINID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <BIN>" + partBin + "</BIN>\n" +
                "                </BINID>\n" +
                "                <PURCHASEORDERTYPE xmlns:ns6=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + purchaseOrderType + "</TYPECODE>\n" +
                "                </PURCHASEORDERTYPE>\n" +
                "                <RECEIPTQUANTITY xmlns:ns7=\"http://schemas.datastream.net/MP_fields\" qualifier=\"OTHER\">\n" +
                "                    <VALUE xmlns:ns8=\"http://www.openapplications.org/oagis_fields\">" + receiptQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns:ns9=\"http://www.openapplications.org/oagis_fields\">6</NUMOFDEC>\n" +
                "                    <SIGN xmlns:ns10=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns:ns11=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </RECEIPTQUANTITY>\n" +
                "                <PURCHASEORDERLINEID xmlns:ns12=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PURCHASEORDERID>\n" +
                "                        <PURCHASEORDERCODE>" + purchaseOrderCode + "</PURCHASEORDERCODE>\n" +
                "                        <ORGANIZATIONID>\n" +
                "                            <ORGANIZATIONCODE>" + purchaseOrderOrganization + "</ORGANIZATIONCODE>\n" +
                "                        </ORGANIZATIONID>\n" +
                "                    </PURCHASEORDERID>\n" +
                "                    <PURCHASEORDERLINENUM>" + purchaseOrderLineNum + "</PURCHASEORDERLINENUM>\n" +
                "                </PURCHASEORDERLINEID>\n" +
                "                <INSPECTIONSTATUS xmlns:ns15=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + inspectionStatus + "</STATUSCODE>\n" +
                "                </INSPECTIONSTATUS>\n" +
                "                <RECEIVEDQUANTITY xmlns:ns16=\"http://schemas.datastream.net/MP_fields\" qualifier=\"OTHER\">\n" +
                "                    <VALUE xmlns:ns17=\"http://www.openapplications.org/oagis_fields\">" + receivedQuantity + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns:ns18=\"http://www.openapplications.org/oagis_fields\">6</NUMOFDEC>\n" +
                "                    <SIGN xmlns:ns19=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <UOM xmlns:ns20=\"http://www.openapplications.org/oagis_fields\">default</UOM>\n" +
                "                </RECEIVEDQUANTITY>\n" +
                "                <PORECEIPTLINESTATUS xmlns:ns22=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + poReceiptLineStatus + "</STATUSCODE>\n" +
                "                </PORECEIPTLINESTATUS>\n" +
                "            </POReceiptActiveLine>\n" +
                "        </MP1276_SyncPOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String approvePOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1280_ApprovePOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Approve\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1280_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "        </MP1280_ApprovePOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String cancelPOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, String poReceiptLineNum) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP1277_CancelPOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Cancel\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1277_001\">\n" +
                "            <PORECEIPTLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PORECEIPTID>\n" +
                "                <PORECEIPTLINENUM>" + poReceiptLineNum + "</PORECEIPTLINENUM>\n" +
                "            </PORECEIPTLINEID>\n" +
                "        </MP1277_CancelPOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String undoCancelPOReceiptActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, String poReceiptLineNum) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2155_UndoCancelPOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"UndoCancel\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2155_001\">\n" +
                "            <PORECEIPTLINEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                </PORECEIPTID>\n" +
                "                <PORECEIPTLINENUM>" + poReceiptLineNum + "</PORECEIPTLINENUM>\n" +
                "            </PORECEIPTLINEID>\n" +
                "        </MP2155_UndoCancelPOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String retrieveSingleActiveLine(String userName, String tenant, String passWord, String organization, String poReceiptCode, String poReceiptOrganization, String assetCode, String assetOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP2285_RetrieveSinglePOReceiptActiveLine_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"RetrieveSingle\" noun=\"POReceiptActiveLine\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP2285_001\">\n" +
                "            <PORECEIPTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <PORECEIPTCODE>" + poReceiptCode + "</PORECEIPTCODE> \n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + poReceiptOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </PORECEIPTID>\n" +
                "            <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <EQUIPMENTCODE>" + assetCode + "</EQUIPMENTCODE> \n" +
                "                <ORGANIZATIONID entity=\"Organization\">\n" +
                "                    <ORGANIZATIONCODE>" + assetOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </ASSETID>\n" +
                "        </MP2285_RetrieveSinglePOReceiptActiveLine_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
