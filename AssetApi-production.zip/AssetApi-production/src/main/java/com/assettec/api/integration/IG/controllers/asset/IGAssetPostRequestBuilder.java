package com.assettec.api.integration.IG.controllers.asset;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class IGAssetPostRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String postIGAsset(String userName, String tenant, String passWord, String organization, String equipmentCode, String equipmentOrg, String equipmentDesc, String equipmentType, String equipmentStatus, String equipmentDep, String equipmentClass, String equipmentCategory, int commissionDateYear, int commissionDateMonth, int commissionDateDay, String timeZone, String assetValue, String serialNumber, String model, String codeIGERP, String IGPAT, String BEMIG) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName, tenant, passWord, organization) +
                "    <Body>\n" +
                "        <MP0301_AddAssetEquipment_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"AssetEquipment\" version=\"001\" confirm_availability_status=\"confirm_availability_status1\" confirmaddlinearreferences=\"confirmaddlinearreferences1\" confirmnewequipmentlength=\"confirmnewequipmentlength1\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0301_001\">\n" +
                "            <AssetEquipment recordid=\"1\" user_entity=\"user_entity1\" system_entity=\"system_entity1\" autonumber=\"default\" creategis=\"true\" has_department_security=\"has_1\" has_readonly_department_security_for_createwo=\"has_1\" is_gis_webservice_request=\"false\" is_associated_to_current_consist=\"false\" is_default_rankings_available=\"false\" instructure=\"false\" haswo=\"false\" confirm_delete_surveryanswers=\"confirmed\" xmlns=\"http://schemas.datastream.net/MP_entities/AssetEquipment_001\">\n" +
                "                <ASSETID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <EQUIPMENTCODE>" + equipmentCode + "</EQUIPMENTCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + equipmentOrg + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + equipmentDesc + "</DESCRIPTION>\n" +
                "                </ASSETID>\n" +
                "                <TYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <TYPECODE>" + equipmentType + "</TYPECODE>\n" +
                "                </TYPE>\n" +
                "                <STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <STATUSCODE>" + equipmentStatus + "</STATUSCODE>\n" +
                "                </STATUS>\n" +
                "                <DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <DEPARTMENTCODE>" + equipmentDep + "</DEPARTMENTCODE>\n" +
                "                </DEPARTMENTID>\n" +
                "                <CLASSID entity=\"ent1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CLASSCODE>" + equipmentClass + "</CLASSCODE>\n" +
                "                </CLASSID>\n" +
                "                <CATEGORYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CATEGORYCODE>" + equipmentCategory + "</CATEGORYCODE>\n" +
                "                </CATEGORYID>\n" +
                "                <COMMISSIONDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + commissionDateYear + "</YEAR>\n" +
                "                    <MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + commissionDateMonth + "</MONTH>\n" +
                "                    <DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + commissionDateDay + "</DAY>\n" +
                "                    <HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">0</HOUR>\n" +
                "                    <MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">0</MINUTE>\n" +
                "                    <SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SECOND>\n" +
                "                    <SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">0</SUBSECOND>\n" +
                "                    <TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + timeZone + "</TIMEZONE>\n" +
                "                </COMMISSIONDATE>\n" +
                "                <ASSETVALUE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <VALUE xmlns=\"http://www.openapplications.org/oagis_fields\">" + assetValue + "</VALUE>\n" +
                "                    <NUMOFDEC xmlns=\"http://www.openapplications.org/oagis_fields\">6</NUMOFDEC>\n" +
                "                    <SIGN xmlns=\"http://www.openapplications.org/oagis_fields\">+</SIGN>\n" +
                "                    <CURRENCY xmlns=\"http://www.openapplications.org/oagis_fields\">BRL</CURRENCY>\n" +
                "                    <DRCR xmlns=\"http://www.openapplications.org/oagis_fields\">D</DRCR>\n" +
                "                </ASSETVALUE>\n" +
                "                <ManufacturerInfo>\n" +
                "                    <SERIALNUMBER xmlns=\"http://schemas.datastream.net/MP_fields\">" + serialNumber + "</SERIALNUMBER>\n" +
                "                    <MODEL xmlns=\"http://schemas.datastream.net/MP_fields\">" + model + "</MODEL>\n" +
                "                </ManufacturerInfo>\n" +
                "                <UserDefinedFields>\n" +
                "                    <UDFCHAR01 xmlns=\"http://schemas.datastream.net/MP_fields\">" + IGPAT + "</UDFCHAR01>\n" +
                "                    <UDFCHAR02 xmlns=\"http://schemas.datastream.net/MP_fields\">" + codeIGERP + "</UDFCHAR02>\n" +
                "                    <UDFCHAR09 xmlns=\"http://schemas.datastream.net/MP_fields\">" + BEMIG + "</UDFCHAR09>\n" +
                "                </UserDefinedFields>\n" +
                "            </AssetEquipment>\n" +
                "        </MP0301_AddAssetEquipment_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
