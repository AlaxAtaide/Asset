package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ActivityMobile {
    private String activityCode;
    private String tradeCode;
    private String taskCode;
    private String materialList;
    private String repairReason;
    private String workAccomplished;
    private String technicianPartFailure;
    private String manufacturerCode;
    private String activityStartDate;
    private String activityEndDate;
    private String estimatedHours;
    private String hoursRemaining;
    private String persons;
    private String systemLevel;
    private String assemblyLevel;
    private String componentLevel;
    private String partLocation;

    public static ActivityMobile createEmpty() {
        return new ActivityMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
