package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LinearReferenceDetailsMobile {
    private String fromPoint;
    private String fromPointDescription;
    private String fromRefDescription;
    private String fromGeoRef;

    private String toPoint;
    private String toPointDescription;
    private String toRefDescription;
    private String toGeoRef;

    private String inspectionDirection;
    private String flow;
    private String relationship;

    private String fromReference;
    private String fromOffsetPercentage;
    private String fromOffset;
    private String fromOffsetDirection;
    private String fromRelatedOffsetDirection;
    private String fromRelatedReference;
    private String fromRelatedOffset;
    private String fromCoordinateX;
    private String fromCoordinateY;
    private String fromLatitude;
    private String fromLongitude;
    private String fromVerticalRelationShip;
    private String fromHorizontalOffset;
    private String fromHorizontalOffsetType;
    private String fromVerticalOffset;
    private String fromVerticalOffsetType;

    private String toReference;
    private String toOffsetPercentage;
    private String toOffset;
    private String toOffsetDirection;
    private String toRelatedOffsetDirection;
    private String toRelatedReference;
    private String toRelatedOffset;
    private String toCoordinateX;
    private String toCoordinateY;
    private String toLatitude;
    private String toLongitude;
    private String toVerticalRelationShip;
    private String toHorizontalOffset;
    private String toHorizontalOffsetType;
    private String toVerticalOffset;
    private String toVerticalOffsetType;

    public static LinearReferenceDetailsMobile createEmpty() {
        return new LinearReferenceDetailsMobile("", "", "", "", "","","", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
