package com.assettec.api.internal.core.entities.activity;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RelatedWorkOrderEquipment {
    private Id equipmentId;
    private ActivityId relatedWorkOrderId;

    public String buildRequest(String upper, String lower) {

        String equipmentId = getEquipmentId() == null ? "" : getEquipmentId().buildRequest("<EQUIPMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">","</EQUIPMENTID>","<ORGANIZATIONID entity=\"AssetEquipmentDefault\">","</ORGANIZATIONID>","EQUIPMENTCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");
        String relatedWorkOrderId = getRelatedWorkOrderId() == null ? "" : getRelatedWorkOrderId().buildRequest("<RELATEDWORKORDERACTID xmlns=\"http://schemas.datastream.net/MP_fields\">" + "<ACTIVITYID>","</ACTIVITYID>" + "</RELATEDWORKORDERACTID>","<WORKORDERID auto_generated=\"true\">","</WORKORDERID>","<ORGANIZATIONID entity=\"BookedHours\">","</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION","ACTIVITYCODE","ACTIVITYNOTE");

        return upper + equipmentId + relatedWorkOrderId + lower;
    }
}
