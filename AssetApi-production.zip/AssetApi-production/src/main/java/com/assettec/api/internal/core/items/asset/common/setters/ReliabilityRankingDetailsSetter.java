package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.ReliabilityRankingDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ReliabilityRankingDetailsSetter {

    private IdSetter idSetter;
    private CountSetter countSetter;
    private DateSetter dateSetter;

    public ReliabilityRankingDetails setReliabilityRankingDetails(NodeList childNodes) {
        ReliabilityRankingDetails reliabilityRankingDetails = new ReliabilityRankingDetails();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("RELIABILITYRANKINGLOCKED")) reliabilityRankingDetails.setRankingLocked(childNode.getTextContent());
            if (childNode.getNodeName().equals("RELIABILITYRANKINGINDEXCODE")) reliabilityRankingDetails.setRankingIndexCode(childNode.getTextContent());
            if (childNode.getNodeName().equals("RELIABILITYRANKINGID")) reliabilityRankingDetails.setRankingId(idSetter.setIdRevision(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("RELIABILITYRANKINGSCORE")) reliabilityRankingDetails.setRankingScore(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("OUTOFSYNC")) reliabilityRankingDetails.setOutOfSync(childNode.getTextContent());
            if (childNode.getNodeName().equals("SETUPLASTUPDATEDDATE")) reliabilityRankingDetails.setSetupLastUpdate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SURVEYLASTUPDATEDDATE")) reliabilityRankingDetails.setSurveyLastUpdate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VALUESLASTCALCULATEDDATE")) reliabilityRankingDetails.setValuesLastUpdate(dateSetter.setDate(childNode.getChildNodes()));
        }

        return reliabilityRankingDetails;
    }
}
