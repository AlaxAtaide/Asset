package com.assettec.api.integration.IG.controllers.asset;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class IGAssetRegistrationRequest {

    private String http;
    private String message;

    private String equipmentCode;
    private String equipmentOrganization;
    private String equipmentDescription;
    private String equipmentType;
    private String equipmentStatus;
    private String equipmentDepartment;
    private String equipmentCategory;
    private String equipmentClass;
    private double equipmentValue;
    private String serialNumber;
    private String model;
    private String codeIGERP;
    private String codeIGPAT;
    private String codeBEMIG;
    private String commissionDate;

}
