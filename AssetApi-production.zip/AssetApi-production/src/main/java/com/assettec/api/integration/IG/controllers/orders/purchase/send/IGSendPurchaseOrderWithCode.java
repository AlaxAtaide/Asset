package com.assettec.api.integration.IG.controllers.orders.purchase.send;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGSendPurchaseOrderWithCode {
    private String http;
    private String message;
    private IGSendPurchaseOrder sendPurchaseOrder;
}
