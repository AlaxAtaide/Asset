package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ScheduleMobile {
    private String reportedBy;
    private String reportedDate;
    private String assignedBy;
    private String assignedTo;
    private String programedStartDate;
    private String programedEndDate;
    private String solicitedStartDate;
    private String solicitedEndDate;
    private String startDate;
    private String endDate;
    private String shift;
    private String budget;
    private String campaign;
    private String serviceRequestCode;

    public static ScheduleMobile createEmpty() {
        return new ScheduleMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
