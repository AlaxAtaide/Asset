package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IncidentMobile {
    private String patientIncident;
    private String staffInjuryIncident;
    private String securityIncident;
    private String propertyDamageIncident;
    private String hazardousMaterialsIncident;
    private String fireSafetyIncident;
    private String medicalEquipmentIncident;
    private String utilitySystemIncident;

    public static IncidentMobile createEmpty() {
        return new IncidentMobile("", "", "", "", "", "", "", "");
    }
}
