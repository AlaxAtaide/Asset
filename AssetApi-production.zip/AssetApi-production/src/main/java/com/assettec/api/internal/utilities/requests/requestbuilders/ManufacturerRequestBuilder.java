package com.assettec.api.internal.utilities.requests.requestbuilders;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ManufacturerRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String getManufacturer(String userName, String tenant,String passWord, String organization, String manufacturerCode, String manufacturerOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1253_GetManufacturer_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Get\" noun=\"Manufacturer\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1253_001\">\n" +
                "            <MANUFACTURERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <MANUFACTURERCODE>" + manufacturerCode + "</MANUFACTURERCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + manufacturerOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </MANUFACTURERID>\n" +
                "        </MP1253_GetManufacturer_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String postManufacturer(String userName, String tenant,String passWord, String organization, String manufacturerCode, String manufacturerOrganization, String manufacturerDescription) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1252_AddManufacturer_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Manufacturer\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1252_001\">\n" +
                "            <Manufacturer recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/Manufacturer_001\">\n" +
                "                <MANUFACTURERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <MANUFACTURERCODE>" + manufacturerCode + "</MANUFACTURERCODE> \n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + manufacturerOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + manufacturerDescription + "</DESCRIPTION>\n" +
                "                </MANUFACTURERID>\n" +
                "            </Manufacturer>\n" +
                "        </MP1252_AddManufacturer_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String putManufacturer(String userName, String tenant,String passWord, String organization, String manufacturerCode, String manufacturerOrganization, String manufacturerDescription, String updatedCount) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1254_SyncManufacturer_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Sync\" noun=\"Manufacturer\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1254_001\">\n" +
                "            <Manufacturer recordid=\"" + updatedCount + "\" xmlns=\"http://schemas.datastream.net/MP_entities/Manufacturer_001\">\n" +
                "                <MANUFACTURERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <MANUFACTURERCODE>" + manufacturerCode + "</MANUFACTURERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + manufacturerOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + manufacturerDescription + "</DESCRIPTION>\n" +
                "                </MANUFACTURERID>\n" +
                "            </Manufacturer>\n" +
                "        </MP1254_SyncManufacturer_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

    public String deleteManufacturer(String userName, String tenant,String passWord, String organization, String manufacturerCode, String manufacturerOrganization) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP1255_DeleteManufacturer_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Delete\" noun=\"Manufacturer\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP1255_001\">\n" +
                "            <MANUFACTURERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                <MANUFACTURERCODE>" + manufacturerCode + "</MANUFACTURERCODE>\n" +
                "                <ORGANIZATIONID entity=\"User\">\n" +
                "                    <ORGANIZATIONCODE>" + manufacturerOrganization + "</ORGANIZATIONCODE>\n" +
                "                </ORGANIZATIONID>\n" +
                "            </MANUFACTURERID>\n" +
                "        </MP1255_DeleteManufacturer_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }

}
