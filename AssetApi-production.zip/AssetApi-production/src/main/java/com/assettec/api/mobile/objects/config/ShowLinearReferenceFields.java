package com.assettec.api.mobile.objects.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ShowLinearReferenceFields implements Serializable {
    private boolean fromPoint;
    private boolean fromRefDescription;
    private boolean fromGeoRef;
    private boolean toPoint;
    private boolean toRefDescription;
    private boolean toGeoRef;
    private boolean inspectionDirection;
    private boolean flow;
    private boolean relationship;
    private boolean fromReferenceCode;
    private boolean fromOffsetPercent;
    private boolean fromOffsetDirectionCode;
    private boolean fromReferenceDescription;
    private boolean fromOffset;
    private boolean fromOffsetLinearReferenceDetails;
    private boolean toOffsetDirectionDescription;
    private boolean fromCoordinateX;
    private boolean fromCoordinateY;
    private boolean fromLatitude;
    private boolean fromLongitude;
    private boolean fromVerticalRelationShip;
    private boolean fromHorizontalOffset;
    private boolean fromHorizontalOffsetType;
    private boolean fromVerticalOffset;
    private boolean fromVerticalOffsetType;
    private boolean toReferenceCode;
    private boolean toOffsetPercent;
    private boolean toOffsetDirectionCode;
    private boolean toReferenceDescription;
    private boolean toOffset;
    private boolean toOffsetLinearReferenceDetails;
    private boolean fromOffsetDirectionDescription;
    private boolean toCoordinateX;
    private boolean toCoordinateY;
    private boolean toLatitude;
    private boolean toLongitude;
    private boolean toVerticalRelationShip;
    private boolean toHorizontalOffset;
    private boolean toHorizontalOffsetType;
    private boolean toVerticalOffset;
    private boolean toVerticalOffsetType;
}
