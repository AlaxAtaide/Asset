package com.assettec.api.integration.IG.controllers.part;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "part")
@AllArgsConstructor
public class IGPartController {
    private ApiUserService apiUserService;
    private IGPartService partService;

    @SneakyThrows
    @PostMapping()
    public IGPartRegistrationRequest registerPart(@RequestParam(name = "token") String token, @RequestBody IGPartRegistrationRequest request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return partService.registerPart(apiUser, request);
    }
}
