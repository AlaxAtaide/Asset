package com.assettec.api.internal.users;

import lombok.*;

import javax.validation.constraints.NotBlank;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class AppUser {
    @NotBlank
    private String username;
    @NotBlank
    private String password;
    @NotBlank
    private String organization;
    @NotBlank
    private String tenant;
    private String token;
}
