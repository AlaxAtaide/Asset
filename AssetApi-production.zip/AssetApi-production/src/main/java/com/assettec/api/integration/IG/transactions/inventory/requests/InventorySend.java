package com.assettec.api.integration.IG.transactions.inventory.requests;

import com.assettec.api.integration.IG.transactions.inventory.InventoryLine;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InventorySend {
    private String http;
    private String message;
    private List<InventoryLine> inventoryLines;
}
