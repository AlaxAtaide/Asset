package com.assettec.api.mobile.controllers;

import com.assettec.api.internal.users.AppUser;
import com.assettec.api.internal.users.status.UserStatusAuth;
import com.assettec.api.mobile.uservalidation.UserValidationService;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "validate")
@AllArgsConstructor
public class UserValidationController {
    private UserValidationService userValidationService;

    @PostMapping() @Async
    public CompletableFuture<String> validateAppUser(@RequestBody AppUser appUser) {
        return CompletableFuture.completedFuture(userValidationService.validateAppUser(appUser));
    }

    @GetMapping(path = "status")
    public CompletableFuture<List<UserStatusAuth>> getStatusAuth(@RequestParam(name = "token") String token) {
        return CompletableFuture.completedFuture(userValidationService.getUserWorkOrderStatusAuth(token));
    }


}
