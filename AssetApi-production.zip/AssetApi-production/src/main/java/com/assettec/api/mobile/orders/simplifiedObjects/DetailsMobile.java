package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DetailsMobile {
    private String classId;
    private String problemCode;
    private String criticality;
    private String ppmCode;
    private String maintenancePatternCode;
    private String maintenancePatterDescription;
    private String parentWorkOrder;
    private String cnNumber;
    private String msProject;
    private String schedulingSessionType;
    private String causeCode;
    private String customerCode;
    private String level1;
    private String callerName;
    private String rejectionReason;
    private String reOpened;
    private String customerContractCode;
    private String workPackage;
    private String alertCode;
    private String safetyReviewedBy;
    private String permitReviewedBy;
    private String standardWo;
    private String priorityCode;
    private String costCode;
    private String targetValue;
    private String lastMeterRating;
    private String triggerEvent;
    private String failureCode;
    private String actionCode;
    private String routeCode;
    private String routeStatus;
    private String downTimeCost;
    private String downTimeHours;
    private String originalWorkOrder;
    private String calculatedPriority;
    private String categoryCode;
    private String minor;
    private String preserveCalculatedPriority;
    private String latitude;
    private String longitude;

    public static DetailsMobile createEmpty() {
        return new DetailsMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "");
    }
}
