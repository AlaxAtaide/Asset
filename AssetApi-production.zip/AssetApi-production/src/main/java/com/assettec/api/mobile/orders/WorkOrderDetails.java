package com.assettec.api.mobile.orders;

import com.assettec.api.mobile.orders.simplifiedObjects.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WorkOrderDetails {
    private String code;
    private String organization;
    private String description;
    private String type;
    private String status;

    private String statusCode;
    private String statusDescription;

    private String equipmentCode;
    private String equipmentDescription;
    private String equipmentOrganization;
    private String equipmentType;
    private String multipleEquipments;
    private String equipmentAlias;
    private String equipmentManufacturer;

    private String print;

    private String locationCode;
    private String locationDescription;

    private String positionCode;
    private String positionDescription;

    private String workspace;

    private String oemSite;
    private String supplier;
    private String coverageType;

    private String safety;
    private String warranty;

    private String depend;
    private String printed;
    private String survey;

    private String department;
    private String departmentOrg;

    private String reliabilityRanking;
    private String reliabilityRankingIndex;
    private String reliabilityRankingScore;

    private String createdBy;
    private String createdDate;

    private String eSigner;
    private String eSignDate;
    private String eSignType;

    private LinearReferenceDetailsMobile linearReferenceDetails;
    private ScheduleMobile schedule;
    private ComplianceMobile compliance;
    private ProductionMobile productionDetails;
    private IncidentMobile incidentControl;
    private DetailsMobile details;
    private CustomerServiceDetailsMobile customerServiceDetails;
    private ActivityMobile activity;
    private UserDefinedFieldsMobile userDefinedFields;

    public static WorkOrderDetails createEmpty() {
        return new WorkOrderDetails("", "", "", "", "", "", "", "","","", "", "", "", "",  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",

        LinearReferenceDetailsMobile.createEmpty(),
        ScheduleMobile.createEmpty(),
        ComplianceMobile.createEmpty(),
        ProductionMobile.createEmpty(),
        IncidentMobile.createEmpty(),
        DetailsMobile.createEmpty(),
        CustomerServiceDetailsMobile.createEmpty(),
        ActivityMobile.createEmpty(),
        UserDefinedFieldsMobile.createEmpty()
        );
    }
}
