package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.Details;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.OffSetDirection;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class DetailsSetter {

    private CodeSetter codeSetter;
    private CountSetter countSetter;
    private OffsetDirectionSetter offsetDirectionSetter;

    public Details setDetails(NodeList nodeList) {
        Details details = new Details(new InforEamCode("",""),new InforEamCount("","","",""),new OffSetDirection("","",""),new InforEamCode("",""),new InforEamCode("",""),new InforEamCount("","","",""),new OffSetDirection("","",""),new InforEamCode("",""));

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);

            if (node.getNodeName().equals("FROMREFERENCEID")) details.setFromReferenceId(codeSetter.setCode(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("FROMOFFSET")) details.setFromOffSet(countSetter.setCount(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("FROMOFFSETDIRECTION")) details.setFromOffSetDirection(offsetDirectionSetter.setOffsetDirection(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("FROMREFERENCETYPE")) details.setFromReferenceType(codeSetter.setCode(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("TOREFERENCEID")) details.setToReferenceId(codeSetter.setCode(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("TOOFFSET")) details.setToOffSet(countSetter.setCount(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("TOOFFSETDIRECTION")) details.setToOffSetDirection(offsetDirectionSetter.setOffsetDirection(nodeList.item(i).getChildNodes()));
            if (node.getNodeName().equals("TOREFERENCETYPE")) details.setToReferenceType(codeSetter.setCode(nodeList.item(i).getChildNodes()));

        }

        return details;
    }
}
