package com.assettec.api.internal.utilities.requests.requestbuilders.workOrderBuilder;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class WorkOrderBodyBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String buildBody(ApiUser apiUser, WorkOrder workOrder) {

        String workOrderId = workOrder.getId() == null ? "" : workOrder.getId().buildRequest("<WORKORDERID auto_generated=\"true\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</WORKORDERID>", "<ORGANIZATIONID entity=\"User\">", "</ORGANIZATIONID>", "JOBNUM", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String status = workOrder.getStatus() == null ? "" : workOrder.getStatus().buildRequest("<STATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</STATUS>", "STATUSCODE", "DESCRIPTION");
        String equipmentId = workOrder.getEquipmentId() == null ? "" : workOrder.getEquipmentId().buildRequest("<EQUIPMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</EQUIPMENTID>", "<ORGANIZATIONID entity=\"Organization\">", "</ORGANIZATIONID>", "EQUIPMENTCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String createdBy = workOrder.getCreatedBy() == null ? "" : workOrder.getCreatedBy().buildRequest("<CREATEDBY xmlns=\"http://schemas.datastream.net/MP_fields\">", "</CREATEDBY>", "USERCODE", "DESCRIPTION");
        String enteredBy = workOrder.getEnteredBy() == null ? "" : "<ENTEREDBY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getEnteredBy() + "</ENTEREDBY>";
        String type = workOrder.getType() == null ? "" : workOrder.getType().buildRequest("<TYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</TYPE>", "TYPECODE", "DESCRIPTION");
        String departmentId = workOrder.getDepartmentId() == null ? "" : workOrder.getDepartmentId().buildRequest("<DEPARTMENTID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</DEPARTMENTID>", "<ORGANIZATIONID entity=\"Group\">", "</ORGANIZATIONID>", "DEPARTMENTCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String classId = workOrder.getClassId() == null ? "" : workOrder.getClassId().buildRequest("<CLASSID entity=\"ent1\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</CLASSID>", "<ORGANIZATIONID entity=\"Class\">", "</ORGANIZATIONID>", "CLASSCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String problemId = workOrder.getProblem() == null ? "" : workOrder.getProblem().buildRequest("<PROBLEMCODEID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PROBLEMCODEID>", "PROBLEMCODE", "DESCRIPTION");
        String standardWo = workOrder.getStandardWorkOrder() == null ? "" : workOrder.getStandardWorkOrder().buildRequest("<STANDARDWO xmlns=\"http://schemas.datastream.net/MP_fields\">", "</STANDARDWO>", "<ORGANIZATIONID entity=\"Department\">", "</ORGANIZATIONID>", "STDWOCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String priority = workOrder.getPriority() == null ? "" : workOrder.getPriority().buildRequest("<PRIORITY xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PRIORITY>", "PRIORITYCODE", "DESCRIPTION");
        String locationId = workOrder.getLocationId() == null ? "" : workOrder.getLocationId().buildRequest("<LOCATIONID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</LOCATIONID>", "<ORGANIZATIONID entity=\"Personnel\">", "</ORGANIZATIONID>", "LOCATIONCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");

        String costCodeId = workOrder.getCostCodeId() == null ? "" : workOrder.getCostCodeId().buildRequest("<COSTCODEID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</COSTCODEID>", "<ORGANIZATIONID entity=\"OrganizationValidity\">", "</ORGANIZATIONID>", "COSTCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String projectId = workOrder.getProjectId() == null ? "" : workOrder.getProjectId().buildRequest("<PROJECTID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PROJECTID>", "<ORGANIZATIONID entity=\"Equipment\">", "</ORGANIZATIONID>", "PROJECTCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String projBug = workOrder.getProjectBudget() == null || workOrder.getProjectBudget().isEmpty() ? "" : "<PROJBUD xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProjectBudget() + "</PROJBUD>";
        String targetValue = workOrder.getTargetValue() == null ? "" : workOrder.getTargetValue().buildRequest("<TARGETVALUE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</TARGETVALUE>");
        String criticalityId = workOrder.getCriticality() == null ? "" : workOrder.getCriticality().buildRequest("<CRITICALITYID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</CRITICALITYID>", "CRITICALITY", "DESCRIPTION");
        String ppm = workOrder.getPpm() == null ? "" : workOrder.getPpm().buildRequest("<PPM xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PPM>", "<ORGANIZATIONID entity=\"AssetEquipment\">", "</ORGANIZATIONID>", "PPMCODE", "PPMREVISION", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String serviceRequestId = workOrder.getServiceRequest() == null ? "" : workOrder.getServiceRequest().buildRequest("<SERVICEREQUESTID xmlns=\"http://schemas.datastream.net/MP_fields\">", "</SERVICEREQUESTID>", "<ORGANIZATIONID entity=\"PositionEquipment\">", "</ORGANIZATIONID>", "SERVICEREQUESTCODE", "DESCRIPTION", "ORGANIZATIONCODE", "DESCRIPTION");
        String multipleWorkOrderEquipment = workOrder.getMultipleWorkOrderEquipment() == null ? "" : workOrder.getMultipleWorkOrderEquipment().buildRequest("<MultipleWorkOrderEquipment>" + "<WorkOrderEquipment xmlns=\"http://schemas.datastream.net/MP_entities/WorkOrderEquipment_001\">", "</WorkOrderEquipment>" + "</MultipleWorkOrderEquipment>");
        String userDefinedFields = workOrder.getUserDefinedFields() == null ? "" : workOrder.getUserDefinedFields().buildRequest("<UserDefinedFields>", "</UserDefinedFields>");
        String callCenterDetails = workOrder.getCallCenterDetail() == null ? "" : workOrder.getCallCenterDetail().buildRequest("<CallCenterDetail>", "</CallCenterDetail>");
        String activities = workOrder.getActivities() == null ? "" : workOrder.getActivities().buildRequest();

        String requestedBy = workOrder.getRequestedBy() == null ? "" : workOrder.getRequestedBy().buildRequest("<REQUESTEDBY xmlns=\"http://schemas.datastream.net/MP_fields\">","</REQUESTEDBY>","PERSONCODE","DESCRIPTION");

        String reportedDate = workOrder.getReported() == null ? "" : workOrder.getReported().buildRequest("<REPORTED qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</REPORTED>");

        String assignedTo = workOrder.getAssignedTo() == null ? "" : workOrder.getAssignedTo().buildRequest("<ASSIGNEDTO xmlns=\"http://schemas.datastream.net/MP_fields\">","</ASSIGNEDTO>","PERSONCODE","DESCRIPTION");

        String targetDate = workOrder.getTargetDate() == null ? "" : workOrder.getTargetDate().buildRequest("<TARGETDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</TARGETDATE>");

        String scheduledEnd = workOrder.getScheduledEnd() == null ? "" : workOrder.getScheduledEnd().buildRequest("<SCHEDEND qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</SCHEDEND>");

        String shiftId = workOrder.getShift() == null ? "" : workOrder.getShift().buildRequest("<SHIFTID xmlns=\"http://schemas.datastream.net/MP_fields\">","</SHIFTID>","<ORGANIZATIONID entity=\"PositionEquipmentDefault\">","</ORGANIZATIONID>","SHIFTCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String parentWo = workOrder.getParentWorkOrder() == null ? "" :  workOrder.getParentWorkOrder().buildRequest("<PARENTWO auto_generated=\"true\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</PARENTWO>","<ORGANIZATIONID entity=\"SystemEquipment\">","</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String lastMeterReading = workOrder.getLastMeterReading() == null ? "" : workOrder.getLastMeterReading().buildRequest("<LASTMETERREADING qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</LASTMETERREADING>");

        String triggerEvent = workOrder.getTriggerEvent() == null ? "" : workOrder.getTriggerEvent().buildRequest("<TRIGGEREVENT auto_generated=\"true\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</TRIGGEREVENT>","<ORGANIZATIONID entity=\"SystemEquipmentDefault\">","</ORGANIZATIONID>","JOBNUM","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String requestedStart = workOrder.getRequestedStart() == null ? "" : workOrder.getRequestedStart().buildRequest("<REQUESTEDSTART qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</REQUESTEDSTART>");

        String requestedEnd = workOrder.getRequestedEnd() == null ? "" : workOrder.getRequestedEnd().buildRequest("<REQUESTEDEND qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</REQUESTEDEND>");

        String schedulingSessionType = workOrder.getSchedulingSessionType() == null ? "" : workOrder.getSchedulingSessionType().buildRequest("<SCHEDULINGSESSIONTYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</SCHEDULINGSESSIONTYPE>","TYPECODE","DESCRIPTION");

        String createdDate = workOrder.getCreatedDate() == null ? "" : workOrder.getCreatedDate().buildRequest("<CREATEDDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</CREATEDDATE>");

        String failureCode = workOrder.getFailure() == null ? "" : workOrder.getFailure().buildRequest("<FAILURECODEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</FAILURECODEID>","FAILURECODE","DESCRIPTION");

        String causeCode = workOrder.getCause() == null ? "" : workOrder.getCause().buildRequest("<CAUSECODEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</CAUSECODEID>","CAUSECODE","DESCRIPTION");

        String actionCode = workOrder.getAction() == null ? "" : workOrder.getAction().buildRequest("<ACTIONCODEID xmlns=\"http://schemas.datastream.net/MP_fields\">","</ACTIONCODEID>","ACTIONCODE","DESCRIPTION");

        String startDate = workOrder.getStartDate() == null ? "" : workOrder.getStartDate().buildRequest("<STARTDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</STARTDATE>");

        String completedDate = workOrder.getCompletedDate() == null ? "" : workOrder.getCompletedDate().buildRequest("<COMPLETEDDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</COMPLETEDDATE>");

        String downTimeHours = workOrder.getDownTimeHours() == null ? "" : workOrder.getDownTimeHours().buildRequest("<DOWNTIMEHOURS qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</DOWNTIMEHOURS>");

        String downTimeCost = workOrder.getDownTimeCost() == null ? "" : workOrder.getDownTimeCost().buildRequest("<DOWNTIMECOSTVALUE qualifier=\"ACTUAL\" type=\"T\" index=\"index1\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</DOWNTIMECOSTVALUE>");

        String userDefinedArea = workOrder.getUserDefinedArea() == null ? "" : workOrder.getUserDefinedArea().buildRequest("<USERDEFINEDAREA xmlns=\"http://schemas.datastream.net/MP_fields\">" + "<CUSTOMFIELD index=\"1\" entity=\"entity1\" type=\"type1\" changed=\"chan1\">","</CUSTOMFIELD>" + "</USERDEFINEDAREA>");

        String meterDue = workOrder.getMeterDue() == null ? "" : workOrder.getMeterDue().buildRequest("<METERDUE qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</METERDUE>");

        String meterDue2 = workOrder.getMeterDue2() == null ? "" : workOrder.getMeterDue2().buildRequest("<METERDUE2 qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</METERDUE2>");

        String periodUom = workOrder.getPeriodUom() == null ? "" : workOrder.getPeriodUom().buildRequest("<PERIODUOM xmlns=\"http://schemas.datastream.net/MP_fields\">","</PERIODUOM>","PERIODUOMCODE","DESCRIPTION");

        String meterUom2 = workOrder.getMeterUom2() == null ? "" : workOrder.getMeterUom2().buildRequest("<METERUOM2 xmlns=\"http://schemas.datastream.net/MP_fields\">","</METERUOM2>","UOMCODE","DESCRIPTION");

        String route = workOrder.getRoute() == null ? "" : workOrder.getRoute().buildRequest("<ROUTE xmlns=\"http://schemas.datastream.net/MP_fields\">","</ROUTE>","<ORGANIZATIONID entity=\"WorkRequest\">","</ORGANIZATIONID>","ROUTECODE","ROUTEREVISION","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String routeStatus = workOrder.getRouteStatus() == null ? "" : workOrder.getRouteStatus().buildRequest("<ROUTESTATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">","</ROUTESTATUS>","STATUSCODE","DESCRIPTION");

        String closingComment = workOrder.getClosingComment() == null ? "" : "<CLOSINGCOMMENT recordid=\"1\" is_html_comment=\"is_h1\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITYCOMMENTID>" +
                "<ENTITY>" + workOrder.getClosingComment().getEntityComment().getEntity() + "</ENTITY>" +
                "<COMMENTTYPE entity=\"User\">" +
                "<TYPECODE>" + workOrder.getClosingComment().getEntityComment().getCommentType().getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getEntityComment().getCommentType().getDescription() + "</DESCRIPTION>" +
                "</COMMENTTYPE>" +
                "<ENTITYKEYCODE>" + workOrder.getClosingComment().getEntityComment().getEntityKeyCode() + "</ENTITYKEYCODE>" +
                "<LANGUAGEID>" +
                "<LANGUAGECODE>" + workOrder.getClosingComment().getEntityComment().getLanguage().getCode() + "</LANGUAGECODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getEntityComment().getLanguage().getDescription() + "</DESCRIPTION>" +
                "</LANGUAGEID>" +
                "<LINENUM>" + workOrder.getClosingComment().getEntityComment().getLineNum() + "</LINENUM>" +
                "</ENTITYCOMMENTID>" +
                "<COMMENTTEXT>" + workOrder.getClosingComment().getCommentText() + "</COMMENTTEXT>" +
                "<PRINT>" + workOrder.getClosingComment().getPrint() + "</PRINT>" +
                "<CREATEDDATE qualifier=\"ACCOUNTING\">" +
                "<YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getYear() + "</YEAR>" +
                "<MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getMonth() + "</MONTH>" +
                "<DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getDay() + "</DAY>" +
                "<HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getHour() + "</HOUR>" +
                "<MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getMinute() + "</MINUTE>" +
                "<SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getSecond() + "</SECOND>" +
                "<SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getNano() + "</SUBSECOND>" +
                "<TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getCreatedDate().getTimeZone() + "</TIMEZONE>" +
                "</CREATEDDATE>" +
                "<UPDATEDDATE qualifier=\"ACCOUNTING\">" +
                "<YEAR xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getYear() + "</YEAR>" +
                "<MONTH xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getMonth() + "</MONTH>" +
                "<DAY xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getDay() + "</DAY>" +
                "<HOUR xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getHour() + "</HOUR>" +
                "<MINUTE xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getMinute() + "</MINUTE>" +
                "<SECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getSecond() + "</SECOND>" +
                "<SUBSECOND xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getNano() + "</SUBSECOND>" +
                "<TIMEZONE xmlns=\"http://www.openapplications.org/oagis_fields\">" + workOrder.getClosingComment().getUpdatedDate().getTimeZone() + "</TIMEZONE>" +
                "</UPDATEDDATE>" +
                "<CREATEDBY>" +
                "<USERCODE>" + workOrder.getClosingComment().getCreatedBy().getCode() + "</USERCODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getCreatedBy().getDescription() + "</DESCRIPTION>" +
                "</CREATEDBY>" +
                "<UPDATEDBY>" +
                "<USERCODE>" + workOrder.getClosingComment().getUpdatedBy().getCode() + "</USERCODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getUpdatedBy().getDescription() + "</DESCRIPTION>" +
                "</UPDATEDBY>" +
                "<CATEGORYID>" +
                "<CATEGORYCODE>" + workOrder.getClosingComment().getCategory().getCode() + "</CATEGORYCODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getCategory().getDescription() + "</DESCRIPTION>" +
                "</CATEGORYID>" +
                "<ORGANIZATIONID entity=\"Requisition\">" +
                "<ORGANIZATIONCODE>" + workOrder.getClosingComment().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getClosingComment().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<TRANSLATEDTEXT>" + workOrder.getClosingComment().getTranslatedText() + "</TRANSLATEDTEXT>" +
                "</CLOSINGCOMMENT>";

        String customerId = workOrder.getCustomerId() == null ? "" : "<CUSTOMERID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<CUSTOMERCODE>" + workOrder.getCustomerId().getCode() + "</CUSTOMERCODE>" +
                "<ORGANIZATIONID entity=\"Activity\">" +
                "<ORGANIZATIONCODE>" + workOrder.getCustomerId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getCustomerId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getCustomerId().getDescription() + "</DESCRIPTION>" +
                "</CUSTOMERID>";

        String linearReferenceEvent = workOrder.getLinearReferenceEvent() == null ? "" : workOrder.getLinearReferenceEvent().buildRequest("<LINEARREFERENCEEVENT xmlns=\"http://schemas.datastream.net/MP_fields\">","</LINEARREFERENCEEVENT>");

        String customerContractId = workOrder.getCustomerContractId() == null ? "" : "<CUSTOMERCONTRACTID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<CUSTOMERCONTRACTCODE>" + workOrder.getCustomerContractId().getCode() + "</CUSTOMERCONTRACTCODE>" +
                "<ORGANIZATIONID entity=\"ActivityDefault\">" +
                "<ORGANIZATIONCODE>" + workOrder.getCustomerContractId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getCustomerContractId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getCustomerContractId().getDescription() + "</DESCRIPTION>" +
                "</CUSTOMERCONTRACTID>";

        String alertId = workOrder.getAlert() == null ? "" : "<ALERTID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ALERTCODE>" + workOrder.getAlert().getCode() + "</ALERTCODE>" +
                "<DESCRIPTION>" + workOrder.getAlert().getDescription() + "</DESCRIPTION>" +
                "</ALERTID>";

        String productionDetails = workOrder.getProductionDetails() == null ? "" : "<ProductionDetails>" +
                "<PRODUCTIONREQUESTCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProductionDetails().getRequestCode() + "</PRODUCTIONREQUESTCODE>" +
                "<PRODUCTIONREQUESTREVISION qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                workOrder.getProductionDetails().getRequestRevision().buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</PRODUCTIONREQUESTREVISION>" +
                "<PRODUCTIONORDER xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProductionDetails().getOrder() + "</PRODUCTIONORDER>" +
                "<PRODUCTIONPRIORITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProductionDetails().getPriority() + "</PRODUCTIONPRIORITY>" +
                "<PRODUCTIONPRIORITYDESC xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProductionDetails().getPriorityDescription() + "</PRODUCTIONPRIORITYDESC>" +
                workOrder.getProductionDetails().getStartDate().buildRequest("<PRODUCTIONSTARTDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PRODUCTIONSTARTDATE>") +
                workOrder.getProductionDetails().getEndDate().buildRequest("<PRODUCTIONENDDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</PRODUCTIONENDDATE>") +
                "<ACCOUNTINGENTITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getProductionDetails().getAccountingEntity() + "</ACCOUNTINGENTITY>" +
                "</ProductionDetails>";

        String campaignEventId = workOrder.getCampaignId() == null ? "" : "<CAMPAIGNEVENTID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<CAMPAIGNID>" +
                "<CAMPAIGNCODE>" + workOrder.getCampaignId().getCampaignEventId().getCode() + "</CAMPAIGNCODE>" +
                "<ORGANIZATIONID entity=\"SystemHierarchy\">" +
                "<ORGANIZATIONCODE>" + workOrder.getCampaignId().getCampaignEventId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getCampaignId().getCampaignEventId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getCampaignId().getCampaignEventId().getDescription() + "</DESCRIPTION>" +
                "</CAMPAIGNID>" +
                "<CAMPAIGNEVENT>" + workOrder.getCampaignId().getCampaignEvent() + "</CAMPAIGNEVENT>" +
                "</CAMPAIGNEVENTID>";

        String campaignStatus = workOrder.getCampaignStatus() == null ? "" : "<CAMPAIGNSTATUS entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<STATUSCODE>" + workOrder.getCampaignStatus().getCode() + "</STATUSCODE>" +
                "<DESCRIPTION>" + workOrder.getCampaignStatus().getDescription() + "</DESCRIPTION>" +
                "</CAMPAIGNSTATUS>";

        String maintenancePatternId = workOrder.getMaintenancePatternId() == null ? "" : "<MAINTENANCEPATTERNID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<MAINTENANCEPATTERNCODE>" + workOrder.getMaintenancePatternId().getCode() + "</MAINTENANCEPATTERNCODE>" +
                "<MAINTENANCEPATTERNREVISION>" + workOrder.getMaintenancePatternId().getRevision() + "</MAINTENANCEPATTERNREVISION>" +
                "<ORGANIZATIONID entity=\"AssetHierarchy\">" +
                "<ORGANIZATIONCODE>" + workOrder.getMaintenancePatternId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getMaintenancePatternId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getMaintenancePatternId().getDescription() + "</DESCRIPTION>" +
                "</MAINTENANCEPATTERNID>";

        String eSignatureDetails = workOrder.getESignatureDetail() == null ? "" : "<ESignatureDetail>" +
                "<ESIGNER xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<USERCODE>" + workOrder.getESignatureDetail().getESigner().getCode() + "</USERCODE>" +
                "<DESCRIPTION>" + workOrder.getESignatureDetail().getESigner().getDescription() + "</DESCRIPTION>" +
                "</ESIGNER>" +
                workOrder.getESignatureDetail().getESignatureDate().buildRequest("<ESIGNATUREDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</ESIGNATUREDATE>") +
                "<SIGNATURETYPE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getESignatureDetail().getSignatureType() + "</SIGNATURETYPE>" +
                "<ERECORDCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getESignatureDetail().getERecordCode() + "</ERECORDCODE>" +
                "</ESignatureDetail>";

        String safetyReviewedBy = workOrder.getSafetyReviewedBy() == null ? "" : "<SAFETYREVIEWEDBY xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<USERCODE>" + workOrder.getSafetyReviewedBy().getCode() + "</USERCODE>" +
                "<DESCRIPTION>" + workOrder.getSafetyReviewedBy().getDescription() + "</DESCRIPTION>" +
                "</SAFETYREVIEWEDBY>";

        String permitReviewedBy = workOrder.getPermitReviewedBy() == null ? "" : "<PERMITREVIEWEDBY xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<USERCODE>" + workOrder.getPermitReviewedBy().getCode() + "</USERCODE>" +
                "<DESCRIPTION>" + workOrder.getPermitReviewedBy().getDescription() + "</DESCRIPTION>" +
                "</PERMITREVIEWEDBY>";

        String originalWorkOrderId = workOrder.getOriginalWorkOrderActivityId() == null ? "" : "<ORIGINALWORKORDERACTID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ACTIVITYID>" +
                "<WORKORDERID auto_generated=\"false\">" +
                "<JOBNUM>" + workOrder.getOriginalWorkOrderActivityId().getWorkOrderId().getCode() + "</JOBNUM>" +
                "<ORGANIZATIONID entity=\"AssetEquipmentByProfile\">" +
                "<ORGANIZATIONCODE>" + workOrder.getOriginalWorkOrderActivityId().getWorkOrderId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getOriginalWorkOrderActivityId().getWorkOrderId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getOriginalWorkOrderActivityId().getWorkOrderId().getDescription() + "</DESCRIPTION>" +
                "</WORKORDERID>" +
                "<ACTIVITYCODE auto_generated=\"auto3\">" + workOrder.getOriginalWorkOrderActivityId().getCode() + "</ACTIVITYCODE>" +
                "<ACTIVITYNOTE>" + workOrder.getOriginalWorkOrderActivityId().getNote() + "</ACTIVITYNOTE>" +
                "</ACTIVITYID>" +
                "</ORIGINALWORKORDERACTID>";

        String calculatedPriority = workOrder.getCalculatedPriority() == null ? "" : workOrder.getCalculatedPriority().buildRequest("<CALCULATEDPRIORITY qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</CALCULATEDPRIORITY>");
        String dueDate = workOrder.getDueDate() == null ? "" : workOrder.getDueDate().buildRequest("<DUEDATE qualifier=\"ACCOUNTING\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</DUEDATE>");

        String estimatedLaborCost = workOrder.getEstimatedLaborCost() == null ? "" : workOrder.getEstimatedLaborCost().buildRequest("<ESTIMATEDLABORCOST qualifier=\"APPRVORD\" type=\"F\" index=\"index2\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</ESTIMATEDLABORCOST>");
        String estimatedMaterialCost = workOrder.getEstimatedMaterialCost() == null ? "" : workOrder.getEstimatedMaterialCost().buildRequest("<ESTIMATEDMATERIALCOST qualifier=\"APPRVORD\" type=\"F\" index=\"index2\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</ESTIMATEDMATERIALCOST>");
        String estimatedMiscellaneousCost = workOrder.getEstimatedMiscellaneousCost() == null ? "" : workOrder.getEstimatedMiscellaneousCost().buildRequest("<ESTIMATEDMISCELLANEOUSCOST qualifier=\"APPRVORD\" type=\"F\" index=\"index2\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</ESTIMATEDMISCELLANEOUSCOST>");
        String estimatedTotalCost = workOrder.getEstimatedTotalCost() == null ? "" : workOrder.getEstimatedTotalCost().buildRequest("<ESTIMATEDTOTALCOST qualifier=\"APPRVORD\" type=\"F\" index=\"index2\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</ESTIMATEDTOTALCOST>");

        String workSpaceId = workOrder.getWorkSpaceId() == null ? "" : "<WORKSPACEID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<WORKSPACENUMBER>" + workOrder.getWorkSpaceId().getNumber() + "</WORKSPACENUMBER>" +
                "<WORKSPACECODE>" + workOrder.getWorkSpaceId().getCode() + "</WORKSPACECODE>" +
                "<ORGANIZATIONID entity=\"PartStores\">" +
                "<ORGANIZATIONCODE>" + workOrder.getWorkSpaceId().getOrganization().getCode() + "</ORGANIZATIONCODE>" +
                "<DESCRIPTION>" + workOrder.getWorkSpaceId().getOrganization().getDescription() + "</DESCRIPTION>" +
                "</ORGANIZATIONID>" +
                "<DESCRIPTION>" + workOrder.getWorkSpaceId().getDescription() + "</DESCRIPTION>" +
                "</WORKSPACEID>";

        String positionId = workOrder.getPositionId() == null ? "" : workOrder.getPositionId().buildRequest("<POSITIONID xmlns=\"http://schemas.datastream.net/MP_fields\">","</POSITIONID>","<ORGANIZATIONID entity=\"LaborRequisitionDefault\">","</ORGANIZATIONID>","EQUIPMENTCODE","DESCRIPTION","ORGANIZATIONCODE","DESCRIPTION");

        String coverageType = workOrder.getCoverageType() == null ? "" : "<COVERAGETYPE entity=\"User\" xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<TYPECODE>" + workOrder.getCoverageType().getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + workOrder.getCoverageType().getDescription() + "</DESCRIPTION>" +
                "</COVERAGETYPE>";

        String complianceDetails = workOrder.getComplianceDetail() == null ? "" : "<ComplianceDetail>" +
                "<ABOVECEILINGPERMIT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getAboveCeilingPermit() + "</ABOVECEILINGPERMIT>" +
                "<INTERIMLIFESAFETY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getInterimLifeSafety() + "</INTERIMLIFESAFETY>" +
                "<INTERIMINFECTIONCONTROL xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getInterimInfectionControl() + "</INTERIMINFECTIONCONTROL>" +
                "<PRECONSTRUCTIONRISKASSESSMENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getPreConstructionRiskAssessment() + "</PRECONSTRUCTIONRISKASSESSMENT>" +
                "<PLANIMPROVEMENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getPlanImprovement() + "</PLANIMPROVEMENT>" +
                "<STATEMENTOFCOND xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getStatementOfCondition() + "</STATEMENTOFCOND>" +
                "<BUILDMAINTPROGRAM xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getBuildMainTProgram() + "</BUILDMAINTPROGRAM>" +
                "<PERSONALPROTECTIVEEQUIP xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getPersonalProtectiveEquipment() + "</PERSONALPROTECTIVEEQUIP>" +
                "<LOCKOUT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getLockout() + "</LOCKOUT>" +
                "<BURNPERMIT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getBurnPermit() + "</BURNPERMIT>" +
                "<CONFINEDSPACE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getConfinedSpace() + "</CONFINEDSPACE>" +
                "<PATIENTSAFETY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getPatientSafety() + "</PATIENTSAFETY>" +
                "<RECALLNOTICE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getRecallNotice() + "</RECALLNOTICE>" +
                "<SMDA xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getSMDA() + "</SMDA>" +
                "<HIPAACONFIDENTIALITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getComplianceDetail().getHipaaConfidentiality() + "</HIPAACONFIDENTIALITY>" +
                "</ComplianceDetail>";

        String incidentTracking = workOrder.getIncidentTracking() == null ? "" : "<IncidentTracking>" +
                "<PATIENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getPatient() + "</PATIENT>" +
                "<STAFFINJURY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getStaffInjury() + "</STAFFINJURY>" +
                "<SECURITYINCIDENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getSecurityIncident() + "</SECURITYINCIDENT>" +
                "<PROPERTYDAMAGE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getPropertyDamage() + "</PROPERTYDAMAGE>" +
                "<HAZARDOUSMATERIALSINCIDENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getHazardousMaterialIncident() + "</HAZARDOUSMATERIALSINCIDENT>" +
                "<FIRESAFETYINCIDENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getFireSafetyIncident() + "</FIRESAFETYINCIDENT>" +
                "<MEDICALEQUIPMENTINCIDENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getMedicalEquipmentIncident() + "</MEDICALEQUIPMENTINCIDENT>" +
                "<UTILITYSYSTEMINCIDENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getIncidentTracking().getUtilitySystemIncident() + "</UTILITYSYSTEMINCIDENT>" +
                "</IncidentTracking>";

        String latitude = workOrder.getLatitude() == null ? "" : workOrder.getLatitude().buildRequest("<LATITUDE qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</LATITUDE>");
        String longitude = workOrder.getLongitude() == null ? "" : workOrder.getLongitude().buildRequest("<LONGITUDE qualifier=\"ACCEPTED\" xmlns=\"http://schemas.datastream.net/MP_fields\">", "</LONGITUDE>");
        String workOrderTypeCategory = workOrder.getWorkOrderTypeCategory() == null ? "" : "<WOTYPECATEGORYID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<CATEGORYCODE>" + workOrder.getWorkOrderTypeCategory().getCode() + "</CATEGORYCODE>" +
                "<DESCRIPTION>" + workOrder.getWorkOrderTypeCategory().getDescription() + "</DESCRIPTION>" +
                "</WOTYPECATEGORYID>";

        String failureModeId = workOrder.getFailureMode() == null ? "" : "<FAILUREMODEID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getFailureMode().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getFailureMode().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getFailureMode().getDescription() + "</DESCRIPTION>" +
                "</FAILUREMODEID>";

        String symptomId = workOrder.getSymptom() == null ? "" : "<SYMPTOMID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<SYMPTOMCODE>" + workOrder.getSymptom().getCode() + "</SYMPTOMCODE>" +
                "<DESCRIPTION>" + workOrder.getSymptom().getDescription() + "</DESCRIPTION>" +
                "</SYMPTOMID>";

        String tacticalCauseId = workOrder.getTacticalCause() == null ? "" : "<TACTICALCAUSEID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getTacticalCause().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getTacticalCause().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getTacticalCause().getDescription() + "</DESCRIPTION>" +
                "</TACTICALCAUSEID>";

        String humanFactorId = workOrder.getHumanFactor() == null ? "" : "<HUMANFACTORID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getHumanFactor().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getHumanFactor().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getHumanFactor().getDescription() + "</DESCRIPTION>" +
                "</HUMANFACTORID>";

        String workManShip = workOrder.getWorkmanShip() == null ? "" : "<WORKMANSHIPID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getWorkmanShip().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getWorkmanShip().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getWorkmanShip().getDescription() + "</DESCRIPTION>" +
                "</WORKMANSHIPID>";

        String humanOversight = workOrder.getHumanOversight() == null ? "" : "<HUMANOVERSIGHTID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getHumanOversight().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getHumanOversight().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getHumanOversight().getDescription() + "</DESCRIPTION>" +
                "</HUMANOVERSIGHTID>";

        String methodOfDetection = workOrder.getMethodOfDetection() == null ? "" : "<METHODOFDETECTIONID xmlns=\"http://schemas.datastream.net/MP_fields\">" +
                "<ENTITY>" + workOrder.getMethodOfDetection().getEntity() + "</ENTITY>" +
                "<USERDEFINEDCODE>" + workOrder.getMethodOfDetection().getCode() + "</USERDEFINEDCODE>" +
                "<DESCRIPTION>" + workOrder.getMethodOfDetection().getDescription() + "</DESCRIPTION>" +
                "</METHODOFDETECTIONID>";

        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                xmlRequestHeader.postRequestHeader(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization()) +
                "<Body>" +
                "<MP0025_SyncWorkOrder_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" replace_mec_eq=\"false\" deleteActivities=\"dele1\" autoproductionrequestprompt=\"autoproductionrequestprompt1\" completenonevaluatedsurveyequipprompt=\"completenonevaluatedsurveyequipprompt1\" confirmadddeletechecklist=\"prompt\" confirmincompletechecklist=\"prompt\" confirmworkorderhasfollowupchecklist=\"prompt\" confirmrouteequipmentchecklist=\"prompt\" confirmequipmentchecklist=\"prompt\" iscontractorportal=\"false\" verb=\"Sync\" noun=\"WorkOrder\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0025_001\">" +
                "<WorkOrder recordid=\"" + workOrder.getUpdatedCount() + "\" is_completed=\"true\" is_cancelled=\"true\" has_department_security=\"has_1\" is_batchwo=\"true\" is_parentpmwo=\"true\" is_batchwo_update=\"true\" is_room_occupied=\"false\" xmlns=\"http://schemas.datastream.net/MP_entities/WorkOrder_001\">" +
                workOrderId +
                status +
                equipmentId +
                createdBy +
                enteredBy +
                type +
                departmentId +
                classId +
                problemId +
                standardWo +
                priority +
                locationId +
                costCodeId +
                projectId +
                projBug +
                targetValue +
                criticalityId +
                ppm +
                serviceRequestId +
                "<SAFETY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSafety() + "</SAFETY>" +
                "<WARRANTY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getWarranty() + "</WARRANTY>" +
                "<EQUIPMENTALIAS xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getEquipmentAlias() + "</EQUIPMENTALIAS>" +
                "<SERIALNUMBER xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSerialNumber() + "</SERIALNUMBER>" +
                "<MODEL xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getModel() + "</MODEL>" +
                requestedBy +
                reportedDate +
                "<SCHEDGROUP xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getScheduledGroup() + "</SCHEDGROUP>" +
                "<SUPERVISORDESCRIPTION xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSupervisorDescription() + "</SUPERVISORDESCRIPTION>" +
                assignedTo +
                targetDate +
                scheduledEnd +
                shiftId +
                parentWo +
                "<CNNUMBER xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getCnNumber() + "</CNNUMBER>" +
                "<CHANGENOTICEDESCRIPTION xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getChangeNoticeDescription() + "</CHANGENOTICEDESCRIPTION>" +
                "<METERUNIT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getMeterUnit() + "</METERUNIT>" +
                lastMeterReading +
                triggerEvent +
                requestedStart +
                requestedEnd +
                "<MSPROJECT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getMsProject() + "</MSPROJECT>" +
                schedulingSessionType +
                "<FIXED xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getFixed() + "</FIXED>" +
                "<DEPEND xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getDepend() + "</DEPEND>" +
                createdDate +
                "<OBJTYPE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getObjectType() + "</OBJTYPE>" +
                failureCode +
                causeCode +
                actionCode +
                startDate +
                completedDate +
                downTimeHours +
                downTimeCost +
                "<REOPENED xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getReOpened() + "</REOPENED>" +
                userDefinedArea +
                "<FREQUENCY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getFrequency() + "</FREQUENCY>" +
                "<EVTISSTYPE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getEvtissType() + "</EVTISSTYPE>" +
                meterDue +
                meterDue2 +
                "<WORKPACKAGE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getWorkPackage() + "</WORKPACKAGE>" +
                periodUom +
                meterUom2 +
                route +
                routeStatus +
                "<ROUTEPARENT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getRouteParent() + "</ROUTEPARENT>" +
                "<BILLABLE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getBillable() + "</BILLABLE>" +
                "<PRINTED xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getPrinted() + "</PRINTED>" +
                "<PRINT xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getPrint() + "</PRINT>" +
                "<SOURCESYSTEM xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSourceSystem() + "</SOURCESYSTEM>" +
                "<SOURCECODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSourceCode() + "</SOURCECODE>" +
                "<ROUTEDFROM xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getRoutedFrom() + "</ROUTEDFROM>" +
                "<ACDCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getAcdCode() + "</ACDCODE>" +
                closingComment +
                activities +
                "<CALLERNAME xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getCallerName() + "</CALLERNAME>" +
                customerId +
                "<LEVEL1 xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getLevel1() + "</LEVEL1>" +
                "<REJECTIONREASON xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getRejectionReason() + "</REJECTIONREASON>" +
                linearReferenceEvent +
                "<INSPECTIONDIRECTIONCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getInspectionDirectionCode() + "</INSPECTIONDIRECTIONCODE>" +
                "<FLOWCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getFlowCode() + "</FLOWCODE>" +
                "<MULTIEQUIP xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getMultiEquip() + "</MULTIEQUIP>" +
                customerContractId +
                dueDate +
                "<CCTRSPCVALIDATION xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getCctrspcValidation() + "</CCTRSPCVALIDATION>" +
                callCenterDetails +
                userDefinedFields +
                alertId +
                productionDetails +
                campaignEventId +
                "<SURVEY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSurvey() + "</SURVEY>" +
                campaignStatus +
                maintenancePatternId +
                "<SEQUENCE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getSequence() + "</SEQUENCE>" +
                eSignatureDetails +
                safetyReviewedBy +
                permitReviewedBy +
                originalWorkOrderId +
                "<JOBSEQUENCE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getJobSequence() + "</JOBSEQUENCE>" +
                "<ACTIVITYNOTE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getActivityNote() + "</ACTIVITYNOTE>" +
                calculatedPriority +
                "<PRESERVECALCPRIORITY xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getPreserveCalculatedPriority() + "</PRESERVECALCPRIORITY>" +
                "<CURRENCYCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getCurrencyCode() + "</CURRENCYCODE>" +
                estimatedLaborCost +
                estimatedMaterialCost +
                estimatedMiscellaneousCost +
                estimatedTotalCost +
                workSpaceId +
                positionId +
                "<MANUFACTURERCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getManufacturerCode() + "</MANUFACTURERCODE>" +
                "<OEMSITE xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getOemSite() + "</OEMSITE>" +
                "<VENDOR xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getVendor() + "</VENDOR>" +
                coverageType +
                complianceDetails +
                incidentTracking +
                latitude +
                longitude +
                multipleWorkOrderEquipment +
                workOrderTypeCategory +
                "<MINOR xmlns=\"http://schemas.datastream.net/MP_fields\">" + workOrder.getMinor() + "</MINOR>" +
                failureModeId +
                symptomId +
                tacticalCauseId +
                humanFactorId +
                workManShip +
                humanOversight +
                methodOfDetection +
                "</WorkOrder>" +
                "</MP0025_SyncWorkOrder_001>" +
                "</Body>" +
                "</Envelope>";
    }
}
