package com.assettec.api.internal.core.issueReturnLines;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class IssueReturnLine {
    private String transactionLine;
    private String partCode;
    private String partOrganization;
    private String transactionQuantity;
    private String bin;
}