package com.assettec.api.integration.IG.transactions.store2store;

import com.assettec.api.internal.core.items.part.PartService;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.transactions.Store2StorePart;
import com.assettec.api.internal.core.transactions.Store2StoreService;
import com.assettec.api.internal.core.transactions.StoreToStore;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class IGStore2Store2SendSetter {

    private Store2StoreService store2StoreService;
    private PartService partService;

    public IGStore2Store2Send setStore2Store2Send(ApiUser apiUser, String transactionCode, StoreToStore storeTransaction, String status) {
        IGStore2Store2Send store2Send = new IGStore2Store2Send();

        store2Send.setClassId(storeTransaction.getClassId().getCode());
        store2Send.setStore2storeCode(storeTransaction.getTransactionId().getCode());
        store2Send.setToStore(storeTransaction.getToStoreId().getCode());
        store2Send.setFromStore(storeTransaction.getFromStoreId().getCode());
        store2Send.setToStoreOrganization(storeTransaction.getToStoreId().getOrganization().getCode());
        store2Send.setFromStoreOrganization(storeTransaction.getFromStoreId().getOrganization().getCode());
        store2Send.setPartQuantity(Integer.parseInt(storeTransaction.getPartLineCount()));

        store2Send.setStatus(status.equals("NF") ? "Aguardando Nota Fiscal" : status.equals("TR") ? "Notal Fiscal Emitida" : status);

        List<IGStore2Store2SendPart> store2SendParts = new ArrayList<>();
        for (int j = 0; j < storeTransaction.getStore2StoreParts().size(); j++) {
            Store2StorePart storePart = storeTransaction.getStore2StoreParts().get(j);
            IGStore2Store2SendPart store2Store2SendPart = new IGStore2Store2SendPart();

            store2Store2SendPart.setPartCode(storePart.getPart().getCode());
            // todo: procurar no lugar certo
            String codeIgerp = partService.getPart(apiUser,storePart.getPart().getCode(),storePart.getPart().getOrganization()).getUserDefinedFields().getUdfChar04() == null ? "" : partService.getPart(apiUser,storePart.getPart().getCode(),storePart.getPart().getOrganization()).getUserDefinedFields().getUdfChar04();
            store2Store2SendPart.setCodeIGERP(codeIgerp);
            store2Store2SendPart.setNewBin(storePart.getToBin());
            store2Store2SendPart.setOldBin(store2StoreService.getStoreIssuePart(apiUser, transactionCode, storePart.getLineNum()).getOldBin());
            store2Store2SendPart.setReceivedQuantity(Double.parseDouble(String.valueOf(Long.parseLong(storePart.getReceiptQuantityValue())/Math.pow(10,Long.parseLong(storePart.getReceiptQuantityDecimals())))));
            store2SendParts.add(store2Store2SendPart);
        }
        store2Send.setStore2StoreParts(store2SendParts);
        return store2Send;
    }
}
