package com.assettec.api.internal.core.entities.linearReferenceEvent.setter;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.objects.HorizontalVerticalDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class HorizontalVerticalDetailsSetter {

    private CodeSetter codeSetter;
    private CountSetter countSetter;

    public HorizontalVerticalDetails setHorizontalVerticalDetails(NodeList nodeList) {
        HorizontalVerticalDetails horizontalVerticalDetails = new HorizontalVerticalDetails(new InforEamCode("",""),new InforEamCount("","","",""),new InforEamCode("",""),new InforEamCode("",""),new InforEamCount("","","",""),new InforEamCode("",""),new InforEamCode("",""));

        horizontalVerticalDetails.setRelationShipTypeId(codeSetter.setCode(nodeList.item(0).getChildNodes()));
        horizontalVerticalDetails.setHorizontalOffSet(countSetter.setCount(nodeList.item(1).getChildNodes()));
        horizontalVerticalDetails.setHorizontalOffSetUom(codeSetter.setCode(nodeList.item(2).getChildNodes()));
        horizontalVerticalDetails.setHorizontalOffSetTypeId(codeSetter.setCode(nodeList.item(3).getChildNodes()));
        horizontalVerticalDetails.setVerticalOffSet(countSetter.setCount(nodeList.item(4).getChildNodes()));
        horizontalVerticalDetails.setVerticalOffSetUom(codeSetter.setCode(nodeList.item(5).getChildNodes()));
        horizontalVerticalDetails.setVerticalOffSetTypeId(codeSetter.setCode(nodeList.item(6).getChildNodes()));

        return horizontalVerticalDetails;
    }
}
