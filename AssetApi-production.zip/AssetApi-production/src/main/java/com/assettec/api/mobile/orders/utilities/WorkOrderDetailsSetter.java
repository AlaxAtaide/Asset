package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class WorkOrderDetailsSetter {

    private ScheduleSetter scheduleSetter;
    private BasicDataSetter basicDataSetter;
    private ProductionSetter productionSetter;
    private DetailsMobileSetter detailsSetter;
    private ComplianceSetter complianceSetter;
    private ActivityMobileSetter activityMobileSetter;
    private CustomerServiceSetter customerServiceSetter;
    private IncidentControlSetter incidentControlSetter;
    private UserDefinedFieldsMobileSetter userDefinedFieldsSetter;
    private LinearReferenceDetailsMobileSetter linearReferenceDetailsMobileSetter;

    public WorkOrderDetails getWorkOrderDetails(WorkOrder workOrder) {
        WorkOrderDetails workOrderDetails = new WorkOrderDetails();

        basicDataSetter.setBasicData(workOrderDetails, workOrder);
        linearReferenceDetailsMobileSetter.setLinearReference(workOrderDetails, workOrder);
        scheduleSetter.setSchedule(workOrderDetails,workOrder);
        complianceSetter.setCompliance(workOrderDetails,workOrder);
        productionSetter.setProductionDetails(workOrderDetails,workOrder);
        incidentControlSetter.setIncidentControl(workOrderDetails,workOrder);
        detailsSetter.setDetails(workOrderDetails,workOrder);
        customerServiceSetter.setCustomerService(workOrderDetails,workOrder);
        activityMobileSetter.setActivity(workOrderDetails,workOrder);
        userDefinedFieldsSetter.setUserDefinedFields(workOrderDetails,workOrder);

        return workOrderDetails;
    }
}
