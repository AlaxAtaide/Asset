package com.assettec.api.internal.core.orders.workorder.utilities;

import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.orders.workorder.WorkOrderEquipment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

@Component
@AllArgsConstructor
public class WorkOrderEquipmentSetter {
    private AdditionalDetailsSetter additionalDetailsSetter;
    private IdSetter idSetter;

    public WorkOrderEquipment setEquipments(NodeList childNodes) {

        Node workOrderEquipmentNode = childNodes.item(0);
        return setEquipment(workOrderEquipmentNode.getChildNodes());
    }

    private WorkOrderEquipment setEquipment(NodeList childNodes) {
        WorkOrderEquipment workOrderEquipment = new WorkOrderEquipment();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("WORKORDERID")) workOrderEquipment.setWorkOrderId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("EQUIPMENTID")) workOrderEquipment.setEquipmentId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("AdditionalDetails")) workOrderEquipment.setAdditionalDetails(additionalDetailsSetter.setAdditionalDetails(childNode.getChildNodes()));
        }

        return workOrderEquipment;
    }
}
