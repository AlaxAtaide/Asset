package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Details {
    private InforEamCode fromReferenceId;
    private InforEamCount fromOffSet;
    private OffSetDirection fromOffSetDirection;
    private InforEamCode fromReferenceType;

    private InforEamCode toReferenceId;
    private InforEamCount toOffSet;
    private OffSetDirection toOffSetDirection;
    private InforEamCode toReferenceType;

    public String buildRequest() {
        return "<RELATEDLINEARREFERENCEDETAILS>" +
                "<FROMREFERENCEID>" +
                "<LINEARREFERENCECODE>" + fromReferenceId.getCode() + "</LINEARREFERENCECODE>" +
                "<DESCRIPTION>" + fromReferenceId.getDescription() + "</DESCRIPTION>" +
                "</FROMREFERENCEID>" +
                "<FROMOFFSET qualifier=\"AVAILABLE\">" +
                fromOffSet.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</FROMOFFSET>" +
                "<FROMOFFSETDIRECTION>" +
                fromOffSetDirection.buildRequest() +
                "</FROMOFFSETDIRECTION>" +
                "<FROMREFERENCETYPE entity=\"Group\">" +
                "<TYPECODE>" + fromReferenceType.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + fromReferenceType.getDescription() + "</DESCRIPTION>" +
                "</FROMREFERENCETYPE>" +
                "<TOREFERENCEID>" +
                "<LINEARREFERENCECODE>" + toReferenceId.getCode() + "</LINEARREFERENCECODE>" +
                "<DESCRIPTION>" + toReferenceId.getDescription() + "</DESCRIPTION>" +
                "</TOREFERENCEID>" +
                "<TOOFFSET qualifier=\"AVAILABLE\">" +
                toOffSet.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") +
                "</TOOFFSET>" +
                "<TOOFFSETDIRECTION>" +
                toOffSetDirection.buildRequest() +
                "</TOOFFSETDIRECTION>" +
                "<TOREFERENCETYPE entity=\"Group\">" +
                "<TYPECODE>" + toReferenceType.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + toReferenceType.getDescription() + "</DESCRIPTION>" +
                "</TOREFERENCETYPE>" +
                "</RELATEDLINEARREFERENCEDETAILS>";
    }
}
