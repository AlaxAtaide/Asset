package com.assettec.api.integration.IG.transactions.system;

import com.assettec.api.integration.IG.transactions.equipment.IGAssetEquipmentRequest;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGAssetSystemSendList {
    private String http;
    private String message;
    private List<IGAssetSystemRequest> assetSystemList;
}
