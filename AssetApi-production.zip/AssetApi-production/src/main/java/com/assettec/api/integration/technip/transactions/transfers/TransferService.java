package com.assettec.api.integration.technip.transactions.transfers;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.internal.core.issueReturnLines.IssueReturnLine;
import com.assettec.api.internal.core.issueReturnLines.IssueReturnRequest;
import com.assettec.api.internal.utilities.common.JsonParser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class TransferService {

    private ApiUserService apiUserService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;

    @SneakyThrows
    public void transferFromFTP(FTPClient ftpClient, String fileName) {
        FTPFile[] ftpFiles = ftpClient.listFiles();
        for (FTPFile ftpFile : ftpFiles) {

            if (Objects.equals(ftpFile.getName(), fileName)) {

                JSONObject jsonObject = JsonParser.getJsonFromFTPFile(ftpClient, ftpFile);
                JSONArray transactionsList = jsonObject.getJSONArray("transactionsList");

                for (int i = 0; i < transactionsList.length(); i++) {
                    IssueReturnRequest issueReturnRequest = new IssueReturnRequest();
                    JSONObject transaction = transactionsList.getJSONObject(i);
                    JSONArray partLines = transaction.getJSONArray("issueReturnLines");

                    issueReturnRequest.setTransactionOrganization(transaction.getString("transactionOrganization"));
                    issueReturnRequest.setServiceOrderCode(transaction.getString("serviceOrderCode"));
                    issueReturnRequest.setActivityCode(transaction.getString("activityCode"));
                    issueReturnRequest.setStoreCode(transaction.getString("storeCode"));
                    issueReturnRequest.setStoreOrganization(transaction.getString("storeOrganization"));
                    issueReturnRequest.setDepartmentCode(transaction.getString("departmentCode"));

                    List<IssueReturnLine> issueReturnLineList = new ArrayList<>();
                    for (int j = 0; j < partLines.length(); j++) {
                        IssueReturnLine issueReturnLine = new IssueReturnLine();
                        JSONObject parts = partLines.getJSONObject(j);

                        issueReturnLine.setTransactionLine(String.valueOf(j * 10));
                        issueReturnLine.setPartCode(parts.getString("partCode"));
                        issueReturnLine.setPartOrganization(parts.getString("partOrganization"));
                        issueReturnLine.setTransactionQuantity(parts.getString("transactionQuantity"));
                        issueReturnLine.setBin(parts.getString("bin"));

                        issueReturnLineList.add(issueReturnLine);
                    }
                    issueReturnRequest.setIssueReturnLines(issueReturnLineList);

                    ApiUser apiUser = apiUserService.findByUserName("AGUIMARAES");
                    issueTransaction(apiUser, issueReturnRequest);
                    ftpClient.rename(fileName, fileName.replace(".json", "-sent.json"));
                }
            }
        }
    }

    @SneakyThrows
    public String issueTransaction(ApiUser apiUser, IssueReturnRequest issueReturnRequest) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getTransactionsRequestBuilder().addIssueReturnTransaction(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), issueReturnRequest.getTransactionOrganization(), "ISSUE", issueReturnRequest.getServiceOrderCode(), issueReturnRequest.getActivityCode(), issueReturnRequest.getStoreCode(), issueReturnRequest.getStoreOrganization(), issueReturnRequest.getDepartmentCode(), issueReturnRequest.getIssueTo(), issueReturnRequest.getIssueReturnLines());
        return requestSender.sendPostRequest(postRequest, host);
    }

    @SneakyThrows
    public String returnTransaction(ApiUser apiUser, IssueReturnRequest issueReturnRequest) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getTransactionsRequestBuilder().addIssueReturnTransaction(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), issueReturnRequest.getTransactionOrganization(), "RETURN", issueReturnRequest.getServiceOrderCode(), issueReturnRequest.getActivityCode(), issueReturnRequest.getStoreCode(), issueReturnRequest.getStoreOrganization(), issueReturnRequest.getDepartmentCode(), issueReturnRequest.getIssueTo(), issueReturnRequest.getIssueReturnLines());
        return requestSender.sendPostRequest(postRequest, host);
    }
}
