package com.assettec.api.mobile.uservalidation;

import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.internal.users.AppUser;
import com.assettec.api.internal.users.status.UserStatusAuth;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.mobile.services.WorkOrderMobileService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class UserValidationService {

    private WorkOrderMobileService workOrderMobileService;
    private ApiUserService apiUserService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;

    @SneakyThrows
    public String validateAppUser(AppUser appUser) {
        if (appUser.getUsername() == null || appUser.getUsername().isEmpty()) throw new IllegalAccessException("User name must not be blank.");
        if (appUser.getPassword() == null || appUser.getPassword().isEmpty()) throw new IllegalAccessException("Password must not be blank.");
        if (appUser.getTenant() == null || appUser.getTenant().isEmpty()) throw new IllegalAccessException("Tenant must not be blank.");
        if (appUser.getOrganization() == null || appUser.getOrganization().isEmpty()) throw new IllegalAccessException("Organization must not be blank.");

        ApiUser apiUser = new ApiUser();
        apiUser.setUsername(appUser.getUsername());
        apiUser.setOrganization(appUser.getOrganization());
        apiUser.setTenant(appUser.getTenant());
        apiUser.setPassword(appUser.getPassword());
        apiUser.setToken(UUID.randomUUID().toString());
        apiUser.setEnabled(false);
        apiUser.setTimeCreated(LocalDateTime.now());

        workOrderMobileService.getDataSpies(apiUser);
        if (apiUserService.findByUserName(appUser.getUsername()).getUsername().equals(appUser.getUsername())) return "User validated." + apiUserService.findByUserName(appUser.getUsername()).getToken();

        apiUserService.saveApiUser(apiUser);
        return "User validated." + apiUser.getToken();
    }

    @SneakyThrows
    public List<UserStatusAuth> getUserWorkOrderStatusAuth(String token) {
        ApiUser apiUser = apiUserService.findByToken(token);

        String postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser,"BSAUTH_HDR","BSAUTH_HDR","entity","EVNT","=");
        String response = requestSender.sendPostRequest(postRequest,XMLParser.getInforHost());

        List<Row> rows = gridService.getRows(response);
        List<UserStatusAuth> workOrderUserAuth = new ArrayList<>();

        for (Row row : rows) {
            UserStatusAuth userStatusAuth = new UserStatusAuth();

            userStatusAuth.setUserGroupCode(row.getDataByName("usergroupcode"));
            userStatusAuth.setUserGroupDescription(row.getDataByName("usergroupdesc"));
            userStatusAuth.setUserSpecificAuthorization(row.getDataByName("userspecauth"));
            userStatusAuth.setEntityDescription(row.getDataByName("entitydesc"));
            userStatusAuth.setSystemEntity(row.getDataByName("rentity"));
            userStatusAuth.setEntityCode(row.getDataByName("entity"));
            userStatusAuth.setUserCode(row.getDataByName("usercode"));
            userStatusAuth.setFromStatus(row.getDataByName("fromstatus"));
            userStatusAuth.setFromStatusDescription(row.getDataByName("fromstatusdesc"));
            userStatusAuth.setToStatus(row.getDataByName("tostatus"));
            userStatusAuth.setToStatusDescription(row.getDataByName("tostatusdesc"));

            workOrderUserAuth.add(userStatusAuth);
        }

        return workOrderUserAuth;
    }
}
