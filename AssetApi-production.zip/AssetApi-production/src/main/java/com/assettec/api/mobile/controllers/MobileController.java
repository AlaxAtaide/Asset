package com.assettec.api.mobile.controllers;

import com.assettec.api.internal.core.grid.DataSpy;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import com.assettec.api.mobile.objects.assets.MobileAssetList;
import com.assettec.api.mobile.objects.departments.DepartmentList;
import com.assettec.api.mobile.objects.organizations.OrganizationList;
import com.assettec.api.mobile.objects.types.TypeList;
import com.assettec.api.mobile.services.MobileAssetService;
import com.assettec.api.mobile.objects.config.FieldsToShow;
import com.assettec.api.mobile.objects.config.FieldsToShowService;
import com.assettec.api.mobile.objects.grid.GridData;
import com.assettec.api.mobile.services.WorkOrderMobileService;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "mobile")
@AllArgsConstructor
public class MobileController {

    private ApiUserService apiUserService;
    private WorkOrderMobileService workOrderService;
    private FieldsToShowService fieldsToShowService;
    private MobileAssetService mobileAssetService;

    @GetMapping(path = "workOrderGrid") @Async
    public CompletableFuture<GridData> getWorkOrdersFromGrid(@RequestParam(name = "token") String token, @RequestParam(name = "dataspy") String dataSpy) {
        ApiUser apiUser = apiUserService.findByToken(token);
        if (dataSpy == null) dataSpy = "";
        return CompletableFuture.completedFuture(workOrderService.getGridWorkOrderData(apiUser, dataSpy));
    }

    @GetMapping(path = "workOrderDetails") @Async
    public CompletableFuture<WorkOrderDetails> getWorkOrdersDetails(@RequestParam(name = "token") String token, @RequestParam(name = "workOrderCode") String workOrderCode, @RequestParam(name = "organization") String organization) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getGridWorkOrderDetails(apiUser, workOrderCode, organization));
    }

    @GetMapping(path = "userDefinedFieldsLabels") @Async
    public CompletableFuture<WorkOrderDetails> getLabels(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getLabels(apiUser));
    }

    @GetMapping(path = "dataSpies") @Async
    public CompletableFuture<List<DataSpy>> getDataSpies(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getDataSpies(apiUser));
    }

    //todo: o usuário do mobile poderá atualizar apenas o status e as horas trabalhadas

    @GetMapping(path = "test") @Async
    public CompletableFuture<List<WorkOrderDetails>> test(@RequestParam(name = "token") String token) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.testEnvironment(apiUser));
    }

    @GetMapping(path = "fields2show") @Async
    public CompletableFuture<FieldsToShow> getShownFields() {
        return CompletableFuture.completedFuture(fieldsToShowService.getShownFields());
    }

    @PostMapping(path = "fields2show") @Async @SneakyThrows
    public CompletableFuture<String> saveShownFields(@RequestParam(name = "token") String token, @RequestBody FieldsToShow fields) {
        if (!Objects.equals(token, "aa937bc76_uo8703bn31_act038741yj")) throw new IllegalAccessException("Not allowed access");
        return CompletableFuture.completedFuture(fieldsToShowService.saveFields(fields));
    }

    @GetMapping(path = "equipments") @Async
    public CompletableFuture<MobileAssetList> getWorkOrderEquipments(@RequestParam(name = "token") String token, @RequestParam(name = "position") int position) {
    ApiUser apiUser = apiUserService.findByToken(token);
    return CompletableFuture.completedFuture(mobileAssetService.getAssets(apiUser, position));
    }

    @GetMapping(path = "positions") @Async
    public CompletableFuture<MobileAssetList> getWorkOrderPositions(@RequestParam(name = "token") String token, @RequestParam(name = "position") int position) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(mobileAssetService.getPositions(apiUser, position));
    }

    @GetMapping(path = "systems") @Async
    public CompletableFuture<MobileAssetList> getWorkOrderSystems(@RequestParam(name = "token") String token, @RequestParam(name = "position") int position) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(mobileAssetService.getSystems(apiUser, position));
    }

    @GetMapping(path = "organizations") @Async
    public CompletableFuture<OrganizationList> getWorkOrderOrganizations(@RequestParam(name = "token") String token, @RequestParam(name = "position") int position) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getOrganizations(apiUser, position));
    }

    @GetMapping(path = "departments") @Async
    public CompletableFuture<DepartmentList> getWorkOrderDepartments(@RequestParam(name = "token") String token, @RequestParam(name = "position") int position) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getDepartments(apiUser, position));
    }

    @GetMapping(path = "types") @Async
    public CompletableFuture<TypeList> getWorkOrderTypes(@RequestParam(name = "token") String token, @RequestParam(name = "userGroup") String userGroup ) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return CompletableFuture.completedFuture(workOrderService.getTypes(apiUser, userGroup));
    }
}
