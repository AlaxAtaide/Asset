package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.objects.Id.Id;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.ParentHierarchy;
import com.assettec.api.internal.core.items.asset.common.objects.DependentAsset;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class ParentHierarchySetter {

    private IdSetter idSetter;
    private CodeSetter codeSetter;
    private DependentAssetSetter dependentAssetSetter;

    public ParentHierarchy setParentHierarchy(NodeList childNodes) {
        ParentHierarchy assetParentHierarchy = new ParentHierarchy(new Id("",new InforEamCode("",""),""),new InforEamCode("",""),new Id("",new InforEamCode("",""),""),"",new DependentAsset(new Id("",new InforEamCode("",""),""),new InforEamCode("",""),"",new Id("",new InforEamCode("",""),""),new Id("",new InforEamCode("",""),""),""),new DependentAsset(new Id("",new InforEamCode("",""),""),new InforEamCode("",""),"",new Id("",new InforEamCode("",""),""),new Id("",new InforEamCode("",""),""),""),new DependentAsset(new Id("",new InforEamCode("",""),""),new InforEamCode("",""),"",new Id("",new InforEamCode("",""),""),new Id("",new InforEamCode("",""),""),""),new DependentAsset(new Id("",new InforEamCode("",""),""),new InforEamCode("",""),"",new Id("",new InforEamCode("",""),""),new Id("",new InforEamCode("",""),""),""));

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("ASSETID")) assetParentHierarchy.setId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("TYPE")) assetParentHierarchy.setType(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LOCATIONID")) assetParentHierarchy.setLocation(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("POSITIONPARENT")) assetParentHierarchy.setPositionParent(childNode.getTextContent());
            if (childNode.getNodeName().equals("AssetDependency")) {
                for (int j = 0; j < childNode.getChildNodes().getLength(); j++) {
                    Node childNode2 = childNode.getChildNodes().item(j);

                    if (childNode.getNodeName().equals("DEPENDENTASSET")) assetParentHierarchy.setDependentAsset(dependentAssetSetter.setDependentAsset(childNode2.getChildNodes()));
                    if (childNode.getNodeName().equals("NONDEPENDENTPOSITION")) assetParentHierarchy.setNonDependentPosition(dependentAssetSetter.setDependentAsset(childNode2.getChildNodes()));
                    if (childNode.getNodeName().equals("NONDEPENDENTPRIMARYSYSTEM")) assetParentHierarchy.setNonDependentPrimarySystem(dependentAssetSetter.setDependentAsset(childNode2.getChildNodes()));
                    if (childNode.getNodeName().equals("NONDEPENDENTSYSTEM")) assetParentHierarchy.setNonDependentSystem(dependentAssetSetter.setDependentAsset(childNode2.getChildNodes()));

                }
            }
        }

        return assetParentHierarchy;
    }
}
