package com.assettec.api.internal.core.receipt.utilities;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.entities.classId.ClassId;
import com.assettec.api.internal.core.entities.store.Store;
import com.assettec.api.internal.core.entities.supplier.Supplier;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrder;
import com.assettec.api.internal.core.orders.purchaseorder.PurchaseOrderService;
import com.assettec.api.internal.core.receipt.POReceipt;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;
import java.util.Objects;

@Component
@AllArgsConstructor
public class POReceiptSetter {

    private PurchaseOrderService purchaseOrderService;

    @SneakyThrows
    public void setBasicData(Document xmlData, POReceipt poReceipt) {
        poReceipt.setUpdateCount(Integer.parseInt(xmlData.getElementsByTagName("POReceipt").item(0).getAttributes().getNamedItem("recordid").getNodeValue()));

        String code = xmlData.getElementsByTagName("PORECEIPTCODE").getLength() != 0 ? xmlData.getElementsByTagName("PORECEIPTCODE").item(0).getTextContent() : "";
        String organization = xmlData.getElementsByTagName("PORECEIPTID").getLength() != 0 ? xmlData.getElementsByTagName("PORECEIPTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        String description = xmlData.getElementsByTagName("PORECEIPTID").getLength() != 0 ? xmlData.getElementsByTagName("PORECEIPTID").item(0).getLastChild().getFirstChild().getTextContent() : "";

        poReceipt.setCode(code);
        poReceipt.setOrganization(organization);
        poReceipt.setDescription(description);

        String status = xmlData.getElementsByTagName("STATUS").getLength() != 0 ? xmlData.getElementsByTagName("STATUS").item(0).getFirstChild().getTextContent() : "";
        poReceipt.setStatus(status);

        String dockLocation = xmlData.getElementsByTagName("DOCKLOCATION").getLength() != 0 ? xmlData.getElementsByTagName("DOCKLOCATION").item(0).getTextContent() : "";
        poReceipt.setDockLocation(dockLocation);

        String freight = xmlData.getElementsByTagName("FREIGHT").getLength() != 0 ? xmlData.getElementsByTagName("FREIGHT").item(0).getTextContent() : "";
        poReceipt.setFreight(freight);

        String reference = xmlData.getElementsByTagName("REFERENCE").getLength() != 0 ? xmlData.getElementsByTagName("REFERENCE").item(0).getTextContent() : "";
        poReceipt.setReference(reference);

        String numberOfReceiptLines = xmlData.getElementsByTagName("NUMBEROFRECEIPTLINES").getLength() != 0 ? xmlData.getElementsByTagName("NUMBEROFRECEIPTLINES").item(0).getTextContent() : "";
        poReceipt.setNumberOfReceiptLines(Integer.parseInt(numberOfReceiptLines));

        String packSlip = xmlData.getElementsByTagName("PACKSLIP").getLength() != 0 ? xmlData.getElementsByTagName("PACKSLIP").item(0).getTextContent() : "";
        poReceipt.setPackSlip(packSlip);

        String receivedBy = xmlData.getElementsByTagName("RECEIVEDBY").getLength() != 0 ? xmlData.getElementsByTagName("RECEIVEDBY").item(0).getFirstChild().getTextContent() : "";
        poReceipt.setReceivedBy(receivedBy);

        String updatedBy = xmlData.getElementsByTagName("UPDATEDBY").getLength() != 0 ? xmlData.getElementsByTagName("UPDATEDBY").item(0).getFirstChild().getTextContent() : "";
        poReceipt.setReceivedBy(updatedBy);
    }

    @SneakyThrows
    public void setSupplier(Document xmlData, POReceipt poReceipt) {
        Node supplierId = xmlData.getElementsByTagName("SUPPLIERID").item(0);
        String supplierCode = supplierId.getFirstChild().getTextContent();
        String supplierOrganization = supplierId.getChildNodes().item(1).getTextContent();

        NodeList languageNode = xmlData.getElementsByTagName("SUPPLIERINFO");
        String language = languageNode.getLength() != 0 ? languageNode.item(0).getChildNodes().item(0).getFirstChild().getTextContent() : "";

        Supplier supplier;

        if (poReceipt.getPurchaseOrder().getSupplier() == null) {
            supplier = new Supplier();
        } else supplier = poReceipt.getPurchaseOrder().getSupplier();

        supplier.setCode(supplierCode);
        supplier.setOrganization(supplierOrganization);
        supplier.setLanguage(language);

        poReceipt.getPurchaseOrder().setSupplier(supplier);
    }

    @SneakyThrows
    public void setStore(Document xmlData, POReceipt poReceipt) {
        NodeList storeId = xmlData.getElementsByTagName("STOREID");
        String storeCode = storeId.item(0).getFirstChild().getTextContent();
        String storeDescription = storeId.item(0).getLastChild().getTextContent();

        Store store;
        if (poReceipt.getPurchaseOrder().getStore() == null) {
            store = new Store();
            store.setCode(storeCode);
        } else {
            store = poReceipt.getPurchaseOrder().getStore();
            if (!Objects.equals(store.getCode(), storeCode)) store.setCode(storeCode);
        }
        store.setDescription(storeDescription);
        poReceipt.getPurchaseOrder().setStore(store);

    }

    @SneakyThrows
    public void setPurchaseOrder(Document xmlData, POReceipt poReceipt, ApiUser apiUser) {
        String purchaseOrderCode = xmlData.getElementsByTagName("PURCHASEORDERCODE").getLength() != 0 ? xmlData.getElementsByTagName("PURCHASEORDERCODE").item(0).getTextContent() : "";
        String purchaseOrderOrganization = xmlData.getElementsByTagName("PURCHASEORDERID").getLength() != 0 ? xmlData.getElementsByTagName("PURCHASEORDERID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        PurchaseOrder purchaseOrder = purchaseOrderService.getPurchaseOrder(apiUser,purchaseOrderCode,purchaseOrderOrganization);

        poReceipt.setPurchaseOrder(purchaseOrder);
    }

    public void setClass(Document xmlData, POReceipt poReceipt) {
        String classCode = xmlData.getElementsByTagName("CLASSCODE").getLength() != 0 ? xmlData.getElementsByTagName("CLASSCODE").item(0).getTextContent() : "";
        String classOrganization = xmlData.getElementsByTagName("CLASSID").getLength() != 0 ? xmlData.getElementsByTagName("CLASSID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";
        String classDescription = xmlData.getElementsByTagName("CLASSID").getLength() != 0 ? xmlData.getElementsByTagName("CLASSID").item(0).getLastChild().getTextContent() : "";

        ClassId classId;
        if (poReceipt.getClassId() == null) {
            classId = new ClassId();
        } else classId = poReceipt.getClassId();

        classId.setCode(classCode);
        classId.setOrganization(classOrganization);
        classId.setDescription(classDescription);

    }

    public void setDateReceived(Document xmlData, POReceipt poReceipt) {

        String dateReceivedYear = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(0).getTextContent();
        String dateReceivedMonth = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(1).getTextContent();
        String dateReceivedDay = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(2).getTextContent();
        String dateReceivedHour = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(3).getTextContent();
        String dateReceivedMinute = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(4).getTextContent();
        String dateReceivedSecond = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(5).getTextContent();
        String dateReceivedSubSecond = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(6).getTextContent();
        String dateReceivedTimeZone = xmlData.getElementsByTagName("DATERECEIVED").item(0).getChildNodes().item(7).getTextContent();

        poReceipt.setDateReceived(LocalDateTime.of(Integer.parseInt(dateReceivedYear), Integer.parseInt(dateReceivedMonth), Integer.parseInt(dateReceivedDay), Integer.parseInt(dateReceivedHour), Integer.parseInt(dateReceivedMinute), Integer.parseInt(dateReceivedSecond), Integer.parseInt(dateReceivedSubSecond)));
        poReceipt.setDateReceivedTimeZone(dateReceivedTimeZone);

    }

    public void setShipVia(Document xmlData, POReceipt poReceipt) {
        NodeList shipVia = xmlData.getElementsByTagName("SHIPVIA");
        String orderTermCode = shipVia.getLength() != 0 ? shipVia.item(0).getFirstChild().getFirstChild().getTextContent() : "";
        String orderTermOrganization = shipVia.getLength() != 0 ? shipVia.item(0).getChildNodes().item(0).getFirstChild().getTextContent() : "";

        poReceipt.setOrderTermCode(orderTermCode);
        poReceipt.setOrderTermOrganization(orderTermOrganization);
    }

    public void setDateUpdated(Document xmlData, POReceipt poReceipt) {
        NodeList dateUpdated = xmlData.getElementsByTagName("DATEUPDATED");
        if (dateUpdated.getLength() != 0) {
            String dateUpdatedYear = dateUpdated.item(0).getChildNodes().item(0).getTextContent();
            String dateUpdatedMonth = dateUpdated.item(0).getChildNodes().item(1).getTextContent();
            String dateUpdatedDay = dateUpdated.item(0).getChildNodes().item(2).getTextContent();
            String dateUpdatedHour = dateUpdated.item(0).getChildNodes().item(3).getTextContent();
            String dateUpdatedMinute = dateUpdated.item(0).getChildNodes().item(4).getTextContent();
            String dateUpdatedSecond = dateUpdated.item(0).getChildNodes().item(5).getTextContent();
            String dateUpdatedSubSecond = dateUpdated.item(0).getChildNodes().item(6).getTextContent();
            String dateUpdatedTimeZone = dateUpdated.item(0).getChildNodes().item(7).getTextContent();

            poReceipt.setDateUpdated(LocalDateTime.of(Integer.parseInt(dateUpdatedYear), Integer.parseInt(dateUpdatedMonth), Integer.parseInt(dateUpdatedDay), Integer.parseInt(dateUpdatedHour), Integer.parseInt(dateUpdatedMinute), Integer.parseInt(dateUpdatedSecond), Integer.parseInt(dateUpdatedSubSecond)));
            poReceipt.setDateUpdatedTimeZone(dateUpdatedTimeZone);
        }
    }

    public void setDepartment(Document xmlData, POReceipt poReceipt) {
        String departmentCode = xmlData.getElementsByTagName("DEPARTMENTCODE").getLength() != 0 ? xmlData.getElementsByTagName("DEPARTMENTCODE").item(0).getTextContent() : "";
        String departmentOrganization = xmlData.getElementsByTagName("DEPARTMENTID").getLength() != 0 ? xmlData.getElementsByTagName("DEPARTMENTID").item(0).getChildNodes().item(1).getFirstChild().getTextContent() : "";

        poReceipt.setDepartmentCode(departmentCode);
        poReceipt.setDepartmentOrganization(departmentOrganization);
    }
}
