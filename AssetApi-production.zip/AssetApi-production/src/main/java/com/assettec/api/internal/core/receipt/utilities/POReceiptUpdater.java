package com.assettec.api.internal.core.receipt.utilities;

import com.assettec.api.internal.core.receipt.packingSlip.PackingSlip;
import com.assettec.api.internal.core.receipt.packingSlip.PackingSlipUpdater;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.receipt.POReceipt;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.List;

@Component
@AllArgsConstructor
public class POReceiptUpdater {

    private PackingSlipUpdater packingSlipUpdater;
    private POReceiptSetter poReceiptSetter;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public POReceipt getPOReceipt(ApiUser apiUser, String poReceiptCode, String organization) {
        String host = XMLParser.getInforHost();

        String postRequest = requestBuilder.getPoReceiptRequestBuilder().getPOReceipt(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(),poReceiptCode,organization);
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        POReceipt poReceipt = new POReceipt();
        setPOReceipt(xmlData, poReceipt, apiUser);

        return poReceipt;
    }

    private void setPOReceipt(Document xmlData, POReceipt poReceipt, ApiUser apiUser) {
        poReceiptSetter.setBasicData(xmlData,poReceipt);

        poReceiptSetter.setPurchaseOrder(xmlData,poReceipt,apiUser);
        poReceiptSetter.setSupplier(xmlData,poReceipt);
        poReceiptSetter.setStore(xmlData,poReceipt);

        poReceiptSetter.setClass(xmlData,poReceipt);
        poReceiptSetter.setDateReceived(xmlData,poReceipt);

        poReceiptSetter.setShipVia(xmlData,poReceipt);
        poReceiptSetter.setDateUpdated(xmlData,poReceipt);

        poReceiptSetter.setDepartment(xmlData,poReceipt);

    }

    @SneakyThrows
    public List<PackingSlip> getPackingSlipLines(ApiUser apiUser, POReceipt poReceipt) {
        String postRequest, response = "", host = XMLParser.getInforHost();
        int i = 1;

        postRequest = requestBuilder.getPackingSlipRequestBuilder().getPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(),poReceipt.getCode(), poReceipt.getOrganization(), i);
        response = requestSender.sendPostRequest(postRequest, host);
        List<PackingSlip> packingSlipList = new ArrayList<>();

        while (!response.equals("Unable to locate registry")) {
            packingSlipList.add(packingSlipUpdater.updatePackingSlip(response));

            i++;
            postRequest = requestBuilder.getPackingSlipRequestBuilder().getPackingSlip(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(),poReceipt.getCode(), poReceipt.getOrganization(), i);
            response = requestSender.sendPostRequest(postRequest, host);

        }
        return packingSlipList;
    }
}
