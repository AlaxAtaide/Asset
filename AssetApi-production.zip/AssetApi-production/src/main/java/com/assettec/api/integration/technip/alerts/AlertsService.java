package com.assettec.api.integration.technip.alerts;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.integration.technip.alerts.email.AlertEmailService;
import com.assettec.api.internal.core.installationcode.InstallationCode;
import com.assettec.api.internal.core.installationcode.InstallationCodeService;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
public class AlertsService {

    private InstallationCodeService installationCodeService;
    private AlertEmailService alertEmailService;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public void sendAlertsEmails() {
        ApiUser apiUser = new ApiUser("AGUIMARAES","Asset@2022","ASSET","EAM_ASSET");
        InstallationCode installationCode = installationCodeService.getInstallationCode(apiUser, "ENVMAIL");

        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getGridRequestBuilder().buildDataSpyGridRequest(apiUser, "WSJOBS", "WSJOBS", "2005");
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");
        if (data.getLength() == 0) throw new IllegalAccessException("Unable to get data.");

        NodeList rows = data.item(0).getChildNodes();
        if (rows.getLength() == 0) throw new IllegalAccessException("Unable to get rows.");

        for (int i = 0; i < rows.getLength(); i++) {
            Node row = rows.item(i);
            System.out.println("Ordem de Serviço: " + row.getChildNodes().item(7).getTextContent());

            // todo change source
            String[] userEmails = installationCode.getValue().split(",");
            String workOrderCode = row.getChildNodes().item(7).getTextContent();
            String workOrderDueDateString = row.getChildNodes().item(4).getTextContent();

            System.out.println("Parsing workOrderDate: " + workOrderDueDateString);
            if (!workOrderDueDateString.isEmpty()) {

                String[] workOrderDueDateArray = workOrderDueDateString.split("-");
                int workOrderDueDateYear = Integer.parseInt(workOrderDueDateArray[2]);
                int workOrderDueDateMonth = Integer.parseInt(workOrderDueDateArray[1]);
                int workOrderDueDateDay = Integer.parseInt(workOrderDueDateArray[0]);

                LocalDateTime workOrderDueDate = LocalDateTime.of(workOrderDueDateYear, workOrderDueDateMonth, workOrderDueDateDay, 0, 0);
                LocalDateTime today = LocalDateTime.now();

                if (workOrderDueDate.equals(today.plusDays(1)))
                    alertEmailService.sendWarningAlert(userEmails, workOrderCode, workOrderDueDateString, installationCode);
                if (workOrderDueDate == today)
                    alertEmailService.sendRedAlert(userEmails, workOrderCode, workOrderDueDateString, installationCode);
                if (workOrderDueDate == today.minusDays(1))
                    alertEmailService.sendDelayedAlert(userEmails, workOrderCode, workOrderDueDateString, installationCode);
            }
        }
    }
}
