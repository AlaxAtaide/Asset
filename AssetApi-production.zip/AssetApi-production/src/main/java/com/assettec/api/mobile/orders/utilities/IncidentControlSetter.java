package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.IncidentMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class IncidentControlSetter {
    public void setIncidentControl(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        IncidentMobile incident = new IncidentMobile();

        incident.setPatientIncident(workOrder.getIncidentTracking().getPatient());
        incident.setStaffInjuryIncident(workOrder.getIncidentTracking().getStaffInjury());
        incident.setSecurityIncident(workOrder.getIncidentTracking().getSecurityIncident());
        incident.setPropertyDamageIncident(workOrder.getIncidentTracking().getPropertyDamage());
        incident.setHazardousMaterialsIncident(workOrder.getIncidentTracking().getHazardousMaterialIncident());
        incident.setFireSafetyIncident(workOrder.getIncidentTracking().getFireSafetyIncident());
        incident.setMedicalEquipmentIncident(workOrder.getIncidentTracking().getMedicalEquipmentIncident());
        incident.setUtilitySystemIncident(workOrder.getIncidentTracking().getUtilitySystemIncident());

        workOrderDetails.setIncidentControl(incident);
    }
}
