package com.assettec.api.internal.core.items.asset.position;

import com.assettec.api.internal.core.entities.address.AddressSetter;
import com.assettec.api.internal.core.items.asset.system.AssetSystem;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class AssetPositionUpdater {

    private AssetPositionSetter assetPositionSetter;
    private AddressSetter addressSetter;

    public AssetPosition getPosition(NodeList resultData) {
        AssetPosition position = new AssetPosition();

        for (int i = 0; i < resultData.getLength(); i++) {
            Node resultDataNode = resultData.item(i);
            if (resultDataNode.getNodeName().equals("PositionEquipment")) {
                position.setUpdatedCount(resultDataNode.getAttributes().getNamedItem("recordid").getTextContent());
                assetPositionSetter.setPosition(position, resultDataNode.getChildNodes());
            }
            if (resultDataNode.getNodeName().equals("Addresses")) position.setAddresses(addressSetter.setAddress(resultDataNode.getChildNodes()));
        }

        return position;
    }
}
