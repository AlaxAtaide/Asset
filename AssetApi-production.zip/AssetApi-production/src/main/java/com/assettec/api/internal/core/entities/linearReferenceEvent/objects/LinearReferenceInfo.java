package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LinearReferenceInfo {
    private LinearReferenceEvent linearReferenceEvent;
    private String inspectionDirectionCode;
    private String flowCode;

    public String buildRequest() {

        String linearReference = linearReferenceEvent == null ? "" : linearReferenceEvent.buildRequest("<LINEARREFERENCEEVENT xmlns=\"http://schemas.datastream.net/MP_fields\">","</LINEARREFERENCEEVENT>");
        String inspectionDirection = inspectionDirectionCode == null ? "" : "<INSPECTIONDIRECTIONCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + inspectionDirectionCode + "</INSPECTIONDIRECTIONCODE>";
        String flow = flowCode == null ? "" : "<FLOWCODE xmlns=\"http://schemas.datastream.net/MP_fields\">" + flowCode + "</FLOWCODE>";

        return "<LinearReferenceInfo>" + linearReference + inspectionDirection + flow + "</LinearReferenceInfo>";
    }
}
