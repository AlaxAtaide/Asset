package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LinearReferenceDetails {
    private InforEamCount equipmentLength;
    private String equipmentLengthUom;
    private String linearReferenceUom;
    private String linearReferencePrecision;
    private String geographicalReference;
    private String inspectionDirectionCode;
    private String flowCode;
    private String linearCostWeight;
    private InforEamCount lrfFromPoint;
    private InforEamCount lrfToPoint;
    private OffSetDirection linearDirection;
    private InforEamCode linearEquipmentType;
}
