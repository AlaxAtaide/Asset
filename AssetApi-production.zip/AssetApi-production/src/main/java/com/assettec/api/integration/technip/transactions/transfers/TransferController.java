package com.assettec.api.integration.technip.transactions.transfers;

import com.assettec.api.internal.utilities.common.FtpConnection;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.net.ftp.FTPClient;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class TransferController {

    private TransferWatcher transferWatcher;

//    @SneakyThrows
//    @Async @Scheduled(fixedRate = 60000)
//    public void watchFTP() {
//        FTPClient ftpClient = FtpConnection.connect("192.168.1.100", "android", "android", 2021);
//        transferWatcher.checkFTPFiles(ftpClient);
//        ftpClient.disconnect();
//    }
}
