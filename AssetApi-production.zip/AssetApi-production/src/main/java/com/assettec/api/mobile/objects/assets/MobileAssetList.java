package com.assettec.api.mobile.objects.assets;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MobileAssetList {
    private int records;
    List<MobileAsset> list;
}
