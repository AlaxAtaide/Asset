package com.assettec.api.internal.core.entities.address;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Address {
    private String code;
    private String entity;
    private String type;
    private String text;
    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String state;
    private String zip;
    private String country;
    private String phone;
    private String phoneExt;
    private String fax;
    private String email;
    private String updatedCount;
}
