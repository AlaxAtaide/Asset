package com.assettec.api.mobile.objects.grid;

import com.assettec.api.internal.core.grid.DataSpy;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GridData {
    private DataSpy currentDataspy;
    private List<GridWorkOrder> workOrderList;
}
