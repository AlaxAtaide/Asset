package com.assettec.api.integration.IG.transactions.store2store;

import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.transactions.Store2StoreService;
import com.assettec.api.internal.core.transactions.StoreToStore;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class IGStore2StoreIGService {

    private Store2StoreService store2StoreService;
    private IGStore2Store2SendSetter store2Store2SendSetter;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;
    private XMLParser xmlParser;

    @SneakyThrows
    public IGStore2Store2SendList returnStore2Store(ApiUser apiUser, String status) {
        String postRequest, response, host = XMLParser.getInforHost();
        postRequest = requestBuilder.getGridRequestBuilder().buildFilterGridRequest(apiUser, "SSSTSR", "SSSTSR", "transactionstatus", status, "=");
        response = requestSender.sendPostRequest(postRequest, host);


        Document xmlData = xmlParser.toDocument(response);
        NodeList data = xmlData.getElementsByTagName("DATA");

        if (data.getLength() == 0) throw new IllegalStateException("Não foi possível encontrar nenhum registro com status: R");

        long lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

        List<IGStore2Store2Send> storeToStoreList = new ArrayList<>();
        List<Row> rows = gridService.getRows(response);

        for (Row row : rows) {
            String transactionCode = gridService.getDataByName("transactioncode",row);

            StoreToStore store2Store = store2StoreService.getStore2StoreReceipt(apiUser, transactionCode);
            store2Store.setStore2StoreParts(store2StoreService.getStore2StoreParts(apiUser, store2Store));

            IGStore2Store2Send store2Send = store2Store2SendSetter.setStore2Store2Send(apiUser, transactionCode, store2Store, store2Store.getTransactionStatus().getCode());
            storeToStoreList.add(store2Send);
        }
        if (records > lastRowNumber) {
            long position;
            while (records > lastRowNumber) {

                position = lastRowNumber + 1;
                postRequest = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursorAndFilter(apiUser, "SSSTSR", "SSSTSR", position, "transactionstatus", "ANF", "=");
                response = requestSender.sendPostRequest(postRequest, host);
                rows = gridService.getRows(response);

                for (Row row : rows) {

                    lastRowNumber = Long.parseLong(data.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                    records = Long.parseLong(xmlData.getElementsByTagName("RECORDS").item(0).getTextContent());

                    String transactionCode = gridService.getDataByName("transactioncode",row);

                    StoreToStore store2Store = store2StoreService.getStore2StoreReceipt(apiUser, transactionCode);
                    store2Store.setStore2StoreParts(store2StoreService.getStore2StoreParts(apiUser, store2Store));

                    IGStore2Store2Send store2Send = store2Store2SendSetter.setStore2Store2Send(apiUser, transactionCode, store2Store, store2Store.getTransactionStatus().getCode());
                    storeToStoreList.add(store2Send);
                }
            }
        }
        return new IGStore2Store2SendList("200","Transação realizada com sucesso.",storeToStoreList);
    }
}
