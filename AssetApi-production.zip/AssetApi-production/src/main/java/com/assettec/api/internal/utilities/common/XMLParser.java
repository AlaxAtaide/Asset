package com.assettec.api.internal.utilities.common;

import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

@Component
public class XMLParser {
    private static final Logger logger = LoggerFactory.getLogger(XMLParser.class);

    @SneakyThrows
    public void printXml(String response) {
        System.out.println(readXML(response));
    }

    @SneakyThrows
    public String readXML(String xmlString) throws TransformerException, ParserConfigurationException, IOException, SAXException {
        Transformer transformer = TransformerFactory.newInstance().newTransformer();

        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        DOMSource source = new DOMSource(toDocument(xmlString));
        StreamResult result = new StreamResult(new StringWriter());
        transformer.transform(source, result);

        return result.getWriter().toString();
    }

    public Document toDocument(String response) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        return builder.parse(new InputSource(new StringReader(response)));
    }

    private static Document readDocument(String fileUrl) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        return builder.parse(new File(fileUrl));
    }

    @SneakyThrows
    public static String getInforHost() {
        String inforHost = null, server, http, https, fileUrl;

        fileUrl = System.getProperty("os.name").contains("Windows") ? System.getProperty("user.dir") + "\\config\\config.xml" : System.getProperty("user.dir") + "/config/config.xml";

        if (!fileExists(fileUrl)) {
            createFile(fileUrl);
        }

        Document inforXml = readDocument(fileUrl);
        server = inforXml.getElementsByTagName("server").item(0).getTextContent();

        if (server.isEmpty()) {
            logger.info("[SpringFramework][ Spring boot shutting down: SKR ]");
            logger.info("[SpringFramework][ Shutdown cause: config.xml localServer is blank ]");
            if (System.getProperty("os.name").contains("Windows")) {
                logger.info("[SpringFramework][ Please modify this file: " + System.getProperty("user.dir") + "\\config\\config.xml ]");
            } else {
                logger.info("[SpringFramework][ Please modify this file: " + System.getProperty("user.dir") + "/config/config.xml ]");
            }
            System.exit(500);
        }

        if (inforXml.getElementsByTagName("http").getLength() != 0) {
            http = inforXml.getElementsByTagName("http").item(0).getTextContent();
        } else {
            http = null;
        }
        if (inforXml.getElementsByTagName("https").getLength() != 0) {
            https = inforXml.getElementsByTagName("https").item(0).getTextContent();
        } else {
            https = null;
        }
        if (http == null && https == null) inforHost = "http://" + server + "/axis/services/EWSConnector";
        if (http == null && https != null)
            inforHost = "https://" + server + ":" + https + "/axis/services/EWSConnector";
        if (https == null && http != null) inforHost = "http://" + server + ":" + http + "/axis/services/EWSConnector";
        if (http != null && https != null) inforHost = "http://" + server + ":" + http + "/axis/services/EWSConnector";
        if (server.contains("http://") || server.contains("https://")) inforHost = server + "/axis/services/EWSConnector";
        return inforHost;
    }

    private static boolean fileExists(String url) {
        File file = new File(url);
        return file.exists();
    }

    @SneakyThrows
    private static void createFile(String url) {
        File file = new File(url);
        boolean madeDir = file.getParentFile().mkdirs();
        boolean createdFile = file.createNewFile();

        if (madeDir && createdFile) logger.info("[XMLParser][ Created directories and config file ]");

        FileWriter fileWriter = new FileWriter(file);
        String xml = "\n<core>\n    <server></server>\n    <ports>\n        <http></http>\n        <https></https>\n    </ports>\n</core>";
        fileWriter.write(xml);
        fileWriter.close();
    }
}
