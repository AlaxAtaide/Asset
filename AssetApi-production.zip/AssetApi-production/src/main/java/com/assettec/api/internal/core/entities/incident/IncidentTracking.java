package com.assettec.api.internal.core.entities.incident;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IncidentTracking {
    private String patient;
    private String staffInjury;
    private String securityIncident;
    private String propertyDamage;
    private String hazardousMaterialIncident;
    private String fireSafetyIncident;
    private String medicalEquipmentIncident;
    private String utilitySystemIncident;
}
