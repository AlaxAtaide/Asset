package com.assettec.api.integration.technip.transactions.transfers;

import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;

@Component
@AllArgsConstructor
public class TransferWatcher {

    private TransferService transferService;

    @SneakyThrows
    public void checkFTPFiles(FTPClient ftpClient) {
        String[] fileNameList = ftpClient.listNames();
        if (fileNameList != null) {
            for (String fileName : fileNameList) {
                String todayString = "IssueTransactionsList-".toLowerCase() + LocalDateTime.now().getYear() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getDayOfMonth() + ".json";
                if (fileName.toLowerCase().equals(todayString)) {
                    transferService.transferFromFTP(ftpClient, fileName);
                }
            }
        }
    }

    @SneakyThrows
    @Async
    public void checkFTPFiles(FTPSClient ftpsClient) {
        String[] fileNameList = ftpsClient.listNames();
        if (fileNameList != null) {
            for (String fileName : fileNameList) {
                String todayString = "IssueTransactionsList-".toLowerCase() + LocalDateTime.now().getYear() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getDayOfMonth() + ".json";
                if (fileName.toLowerCase().equals(todayString)) {
                    transferService.transferFromFTP(ftpsClient, fileName);
                }
            }
        }
    }
}
