package com.assettec.api.internal.core.items.part;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.core.items.part.utilities.PartSetter;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

@Service
@AllArgsConstructor
public class PartService {

    private RequestSender requestSender;
    private RequestCreator requestBuilder;
    private XMLParser xmlParser;
    private PartSetter partSetter;

    @SneakyThrows
    public Part getPart(ApiUser apiUser, String partCode, String partOrganization) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getPartRequestBuilder().getPart(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), partCode, partOrganization);
        String response = requestSender.sendPostRequest(postRequest, host);

        Document xmlData = xmlParser.toDocument(response);
        return partSetter.setPart(xmlData, new Part());
    }
}
