package com.assettec.api.mobile.objects.assets;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MobileAsset {
    private int Id;
    private String code;
    private String organization;
    private String description;
    private String status;
    private String department;
}
