package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.CountSetter;
import com.assettec.api.internal.core.entities.basic.setter.DateSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.PerformanceDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class PerformanceDetailsSetter {

    private IdSetter idSetter;
    private CodeSetter codeSetter;
    private DateSetter dateSetter;
    private CountSetter countSetter;
    private EquipmentConfigurationIdSetter equipmentConfigurationIdSetter;

    public PerformanceDetails setPerformanceDetails(NodeList childNodes) {
        PerformanceDetails performanceDetails = new PerformanceDetails();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeName().equals("PERFORMANCEFORMULAID")) performanceDetails.setPerformanceFormula(equipmentConfigurationIdSetter.setEquipmentConfigurationId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("PERFORMANCE")) performanceDetails.setPerformance(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CONDITIONRATINGWEIGHT")) performanceDetails.setConditionRatingWeight(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CAPACITYCODE")) performanceDetails.setCapacityCode(idSetter.setEntity(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("AVAILABLECAPACITY")) performanceDetails.setAvailableCapacity(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LASTUPDATEDDATE")) performanceDetails.setLastUpdatedDate(dateSetter.setDate(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("DESIREDCAPACITY")) performanceDetails.setDesiredCapacity(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("CAPACITYRATINGWEIGHT")) performanceDetails.setCapacityRatingWeight(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("NOOFFAILURES")) performanceDetails.setNoOffFailures(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MTBFDAYS")) performanceDetails.setMtbfDays(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MTBFRATINGWEIGHT")) performanceDetails.setMtbfRatingWeight(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MUBF")) performanceDetails.setMubf(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MUBFUOM")) performanceDetails.setMubfUom(codeSetter.setCode(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MUBFRATING")) performanceDetails.setMubfRating(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MTTRHRS")) performanceDetails.setMttrHrs(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("MTTRRATING")) performanceDetails.setMttrRating(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE1RESULT")) performanceDetails.setVariableResult1(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE2RESULT")) performanceDetails.setVariableResult2(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE3RESULT")) performanceDetails.setVariableResult3(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE4RESULT")) performanceDetails.setVariableResult4(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE5RESULT")) performanceDetails.setVariableResult5(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE6RESULT")) performanceDetails.setVariableResult6(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE1RATING")) performanceDetails.setVariableRating1(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE2RATING")) performanceDetails.setVariableRating2(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE3RATING")) performanceDetails.setVariableRating3(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE4RATING")) performanceDetails.setVariableRating4(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE5RATING")) performanceDetails.setVariableRating5(countSetter.setCount(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("VARIABLE6RATING")) performanceDetails.setVariableRating6(countSetter.setCount(childNode.getChildNodes()));
        }

        return performanceDetails;
    }
}
