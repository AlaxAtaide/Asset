package com.assettec.api.integration.IG.transactions.store2store;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGStore2Store2Send {

    private String classId;
    private String status;
    private String store2storeCode;
    private String fromStore;
    private String fromStoreOrganization;
    private String toStore;
    private String toStoreOrganization;
    private int partQuantity;

    private List<IGStore2Store2SendPart> store2StoreParts;
}
