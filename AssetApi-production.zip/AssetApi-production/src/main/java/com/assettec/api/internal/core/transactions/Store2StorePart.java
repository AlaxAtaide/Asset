package com.assettec.api.internal.core.transactions;

import com.assettec.api.internal.core.entities.basic.objects.Id.IdLineNum;
import com.assettec.api.internal.core.entities.department.Department;
import com.assettec.api.internal.core.entities.manufacturer.Manufacturer;
import com.assettec.api.internal.core.items.asset.equipment.AssetEquipment;
import com.assettec.api.internal.core.items.part.Part;
import com.assettec.api.internal.core.user.info.area.UserDefinedArea;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFields;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Store2StorePart {
    private Part part;
    private String LineNum;
    private String receiptQuantityValue;
    private String receiptQuantityDecimals;
    private String repairReceiptQuantityValue;
    private String repairReceiptQuantityDecimals;
    private String scrapQuantityValue;
    private String scrapQuantityDecimals;
    private String toBin;
    private String oldBin;

    private AssetEquipment asset;
    private String priceValue;
    private String priceDecimals;
    private String coreValue;
    private String coreDecimals;
    private String stockPriceValue;
    private String stockPriceDecimals;

    private Department department;
    private Manufacturer primaryManufacturer;
    private String primaryManufacturerPartCode;
    private String printQuantityValue;
    private String printQuantityDecimals;

    private String labelPrintingDefault;
    private String partConditionTemplateCode;
    private AssetEquipment attachToEquipment;

    private String byAsset;
    private String uomCode;
    private String status;
    private String inTransitQuantityValue;
    private String inTransitQuantityDecimals;
    private String inTransitRepairQuantityValue;
    private String inTransitRepairQuantityDecimals;
    private String currency;

    private LocalDateTime expirationDate;
    private String expirationDateTimeZone;

    private String manufacturerLot;
    private String serialNumber;
    private String repairable;

    private IdLineNum requisition;
    private UserDefinedArea userDefinedArea;
    private UserDefinedFields userDefinedFields;
}
