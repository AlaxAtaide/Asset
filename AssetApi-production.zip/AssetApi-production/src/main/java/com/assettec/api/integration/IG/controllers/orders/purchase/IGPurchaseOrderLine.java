package com.assettec.api.integration.IG.controllers.orders.purchase;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGPurchaseOrderLine {
    private int purchaseOrderLine;
    private String partCode;
    private String igerpPartCode;
    private String partOrganization;
    private String partDescription;
    private double quantity;
    private String UnitOfMetric;
    private double quantityPerUnitOfMetric;
    private double pricePerUnitOfMetric;
}
