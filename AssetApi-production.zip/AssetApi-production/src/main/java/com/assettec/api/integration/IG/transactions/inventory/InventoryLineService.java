package com.assettec.api.integration.IG.transactions.inventory;

import com.assettec.api.integration.IG.transactions.inventory.utilities.FilterInventoryArray;
import com.assettec.api.internal.core.grid.GridService;
import com.assettec.api.internal.core.grid.Row;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import com.assettec.api.internal.utilities.common.XMLParser;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class InventoryLineService {

    private FilterInventoryArray filterInventoryArray;
    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private GridService gridService;
    private XMLParser xmlParser;

    public static void joinSimilarLines(List<InventoryLine> inventory, InventoryLine inventoryRequest) {
        double totalPartQuantity;
        totalPartQuantity = inventory.stream().mapToDouble(InventoryLine::getQuantityInStore).sum();

        inventoryRequest.setId(1L);
        inventoryRequest.setPartCode(inventory.get(0).getPartCode());
        inventoryRequest.setPartName(inventory.get(0).getPartName());
        inventoryRequest.setPartOrganization(inventory.get(0).getPartOrganization());
        inventoryRequest.setStore(inventory.get(0).getStore());
        inventoryRequest.setBasePrice(inventory.get(0).getBasePrice());
        inventoryRequest.setLastPrice(inventory.get(0).getLastPrice());
        inventoryRequest.setAveragePrice(inventory.get(0).getAveragePrice());
        inventoryRequest.setStandardPrice(inventory.get(0).getStandardPrice());

        inventoryRequest.setQuantityInStore(totalPartQuantity);
    }

    @SneakyThrows
    public List<InventoryLine> getAllInventoryLines(ApiUser apiUser) {
        String host = XMLParser.getInforHost();

        String request = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "WUSPED", "WUSPED");
        String response = requestSender.sendPostRequest(request, host);

        if (response.equals("Invalid GridName")) {
            request = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "WUSPEA", "WUSPEA");
            response = requestSender.sendPostRequest(request, host);
        }

        Document doc = xmlParser.toDocument(response);
        NodeList dataList = doc.getElementsByTagName("DATA");

        long lastRowNumber = Long.parseLong(dataList.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
        long records = Long.parseLong(doc.getElementsByTagName("RECORDS").item(0).getTextContent());
        List<Row> rows = gridService.getRows(response);

        if (records > lastRowNumber) {
            List<InventoryLine> inventoryLines = addLinesToArray(rows);
            long position;
            while (records > lastRowNumber) {
                position = lastRowNumber + 1;
                request = requestBuilder.getGridRequestBuilder().buildGridRequestWithCursor(apiUser, "WUSPED", "WUSPED", position);
                response = requestSender.sendPostRequest(request,host);

                if (response.equals("Invalid GridName")) {
                    request = requestBuilder.getGridRequestBuilder().buildGridRequest(apiUser, "WUSPEA", "WUSPEA");
                    response = requestSender.sendPostRequest(request, host);
                }

                doc = xmlParser.toDocument(response);
                dataList = doc.getElementsByTagName("DATA");
                rows = gridService.getRows(response);

                addLinesToArray(inventoryLines, rows);

                lastRowNumber = Long.parseLong(dataList.item(0).getLastChild().getAttributes().getNamedItem("id").getTextContent());
                records = Long.parseLong(doc.getElementsByTagName("RECORDS").item(0).getTextContent());
            }
            return inventoryLines;
        } else return addLinesToArray(rows);
    }

    private void addLinesToArray(List<InventoryLine> inventoryLines, List<Row> rows) {
        for (Row row : rows) {

            String id = row.getId();
            String averagePrice = gridService.getDataByName("par_avgprice",row);
            String basePrice = gridService.getDataByName("par_baseprice",row);
            String lastPrice = gridService.getDataByName("par_lastprice",row);
            String standardPrice = gridService.getDataByName("par_stdprice",row);
            String store = gridService.getDataByName("bis_store",row);
            String quantity = gridService.getDataByName("bis_qty",row);
            String partCode = gridService.getDataByName("bis_part",row);
            String partDescription = gridService.getDataByName("par_desc",row);
            String partOrganization = gridService.getDataByName("str_org",row);

            InventoryLine inventoryLine = new InventoryLine();

            inventoryLine.setId(Long.valueOf(id));
            inventoryLine.setPartCode(partCode);
            inventoryLine.setPartName(partDescription);
            inventoryLine.setPartOrganization(partOrganization);
            inventoryLine.setStore(store);
            inventoryLine.setQuantityInStore(Double.parseDouble(quantity.replace(",", ".")));
            inventoryLine.setLastPrice(lastPrice);
            inventoryLine.setBasePrice(basePrice);
            inventoryLine.setAveragePrice(averagePrice);
            inventoryLine.setStandardPrice(standardPrice);

            inventoryLines.add(inventoryLine);
        }
    }

    private List<InventoryLine> addLinesToArray(List<Row> rows) {
        List<InventoryLine> inventoryLines = new ArrayList<>();
        addLinesToArray(inventoryLines,rows);
        return inventoryLines;
    }

    public List<InventoryLine> requestRouter(String partCode, String partOrganization, String store, List<InventoryLine> allInventoryLines) {
        if (partCode == null || store == null || partOrganization == null) {
            throw new IllegalStateException("requestBody fields must not be null" +
                    "partCode: " + partCode +
                    "partOrganization: " + partOrganization +
                    "store: " + store);
        } else if (!store.isEmpty() && !partCode.isEmpty() && !partOrganization.isEmpty()) {
            return filterInventoryArray.byStoreCodeAndOrganization(store,partCode,partOrganization,allInventoryLines);
        } else if (!store.isEmpty() && partCode.isEmpty() && partOrganization.isEmpty()) {
            return filterInventoryArray.byStore(store, allInventoryLines);
        } else if (store.isEmpty() && !partCode.isEmpty() && partOrganization.isEmpty()) {
            return filterInventoryArray.byPartCode(partCode, allInventoryLines);
        } else if (store.isEmpty() && partCode.isEmpty() && !partOrganization.isEmpty()) {
            return filterInventoryArray.byOrganization(partOrganization, allInventoryLines);
        } else if (!store.isEmpty() && !partCode.isEmpty()) {
            return filterInventoryArray.byCodeStore(partCode,store,allInventoryLines);
        } else if (!store.isEmpty()) {
            return filterInventoryArray.byStoreOrganization(store,partOrganization,allInventoryLines);
        } else if (!partCode.isEmpty()) {
            return filterInventoryArray.byCodeOrg(partCode,partOrganization,allInventoryLines);
        } else return allInventoryLines;
    }
}
