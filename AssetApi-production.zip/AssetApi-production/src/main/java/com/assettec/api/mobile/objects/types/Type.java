package com.assettec.api.mobile.objects.types;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Type {
    private int id;
    private String code;
    private String description;
    private String userGroup;
    private List<String> status;
    private boolean systemCode;
    private boolean notUsed;
}
