package com.assettec.api.integration.IG.transactions.receipt;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGPOReceiptRequest {
    private String http;
    private String message;

    private String receiptOrganization;
    private String receiptDescription;
    private String receiptStatus;
    private String purchaseOrderCode;
    private String purchaseOrderOrganization;
    private List<IGPartReceiptLines> partReceiptLines;
}
