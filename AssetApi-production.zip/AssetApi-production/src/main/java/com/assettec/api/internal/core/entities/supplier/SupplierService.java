package com.assettec.api.internal.core.entities.supplier;

import com.assettec.api.integration.IG.controllers.supplier.IGSupplier;
import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.utilities.common.XMLParser;
import com.assettec.api.internal.utilities.handlers.RequestCreator;
import com.assettec.api.internal.utilities.handlers.RequestSender;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

@Service
@AllArgsConstructor
public class SupplierService {

    private RequestCreator requestBuilder;
    private RequestSender requestSender;
    private XMLParser xmlParser;

    @SneakyThrows
    public String getContact(ApiUser apiUser, IGSupplier request, int sequenceNumber) {
        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getSupplierRequestBuilder().getSupplierContact(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*", sequenceNumber);
        String rawResponse = requestSender.sendPostRequest(postRequest, host);
        String response = rawResponse.replaceAll("ns[0-9]:", "").replaceAll("ns[0-9][0-9]:", "").replaceAll("ns[0-9][0-9][0-9]:", "");

        if (!response.equals("Cannot find the SupplierContact record.")) {
            Document xmlData = xmlParser.toDocument(response);

            Node contactInfo = xmlData.getElementsByTagName("CONTACTINFO").item(0);
            return contactInfo.getFirstChild().getTextContent();
        } else return response;
    }

    @SneakyThrows
    public Supplier getSupplier(ApiUser apiUser, IGSupplier request) {

        String host = XMLParser.getInforHost();
        String postRequest = requestBuilder.getSupplierRequestBuilder().getSupplier(apiUser.getUsername(), apiUser.getTenant(), apiUser.getPassword(), apiUser.getOrganization(), request.getSupplierCode(), "*");
        String rawResponse = requestSender.sendPostRequest(postRequest, host);
        String response = rawResponse.replaceAll("ns[0-9]:", "").replaceAll("ns[0-9][0-9]:", "").replaceAll("ns[0-9][0-9][0-9]:", "");

        if (!response.equals("Cannot find the Supplier record.")) {
            Document xmlData = xmlParser.toDocument(response);
            Node supplierId = xmlData.getElementsByTagName("SUPPLIERID").item(0);
            String supplierCode = supplierId.getFirstChild().getTextContent();

            Supplier supplier = new Supplier();
            supplier.setCode(supplierCode);
            return supplier;

        } else {
            return new Supplier();
        }
    }
}
