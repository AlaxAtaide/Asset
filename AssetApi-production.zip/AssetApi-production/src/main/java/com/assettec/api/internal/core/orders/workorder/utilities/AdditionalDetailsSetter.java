package com.assettec.api.internal.core.orders.workorder.utilities;

import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.entities.linearReferenceEvent.setter.LinearReferenceInfoSetter;
import com.assettec.api.internal.core.orders.workorder.AdditionalDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class AdditionalDetailsSetter {

    private IdSetter idSetter;
    private LinearReferenceInfoSetter linearReferenceInfoSetter;

    public AdditionalDetails setAdditionalDetails(NodeList childNodes) {
        AdditionalDetails additionalDetails = new AdditionalDetails();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);

            if (childNode.getNodeName().equals("RELATEDWORKORDERID")) additionalDetails.setRelatedWorkOrderId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("OBJTYPE")) additionalDetails.setObjType(childNode.getTextContent());
            if (childNode.getNodeName().equals("DEPARTMENTID")) additionalDetails.setDepartmentid(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("LOCATIONID")) additionalDetails.setLocationId(idSetter.setId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("COSTCODEID")) additionalDetails.setCostCodeId(idSetter.setCostCodeId(childNode.getChildNodes()));
            if (childNode.getNodeName().equals("SAFETY")) additionalDetails.setSafety(childNode.getTextContent());
            if (childNode.getNodeName().equals("WARRANTY")) additionalDetails.setWarranty(childNode.getTextContent());
            if (childNode.getNodeName().equals("LinearReferenceInfo")) additionalDetails.setLinearReferenceInfo(linearReferenceInfoSetter.setLinearReferenceInfo(childNode.getChildNodes()));
        }

        return additionalDetails;
    }
}
