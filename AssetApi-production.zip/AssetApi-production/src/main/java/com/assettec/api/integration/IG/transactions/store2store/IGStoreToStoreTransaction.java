package com.assettec.api.integration.IG.transactions.store2store;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class IGStoreToStoreTransaction {
    private String username;
    private String tenant;
    private String userOrganization;
    private String userPassword;

    private String transactionCode;
    private String organization;
    private String description;
    private String status;
    private String fromStoreCode;
    private String toStoreCode;

    private int updatedCount;
}
