package com.assettec.api.internal.core.entities.linearReferenceEvent.objects;

import com.assettec.api.internal.core.entities.basic.objects.InforEamCode;
import com.assettec.api.internal.core.entities.basic.objects.InforEamCount;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LinearReferenceEvent {
    private InforEamCount fromPoint;
    private String fromReferenceDescription;
    private String fromGeoReference;
    private InforEamCount toPoint;
    private String toReferenceDescription;
    private String toGeoReference;
    private InforEamCode fromReferenceId;
    private InforEamCount fromOffset;
    private InforEamCount fromOffsetPercentage;
    private OffSetDirection fromOffSetDirection;
    private Coordinate fromCoordinate;
    private InforEamCount fromLatitude;
    private InforEamCount fromLongitude;
    private HorizontalVerticalDetails fromHorizontalVerticalDetails;
    private InforEamCode toReferenceId;
    private InforEamCount toOffset;
    private InforEamCount toOffsetPercentage;
    private OffSetDirection toOffSetDirection;
    private Coordinate toCoordinate;
    private InforEamCount toLatitude;
    private InforEamCount toLongitude;
    private HorizontalVerticalDetails toHorizontalVerticalDetails;
    private InforEamCode relationShipType;
    private Details relatedLinearReferenceEventDetails;

    public String buildRequest(String upper, String lower) {

        String fromPointString = fromPoint == null ? "" : "<FROMPOINT qualifier=\"ACTHRS\">" + fromPoint.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</FROMPOINT>";
        String fromRefDesc = fromReferenceDescription == null || fromReferenceDescription.isEmpty() ? "" : "<FROMREFDESC>" + fromReferenceDescription + "</FROMREFDESC>";
        String fromGeoRef = fromGeoReference == null || fromGeoReference.isEmpty() ? "" : "<FROMGEOREF>" + fromGeoReference + "</FROMGEOREF>";

        String toPointString = toPoint == null ? "" : "<TOPOINT qualifier=\"ACTHRS\">" + toPoint.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</TOPOINT>";
        String toRefDesc = toReferenceDescription == null ? "" : "<TOREFDESC>" + toReferenceDescription + "</TOREFDESC>";
        String toGeoRef = toGeoReference == null ? "" : "<TOGEOREF>" + toGeoReference + "</TOGEOREF>";

        String fromReferenceIdString = fromReferenceId == null ? "" : "<FROMREFERENCEID>" +
                "<LINEARREFERENCECODE>" + fromReferenceId.getCode() + "</LINEARREFERENCECODE>" +
                "<DESCRIPTION>" + fromReferenceId.getDescription() + "</DESCRIPTION>" +
                "</FROMREFERENCEID>";

        String fromOffsetString = fromOffset == null ? "" : "<FROMOFFSET qualifier=\"ALLOWEDWT\">" + fromOffset.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</FROMOFFSET>";
        String fromOffsetPercent = fromOffsetPercentage == null ? "" : "<FROMOFFSETPERCENTAGE qualifier=\"ACTHRS\">" + fromOffsetPercentage.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</FROMOFFSETPERCENTAGE>";
        String fromOffsetDirectionString = fromOffSetDirection == null ? "" : "<FROMOFFSETDIRECTION>" + fromOffSetDirection.buildRequest() + "</FROMOFFSETDIRECTION>";

        String fromCoordinateString = fromCoordinate == null ? "" : "<FROMCOORDINATE>" + fromCoordinate.buildRequest() + "</FROMCOORDINATE>";
        String fromLatitudeString = fromLatitude == null ? "" : "<FROMLATITUDE qualifier=\"ACTHRS\">" + fromLatitude.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</FROMLATITUDE>";
        String fromLongitudeString = fromLongitude == null ? "" : "<FROMLONGITUDE qualifier=\"ACTHRS\">" + fromLongitude.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</FROMLONGITUDE>";

        String fromHVD = fromHorizontalVerticalDetails == null ? "" : "<FROMHORIZONTALVERTICALDETAILS>" + fromHorizontalVerticalDetails.buildRequest() + "</FROMHORIZONTALVERTICALDETAILS>";

        String toReferenceIdString = toReferenceId == null ? "" : "<TOREFERENCEID>" +
                "<LINEARREFERENCECODE>" + toReferenceId.getCode() + "</LINEARREFERENCECODE>" +
                "<DESCRIPTION>" + toReferenceId.getDescription() + "</DESCRIPTION>" +
                "</TOREFERENCEID>";

        String toOffsetString = toOffset == null ? "" : "<TOOFFSET qualifier=\"ALLOWEDWT\">" + toOffset.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</TOOFFSET>";
        String toOffsetPercent = toOffsetPercentage == null ? "" : "<TOOFFSETPERCENTAGE qualifier=\"ACTHRS\">" + toOffsetPercentage.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</TOOFFSETPERCENTAGE>";
        String toOffsetDirection = toOffSetDirection == null ? "" : "<TOOFFSETDIRECTION>" + toOffSetDirection.buildRequest() + "</TOOFFSETDIRECTION>";
        String toCoordinateString = toCoordinate == null ? "" : "<TOCOORDINATE>" + toCoordinate.buildRequest() + "</TOCOORDINATE>";
        String toLatitudeString = toLatitude == null ? "" : "<TOLATITUDE qualifier=\"ACTHRS\">" + toLatitude.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</TOLATITUDE>";
        String toLongitudeString = toLongitude == null ? "" : "<TOLONGITUDE qualifier=\"ACTHRS\">" + toLongitude.buildRequest("<TASKQUANTITY qualifier=\"ACCEPTED\">", "</TASKQUANTITY>") + "</TOLONGITUDE>";
        String toHVD = toHorizontalVerticalDetails == null ? "" : "<TOHORIZONTALVERTICALDETAILS>" + toHorizontalVerticalDetails.buildRequest() + "</TOHORIZONTALVERTICALDETAILS>";
        String relationShipTypeId =  relationShipType == null ? "" : "<RELATIONSHIPTYPEID entity=\"AssetEquipment\">" +
                "<TYPECODE>" + relationShipType.getCode() + "</TYPECODE>" +
                "<DESCRIPTION>" + relationShipType.getDescription() + "</DESCRIPTION>" +
                "</RELATIONSHIPTYPEID>";

        String relatedLinearReferenceEvent = relatedLinearReferenceEventDetails == null ? "" : relatedLinearReferenceEventDetails.buildRequest();

        return upper + fromPointString + fromRefDesc + fromGeoRef + toPointString +
                toRefDesc + toGeoRef + fromReferenceIdString + fromOffsetString +
                fromOffsetPercent + fromOffsetDirectionString + fromCoordinateString +
                fromLatitudeString + fromLongitudeString + fromHVD + toReferenceIdString +
                toOffsetString + toOffsetPercent + toOffsetDirection + toCoordinateString +
                toLatitudeString + toLongitudeString + toHVD + relationShipTypeId + relatedLinearReferenceEvent + lower;
    }
}
