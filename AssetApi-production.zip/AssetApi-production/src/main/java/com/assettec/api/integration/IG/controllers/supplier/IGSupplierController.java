package com.assettec.api.integration.IG.controllers.supplier;

import com.assettec.api.internal.users.ApiUser;
import com.assettec.api.internal.users.ApiUserService;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(path = "supplier")
@AllArgsConstructor
public class IGSupplierController {

    private ApiUserService apiUserService;
    private IGSupplierService supplierService;

    @SneakyThrows
    @PostMapping()
    public IGSupplier registerSupplier(@RequestParam(name = "token") String token, @RequestBody IGSupplier request) {
        ApiUser apiUser = apiUserService.findByToken(token);
        return supplierService.registerSupplier(apiUser, request);
    }

}
