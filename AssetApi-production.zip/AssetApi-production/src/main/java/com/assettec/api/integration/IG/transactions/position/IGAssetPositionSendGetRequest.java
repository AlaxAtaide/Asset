package com.assettec.api.integration.IG.transactions.position;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IGAssetPositionSendGetRequest {
    private String positionCode;
    private String oldOrganization;
    private String newOrganization;
    private String positionDescription;
    private String positionType;
    private String positionStatus;
    private String positionDepartment;
    private double positionValue;
    private String positionSerialNumber;
    private String positionModel;
    private String positionState;
    private LocalDateTime purchaseDate;
    private double purchaseCost;
    private String codeIGERP;
    private String codeIGPAT;
    private String codeBEMIG;
    private String sent;
}
