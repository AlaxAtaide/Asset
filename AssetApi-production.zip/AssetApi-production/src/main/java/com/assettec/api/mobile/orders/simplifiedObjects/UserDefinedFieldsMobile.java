package com.assettec.api.mobile.orders.simplifiedObjects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserDefinedFieldsMobile {
    private String udfChar01;
    private String udfChar02;
    private String udfChar03;
    private String udfChar04;
    private String udfChar05;
    private String udfChar06;
    private String udfChar07;
    private String udfChar08;
    private String udfChar09;
    private String udfChar10;
    private String udfChar11;
    private String udfChar12;
    private String udfChar13;
    private String udfChar14;
    private String udfChar15;
    private String udfChar16;
    private String udfChar17;
    private String udfChar18;
    private String udfChar19;
    private String udfChar20;
    private String udfChar21;
    private String udfChar22;
    private String udfChar23;
    private String udfChar24;
    private String udfChar25;
    private String udfChar26;
    private String udfChar27;
    private String udfChar28;
    private String udfChar29;
    private String udfChar30;
    private String udfChar31;
    private String udfChar32;
    private String udfChar33;
    private String udfChar34;
    private String udfChar35;
    private String udfChar36;
    private String udfChar37;
    private String udfChar38;
    private String udfChar39;
    private String udfChar40;
    private String udfChar41;
    private String udfChar42;
    private String udfChar43;
    private String udfChar44;
    private String udfChar45;

    private String udfNum1;
    private String udfNum2;
    private String udfNum3;
    private String udfNum4;
    private String udfNum5;
    private String udfNum6;
    private String udfNum7;
    private String udfNum8;
    private String udfNum9;
    private String udfNum10;

    private String udfDate1;
    private String udfDate2;
    private String udfDate3;
    private String udfDate4;
    private String udfDate5;
    private String udfDate6;
    private String udfDate7;
    private String udfDate8;
    private String udfDate9;
    private String udfDate10;

    private String udfChkBox01;
    private String udfChkBox02;
    private String udfChkBox03;
    private String udfChkBox04;
    private String udfChkBox05;
    private String udfChkBox06;
    private String udfChkBox07;
    private String udfChkBox08;
    private String udfChkBox09;
    private String udfChkBox10;

    private String udfNote01;
    private String udfNote02;
    private String udfNote03;
    private String udfNote04;
    private String udfNote05;
    private String udfNote06;
    private String udfNote07;
    private String udfNote08;
    private String udfNote09;
    private String udfNote10;

    public static UserDefinedFieldsMobile createEmpty() {
        return new UserDefinedFieldsMobile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", "",
                "", "", "", "", "", "", "", "", "", ""
        );
    }
}
