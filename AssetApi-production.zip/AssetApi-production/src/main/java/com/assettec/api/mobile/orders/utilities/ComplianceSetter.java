package com.assettec.api.mobile.orders.utilities;

import com.assettec.api.internal.core.orders.workorder.WorkOrder;
import com.assettec.api.mobile.orders.simplifiedObjects.ComplianceMobile;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class ComplianceSetter {
    public void setCompliance(WorkOrderDetails workOrderDetails, WorkOrder workOrder) {
        ComplianceMobile compliance = new ComplianceMobile();

        compliance.setAboveCeilingPermit(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getAboveCeilingPermit() == null
                ? "" : workOrder.getComplianceDetail().getAboveCeilingPermit());

        compliance.setInterimLifeSafety(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getInterimLifeSafety() == null
                ? "" : workOrder.getComplianceDetail().getInterimLifeSafety());

        compliance.setInterimInfectionControl(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getInterimInfectionControl() == null
                ? "" : workOrder.getComplianceDetail().getInterimInfectionControl());

        compliance.setPreConstructionRiskAssessment(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getPreConstructionRiskAssessment() == null
                ? "" : workOrder.getComplianceDetail().getPreConstructionRiskAssessment());

        compliance.setPlanImprovement(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getPlanImprovement() == null
                ? "" : workOrder.getComplianceDetail().getPlanImprovement());

        compliance.setStatementOfCondition(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getStatementOfCondition() == null
                ? "" : workOrder.getComplianceDetail().getStatementOfCondition());

        compliance.setBuildMaintenanceProgram(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getBuildMainTProgram() == null
                ? "" : workOrder.getComplianceDetail().getBuildMainTProgram());

        compliance.setPersonalProtectiveEquipment(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getPersonalProtectiveEquipment() == null
                ? "" : workOrder.getComplianceDetail().getPersonalProtectiveEquipment());

        compliance.setLockout(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getLockout() == null
                ? "" : workOrder.getComplianceDetail().getLockout());

        compliance.setBurnPermit(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getBurnPermit() == null
                ? "" : workOrder.getComplianceDetail().getBurnPermit());

        compliance.setConfinedSpace(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getConfinedSpace() == null
                ? "" : workOrder.getComplianceDetail().getConfinedSpace());

        compliance.setPatientSafety(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getPatientSafety() == null
                ? "" : workOrder.getComplianceDetail().getPatientSafety());

        compliance.setRecallNotice(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getRecallNotice() == null
                ? "" : workOrder.getComplianceDetail().getRecallNotice());

        compliance.setSMDA(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getSMDA() == null
                ? "" : workOrder.getComplianceDetail().getSMDA());

        compliance.setHipaaConfidentiality(workOrder.getComplianceDetail() == null
                || workOrder.getComplianceDetail().getHipaaConfidentiality() == null
                ? "" : workOrder.getComplianceDetail().getHipaaConfidentiality());


        workOrderDetails.setCompliance(compliance);
    }
}
