package com.assettec.api.internal.core.items.asset.common.setters;

import com.assettec.api.internal.core.entities.basic.setter.CodeSetter;
import com.assettec.api.internal.core.entities.basic.setter.IdSetter;
import com.assettec.api.internal.core.items.asset.common.objects.RentalDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Component
@AllArgsConstructor
public class RentalDetailsSetter {

    private CodeSetter codeSetter;
    private IdSetter idSetter;

    public RentalDetails setRentalDetails(NodeList nodes) {
        RentalDetails rentalDetails = new RentalDetails();

        for (int i = 0; i < nodes.getLength(); i++) {
            Node childNode = nodes.item(i);
            String nodeName = childNode.getNodeName();

            if (nodeName.equals("VEHICLETYPE")) rentalDetails.setVehicleType(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("ISRENTAL")) rentalDetails.setIsRental(childNode.getTextContent());
            if (nodeName.equals("RENTALTEMPLATEID")) rentalDetails.setRentalTemplateId(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("ISCONTRACT")) rentalDetails.setIsContract(childNode.getTextContent());
            if (nodeName.equals("CONTRACTTEMPLATEID")) rentalDetails.setContractTemplateId(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("CUSTOMERID")) rentalDetails.setCustomerId(idSetter.setId(childNode.getChildNodes()));
            if (nodeName.equals("AVAILABILITYSTATUS")) rentalDetails.setAvailabilityStatus(codeSetter.setCode(childNode.getChildNodes()));
            if (nodeName.equals("ISSUETO")) rentalDetails.setIssueTo(codeSetter.setCode(childNode.getChildNodes()));

        }

        return rentalDetails;
    }
}
