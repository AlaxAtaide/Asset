package com.assettec.api.internal.core.entities.activity.setter;

import com.assettec.api.internal.core.entities.activity.Activity;
import com.assettec.api.internal.core.entities.basic.setter.*;
import com.assettec.api.internal.core.entities.linearReferenceEvent.setter.LinearReferenceEventSetter;
import com.assettec.api.internal.core.user.info.fields.UserDefinedFieldsSetter;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

@Component
@AllArgsConstructor
public class ActivitySetter {

    private IdSetter idSetter;
    private CountSetter countSetter;
    private CodeSetter codeSetter;
    private DateSetter dateSetter;
    private CurrencySetter currencySetter;
    private LinearReferenceEventSetter linearReferenceEventSetter;
    private ActivityIdSetter activityIdSetter;
    private RelatedWorkOrderEquipmentSetter relatedWorkOrderEquipmentSetter;
    private UserDefinedFieldsSetter userDefinedFieldsSetter;

    public Activity setActivities(NodeList activitiesList) {

        Activity activity = new Activity();
        Node activityItem = activitiesList.item(0);

        for (int j = 0; j < activityItem.getChildNodes().getLength(); j++) {
            Node activityChildNode = activityItem.getChildNodes().item(j);

            if (activityChildNode.getNodeName().equals("ACTIVITYID"))
                activity.setActivityId(activityIdSetter.setActivityId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("TRADEID"))
                activity.setTradeId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("MULTIPLETRADES"))
                activity.setMultipleTrades(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("PLANNINGLEVEL"))
                activity.setPlanningLevel(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("DEPARTMENTID"))
                activity.setDepartmentId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ESTIMATEDHOURS"))
                activity.setEstimatedHours(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("HOURSREMAINING"))
                activity.setHoursRemaining(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("PERSONS"))
                activity.setPersons(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("TOTALESTIMATEDHOURS"))
                activity.setTotalEstimatedHours(countSetter.setCount(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("TOTALHOURSREMAINING"))
                activity.setTotalHoursRemaining(countSetter.setCount(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("TOTALHOURSREMAINING"))
                activity.setTotalPeopleRequired(countSetter.setCount(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("TASKSID"))
                activity.setTaskId(idSetter.setTaskId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("MATLIST"))
                activity.setMatList(codeSetter.setCodeRevision(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("COMPLETED"))
                activity.setCompleted(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("PERCENTCOMPLETED"))
                activity.setCompletedPercentage(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("ACTIVITYSTARTDATE"))
                activity.setStartDate(dateSetter.setDate(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ACTIVITYENDDATE"))
                activity.setEndDate(dateSetter.setDate(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("DATELASTSCHEDULED"))
                activity.setLastScheduledDate(dateSetter.setDate(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("SCHEDULEDHOURS"))
                activity.setScheduledHours(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("HIREDLABOR"))
                activity.setHiredLabor(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("LABORTYPE"))
                activity.setLaborType(codeSetter.setCode(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("SUPPLIERID"))
                activity.setSupplierId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("NORMALHOURSWORKED"))
                activity.setNormalWorkedHours(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("OVERTIMEHOURSWORKED"))
                activity.setOverTimeWorkHours(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("SOURCESYSTEM"))
                activity.setSourceSystem(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("SOURCECODE"))
                activity.setSourceCode(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("REASONFORREPAIR"))
                activity.setReasonForRepair(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("WORKACCOMPLISHED"))
                activity.setWorkAccomplished(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("TECHNICIANPARTFAILURE"))
                activity.setTechnicianPartFailure(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("VMRSCODE"))
                activity.setLevel(codeSetter.setCode(activityChildNode.getFirstChild().getChildNodes()));
            if (activityChildNode.getNodeName().equals("MANUFACTURERID"))
                activity.setManufacturerId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("WARRANTY"))
                activity.setWarranty(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("ACTIVITYCOMMENT"))
                activity.setActivityComment(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("RELATEDWORKORDERID"))
                activity.setRelatedWorkOrderId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("DEFERMAINTENANCE"))
                activity.setDeferMaintenance(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("DEFERACTDIRECTMATS"))
                activity.setDeferActDirectMats(activityChildNode.getTextContent());

            if (activityChildNode.getNodeName().equals("ORIGINALWORKORDERACTID"))
                activity.setOriginalWorkOrderActivityId(activityIdSetter.setActivityId(activityChildNode.getFirstChild().getChildNodes()));

            if (activityChildNode.getNodeName().equals("PARTLOCATIONCODE"))
                activity.setPartLocationCode(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("DBSESSIONID"))
                activity.setDbSessionId(countSetter.setCount(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("SCHEDULINGSESSIONTYPE"))
                activity.setSchedulingSessionType(codeSetter.setCode(activityChildNode.getChildNodes()));

            if (activityChildNode.getNodeName().equals("WorkOrderEquipments"))
                activity.setWorkOrderEquipments(relatedWorkOrderEquipmentSetter.setWorkOrderEquipment(activityChildNode.getChildNodes()));

            if (activityChildNode.getNodeName().equals("UserDefinedFields"))
                activity.setUserDefinedFields(userDefinedFieldsSetter.setUserDefinedFields(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("LINEARREFUOM"))
                activity.setLinearReferenceUOM(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("LINEARREFERENCEEVENT"))
                activity.setLinearReferenceEvent(linearReferenceEventSetter.setLinearReferenceEvent(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("HEADEREQUIPMENTID"))
                activity.setHeaderEquipmentId(idSetter.setId(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("TOPPARENTACTIVITYCODE"))
                activity.setTopParentActivityCode(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("PARENTACTIVITYCODE"))
                activity.setParentActivityCode(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("JOBSEQUENCE"))
                activity.setJobSequence(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("OLDJOBSEQUENCE"))
                activity.setOldJobSequence(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("ISWORKORDERJOB"))
                activity.setIsWorkOrderJob(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("REUSABLE"))
                activity.setReusable(activityChildNode.getTextContent());
            if (activityChildNode.getNodeName().equals("CURRENCYID"))
                activity.setCurrency(codeSetter.setCode(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ESTIMATEDLABORCOST"))
                activity.setEstimatedLaborCost(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ESTIMATEDMATERIALCOST"))
                activity.setEstimatedMaterialCost(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ESTIMATEDMISCELLANEOUSCOST"))
                activity.setEstimatedMiscellaneousCost(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ESTIMATEDTOTALCOST"))
                activity.setEstimatedTotalCost(currencySetter.setCurrency(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("ASSIGNMENTSTATUS"))
                activity.setAssignmentStatus(codeSetter.setCode(activityChildNode.getChildNodes()));
            if (activityChildNode.getNodeName().equals("PREFERREDSUPPLIER"))
                activity.setPreferredSupplier(idSetter.setId(activityChildNode.getChildNodes()));

        }
        return activity;
    }
}
