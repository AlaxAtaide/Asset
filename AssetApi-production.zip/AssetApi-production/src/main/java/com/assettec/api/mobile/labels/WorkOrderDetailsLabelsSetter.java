package com.assettec.api.mobile.labels;

import com.assettec.api.internal.core.grid.Field;
import com.assettec.api.mobile.orders.WorkOrderDetails;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class WorkOrderDetailsLabelsSetter {
    private UserDefinedFieldsLabelsSetter userDefinedFieldsLabelsSetter;

    public void setLabels(Field field, WorkOrderDetails workOrderDetailsLabels) {

        //basic
        if (field.getName().equals("workorderstatus")) workOrderDetailsLabels.setStatus(field.getLabel());
        if (field.getName().equals("organization")) workOrderDetailsLabels.setOrganization(field.getLabel());
        if (field.getName().equals("workordernum")) workOrderDetailsLabels.setCode(field.getLabel());
        if (field.getName().equals("description")) workOrderDetailsLabels.setDescription(field.getLabel());
        if (field.getName().equals("workordertype_display")) workOrderDetailsLabels.setType(field.getLabel());
        if (field.getName().equals("workorderstatus_display")) workOrderDetailsLabels.setStatus(field.getLabel());
        if (field.getName().equals("forprint")) workOrderDetailsLabels.setPrint(field.getLabel());
        if (field.getName().equals("printed")) workOrderDetailsLabels.setPrinted(field.getLabel());
        if (field.getName().equals("location")) workOrderDetailsLabels.setLocationCode(field.getLabel());
        if (field.getName().equals("workspace")) workOrderDetailsLabels.setWorkspace(field.getLabel());
        if (field.getName().equals("department")) workOrderDetailsLabels.setDepartment(field.getLabel());
        if (field.getName().equals("oemsitesystemid")) workOrderDetailsLabels.setOemSite(field.getLabel());
        if (field.getName().equals("supplier")) workOrderDetailsLabels.setSupplier(field.getLabel());
        if (field.getName().equals("supplierorg")) workOrderDetailsLabels.setSupplier(field.getLabel());
        if (field.getName().equals("coveragetype")) workOrderDetailsLabels.setCoverageType(field.getLabel());
        if (field.getName().equals("coveragetype_display")) workOrderDetailsLabels.setCoverageType(field.getLabel());
        if (field.getName().equals("safety")) workOrderDetailsLabels.setSafety(field.getLabel());
        if (field.getName().equals("dependant")) workOrderDetailsLabels.setDepend(field.getLabel());
        if (field.getName().equals("survey")) workOrderDetailsLabels.setSurvey(field.getLabel());
        if (field.getName().equals("reliabilityranking")) workOrderDetailsLabels.setReliabilityRanking(field.getLabel());
        if (field.getName().equals("reliabilityrankingindex")) workOrderDetailsLabels.setReliabilityRankingIndex(field.getLabel());
        if (field.getName().equals("reliabilityrankingscore")) workOrderDetailsLabels.setReliabilityRankingScore(field.getLabel());
        if (field.getName().equals("createdby")) workOrderDetailsLabels.setCreatedBy(field.getLabel());
        if (field.getName().equals("datecreated")) workOrderDetailsLabels.setCreatedDate(field.getLabel());
        if (field.getName().equals("parentproperty")) workOrderDetailsLabels.setPositionCode(field.getLabel());

        if (field.getName().equals("esignaturedate")) workOrderDetailsLabels.setESignDate(field.getLabel());
        if (field.getName().equals("esignaturetype")) workOrderDetailsLabels.setESignType(field.getLabel());
        if (field.getName().equals("esigner")) workOrderDetailsLabels.setESigner(field.getLabel());
        if (field.getName().equals("warranty")) workOrderDetailsLabels.setWarranty(field.getLabel());

        //Equipment
        if (field.getName().equals("equipment")) workOrderDetailsLabels.setEquipmentCode(field.getLabel());
        if (field.getName().equals("equipmentdesc")) workOrderDetailsLabels.setEquipmentDescription(field.getLabel());
        if (field.getName().equals("equipmentorg")) workOrderDetailsLabels.setEquipmentOrganization(field.getLabel());
        if (field.getName().equals("equipmenttype")) workOrderDetailsLabels.setEquipmentType(field.getLabel());
        if (field.getName().equals("equipmenttypedesc")) workOrderDetailsLabels.setEquipmentType(field.getLabel());
        if (field.getName().equals("multiequip")) workOrderDetailsLabels.setMultipleEquipments(field.getLabel());
        if (field.getName().equals("alias")) workOrderDetailsLabels.setEquipmentAlias(field.getLabel());
        if (field.getName().equals("equipmanufacturer")) workOrderDetailsLabels.setEquipmentManufacturer(field.getLabel());

        // compliance
        if (field.getName().equals("aboveceilingpermit")) workOrderDetailsLabels.getCompliance().setAboveCeilingPermit(field.getLabel());
        if (field.getName().equals("buildingmaintenanceprogram")) workOrderDetailsLabels.getCompliance().setBuildMaintenanceProgram(field.getLabel());
        if (field.getName().equals("confinedspace")) workOrderDetailsLabels.getCompliance().setConfinedSpace(field.getLabel());
        if (field.getName().equals("interiminfectioncontrol")) workOrderDetailsLabels.getCompliance().setInterimInfectionControl(field.getLabel());
        if (field.getName().equals("interimlifesafety")) workOrderDetailsLabels.getCompliance().setInterimLifeSafety(field.getLabel());
        if (field.getName().equals("preconstructionriskassessment")) workOrderDetailsLabels.getCompliance().setPreConstructionRiskAssessment(field.getLabel());
        if (field.getName().equals("planforimprovement")) workOrderDetailsLabels.getCompliance().setPlanImprovement(field.getLabel());
        if (field.getName().equals("statementofconditions")) workOrderDetailsLabels.getCompliance().setStatementOfCondition(field.getLabel());
        if (field.getName().equals("personalprotectiveequipment")) workOrderDetailsLabels.getCompliance().setPersonalProtectiveEquipment(field.getLabel());
        if (field.getName().equals("lockouttagout")) workOrderDetailsLabels.getCompliance().setLockout(field.getLabel());
        if (field.getName().equals("hipaaconfidentiality")) workOrderDetailsLabels.getCompliance().setHipaaConfidentiality(field.getLabel());
        if (field.getName().equals("hotworkburnpermit")) workOrderDetailsLabels.getCompliance().setBurnPermit(field.getLabel());
        if (field.getName().equals("patientsafety")) workOrderDetailsLabels.getCompliance().setPatientSafety(field.getLabel());
        if (field.getName().equals("recallnotice")) workOrderDetailsLabels.getCompliance().setRecallNotice(field.getLabel());
        if (field.getName().equals("smda")) workOrderDetailsLabels.getCompliance().setSMDA(field.getLabel());

        // Production
        if (field.getName().equals("accountingentity")) workOrderDetailsLabels.getProductionDetails().setAccountingEntity(field.getLabel());
        if (field.getName().equals("productionenddate")) workOrderDetailsLabels.getProductionDetails().setProductionEndDate(field.getLabel());
        if (field.getName().equals("productionorder")) workOrderDetailsLabels.getProductionDetails().setProductionOrder(field.getLabel());
        if (field.getName().equals("productionpriority")) workOrderDetailsLabels.getProductionDetails().setProductionPriority(field.getLabel());
        if (field.getName().equals("productionprioritydescription")) workOrderDetailsLabels.getProductionDetails().setProductionPriorityDescription(field.getLabel());
        if (field.getName().equals("productionrequest")) workOrderDetailsLabels.getProductionDetails().setProductionRequest(field.getLabel());
        if (field.getName().equals("productionrequestrevision")) workOrderDetailsLabels.getProductionDetails().setProductionRequestRevision(field.getLabel());
        if (field.getName().equals("productionstartdate")) workOrderDetailsLabels.getProductionDetails().setProductionStartDate(field.getLabel());

        // Incident
        if (field.getName().equals("firesafetyincident")) workOrderDetailsLabels.getIncidentControl().setFireSafetyIncident(field.getLabel());
        if (field.getName().equals("hazardousmaterialsincident")) workOrderDetailsLabels.getIncidentControl().setHazardousMaterialsIncident(field.getLabel());
        if (field.getName().equals("medicalequipmentincident")) workOrderDetailsLabels.getIncidentControl().setMedicalEquipmentIncident(field.getLabel());
        if (field.getName().equals("securityincident")) workOrderDetailsLabels.getIncidentControl().setSecurityIncident(field.getLabel());
        if (field.getName().equals("utilitysystemincident")) workOrderDetailsLabels.getIncidentControl().setUtilitySystemIncident(field.getLabel());
        if (field.getName().equals("patientvisitorinjury")) workOrderDetailsLabels.getIncidentControl().setPatientIncident(field.getLabel());
        if (field.getName().equals("staffinjuryillness")) workOrderDetailsLabels.getIncidentControl().setStaffInjuryIncident(field.getLabel());
        if (field.getName().equals("propertydamage")) workOrderDetailsLabels.getIncidentControl().setPropertyDamageIncident(field.getLabel());

        // Details
        if (field.getName().equals("woclass")) workOrderDetailsLabels.getDetails().setClassId(field.getLabel());
        if (field.getName().equals("problemcode")) workOrderDetailsLabels.getDetails().setProblemCode(field.getLabel());
        if (field.getName().equals("criticality")) workOrderDetailsLabels.getDetails().setCriticality(field.getLabel());
        if (field.getName().equals("maintenancepattern")) workOrderDetailsLabels.getDetails().setMaintenancePatternCode(field.getLabel());
        if (field.getName().equals("parentwo")) workOrderDetailsLabels.getDetails().setParentWorkOrder(field.getLabel());
        if (field.getName().equals("cnnumber")) workOrderDetailsLabels.getDetails().setCnNumber(field.getLabel());
        if (field.getName().equals("msproject")) workOrderDetailsLabels.getDetails().setMsProject(field.getLabel());
        if (field.getName().equals("schedsessiontypedesc")) workOrderDetailsLabels.getDetails().setSchedulingSessionType(field.getLabel());
        if (field.getName().equals("schedsessiontypedesc_display")) workOrderDetailsLabels.getDetails().setSchedulingSessionType(field.getLabel());
        if (field.getName().equals("causecode")) workOrderDetailsLabels.getDetails().setCauseCode(field.getLabel());
        if (field.getName().equals("actioncode")) workOrderDetailsLabels.getDetails().setActionCode(field.getLabel());
        if (field.getName().equals("callername")) workOrderDetailsLabels.getDetails().setCallerName(field.getLabel());
        if (field.getName().equals("rejectreason")) workOrderDetailsLabels.getDetails().setRejectionReason(field.getLabel());
        if (field.getName().equals("reopened")) workOrderDetailsLabels.getDetails().setReOpened(field.getLabel());
        if (field.getName().equals("customercontract")) workOrderDetailsLabels.getDetails().setCustomerContractCode(field.getLabel());
        if (field.getName().equals("package")) workOrderDetailsLabels.getDetails().setWorkPackage(field.getLabel());
        if (field.getName().equals("alertcode")) workOrderDetailsLabels.getDetails().setAlertCode(field.getLabel());
        if (field.getName().equals("safetyreviewedby")) workOrderDetailsLabels.getDetails().setSafetyReviewedBy(field.getLabel());
        if (field.getName().equals("permitreviewedby")) workOrderDetailsLabels.getDetails().setPermitReviewedBy(field.getLabel());
        if (field.getName().equals("standardwo")) workOrderDetailsLabels.getDetails().setStandardWo(field.getLabel());
        if (field.getName().equals("customer")) workOrderDetailsLabels.getDetails().setCustomerCode(field.getLabel());
        if (field.getName().equals("priority")) workOrderDetailsLabels.getDetails().setPriorityCode(field.getLabel());
        if (field.getName().equals("priority_display")) workOrderDetailsLabels.getDetails().setPriorityCode(field.getLabel());
        if (field.getName().equals("priorityicon")) workOrderDetailsLabels.getDetails().setPriorityCode(field.getLabel());
        if (field.getName().equals("costcode")) workOrderDetailsLabels.getDetails().setCostCode(field.getLabel());
        if (field.getName().equals("lastmeterread")) workOrderDetailsLabels.getDetails().setLastMeterRating(field.getLabel());
        if (field.getName().equals("triggerevent")) workOrderDetailsLabels.getDetails().setTriggerEvent(field.getLabel());
        if (field.getName().equals("targetvalue")) workOrderDetailsLabels.getDetails().setTargetValue(field.getLabel());
        if (field.getName().equals("failurecode")) workOrderDetailsLabels.getDetails().setFailureCode(field.getLabel());
        if (field.getName().equals("routecode")) workOrderDetailsLabels.getDetails().setRouteCode(field.getLabel());
        if (field.getName().equals("routestatusdesc")) workOrderDetailsLabels.getDetails().setRouteStatus(field.getLabel());
        if (field.getName().equals("routestatusdesc_display")) workOrderDetailsLabels.getDetails().setRouteStatus(field.getLabel());
        if (field.getName().equals("downtimecost")) workOrderDetailsLabels.getDetails().setDownTimeCost(field.getLabel());
        if (field.getName().equals("downtimehours")) workOrderDetailsLabels.getDetails().setDownTimeHours(field.getLabel());
        if (field.getName().equals("originatingjob")) workOrderDetailsLabels.getDetails().setOriginalWorkOrder(field.getLabel());
        if (field.getName().equals("originatingwoactivity")) workOrderDetailsLabels.getDetails().setOriginalWorkOrder(field.getLabel());
        if (field.getName().equals("calcpriority")) workOrderDetailsLabels.getDetails().setCalculatedPriority(field.getLabel());
        if (field.getName().equals("categoryname")) workOrderDetailsLabels.getDetails().setCategoryCode(field.getLabel());
        if (field.getName().equals("categoryname_display")) workOrderDetailsLabels.getDetails().setCategoryCode(field.getLabel());
        if (field.getName().equals("preservecalcpriority")) workOrderDetailsLabels.getDetails().setPreserveCalculatedPriority(field.getLabel());
        if (field.getName().equals("minor")) workOrderDetailsLabels.getDetails().setMinor(field.getLabel());
        if (field.getName().equals("latitude")) workOrderDetailsLabels.getDetails().setLatitude(field.getLabel());
        if (field.getName().equals("longitude")) workOrderDetailsLabels.getDetails().setLongitude(field.getLabel());
        if (field.getName().equals("pmcode")) workOrderDetailsLabels.getDetails().setPpmCode(field.getLabel());
        if (field.getName().equals("property")) workOrderDetailsLabels.getDetails().setLevel1(field.getLabel());

        // customer service details
        if (field.getName().equals("eqpusabilitydesc")) workOrderDetailsLabels.getCustomerServiceDetails().setEquipmentUsability(field.getLabel());
        if (field.getName().equals("permfixpromisedate")) workOrderDetailsLabels.getCustomerServiceDetails().setPermanentFixPromisedDate(field.getLabel());
        if (field.getName().equals("tempfixdatecompleted")) workOrderDetailsLabels.getCustomerServiceDetails().setTemporaryFixDateCompleted(field.getLabel());
        if (field.getName().equals("tempfixpromisedate")) workOrderDetailsLabels.getCustomerServiceDetails().setTempFixPromiseDate(field.getLabel());
        if (field.getName().equals("servicecategory")) workOrderDetailsLabels.getCustomerServiceDetails().setProviderServiceCategoryCode(field.getLabel());
        if (field.getName().equals("servicecategoryorg")) workOrderDetailsLabels.getCustomerServiceDetails().setProviderServiceCategoryOrganization(field.getLabel());
        if (field.getName().equals("servicecustomerrequest")) workOrderDetailsLabels.getCustomerServiceDetails().setSupplierServiceCategoryCode(field.getLabel());
        if (field.getName().equals("servicecustomerrequestorg")) workOrderDetailsLabels.getCustomerServiceDetails().setSupplierServiceCategoryOrganization(field.getLabel());
        if (field.getName().equals("serviceproblemcode")) workOrderDetailsLabels.getCustomerServiceDetails().setServiceProblemCode(field.getLabel());
        if (field.getName().equals("serviceproblemcodeorg")) workOrderDetailsLabels.getCustomerServiceDetails().setServiceProblemCodeOrganization(field.getLabel());
        if (field.getName().equals("servicerequeststatus")) workOrderDetailsLabels.getCustomerServiceDetails().setWorkAddress(field.getLabel());
        if (field.getName().equals("servicerequeststatus_display")) workOrderDetailsLabels.getCustomerServiceDetails().setWorkAddress(field.getLabel());
        if (field.getName().equals("workaddress")) workOrderDetailsLabels.getCustomerServiceDetails().setWorkAddress(field.getLabel());
        if (field.getName().equals("totalestimatedcost")) workOrderDetailsLabels.getCustomerServiceDetails().setEstimatedTotalCost(field.getLabel());
        if (field.getName().equals("totalestlaborcost")) workOrderDetailsLabels.getCustomerServiceDetails().setEstimatedLaborCost(field.getLabel());
        if (field.getName().equals("totalestmatlcost")) workOrderDetailsLabels.getCustomerServiceDetails().setEstimatedMaterialCost(field.getLabel());
        if (field.getName().equals("totalestmisccost")) workOrderDetailsLabels.getCustomerServiceDetails().setEstimatedMiscellaneousCost(field.getLabel());

        //Activity
        if (field.getName().equals("actenddate")) workOrderDetailsLabels.getActivity().setActivityEndDate(field.getLabel());
        if (field.getName().equals("activity")) workOrderDetailsLabels.getActivity().setActivityCode(field.getLabel());
        if (field.getName().equals("actstartdate")) workOrderDetailsLabels.getActivity().setActivityStartDate(field.getLabel());
        if (field.getName().equals("multipletrades")) workOrderDetailsLabels.getActivity().setTradeCode(field.getLabel());
        if (field.getName().equals("trade")) workOrderDetailsLabels.getActivity().setTradeCode(field.getLabel());
        if (field.getName().equals("task")) workOrderDetailsLabels.getActivity().setTaskCode(field.getLabel());
        if (field.getName().equals("matlcode")) workOrderDetailsLabels.getActivity().setMaterialList(field.getLabel());
        if (field.getName().equals("reasonforrepair")) workOrderDetailsLabels.getActivity().setRepairReason(field.getLabel());
        if (field.getName().equals("workaccomplished")) workOrderDetailsLabels.getActivity().setWorkAccomplished(field.getLabel());
        if (field.getName().equals("techpartfailure")) workOrderDetailsLabels.getActivity().setTechnicianPartFailure(field.getLabel());
        if (field.getName().equals("manufacturer")) workOrderDetailsLabels.getActivity().setManufacturerCode(field.getLabel());
        if (field.getName().equals("esthrs")) workOrderDetailsLabels.getActivity().setEstimatedHours(field.getLabel());
        if (field.getName().equals("remhrs")) workOrderDetailsLabels.getActivity().setHoursRemaining(field.getLabel());
        if (field.getName().equals("pplreq")) workOrderDetailsLabels.getActivity().setPersons(field.getLabel());
        if (field.getName().equals("syslevel")) workOrderDetailsLabels.getActivity().setSystemLevel(field.getLabel());
        if (field.getName().equals("complevel")) workOrderDetailsLabels.getActivity().setComponentLevel(field.getLabel());
        if (field.getName().equals("asslevel")) workOrderDetailsLabels.getActivity().setAssemblyLevel(field.getLabel());
        if (field.getName().equals("componentlocation")) workOrderDetailsLabels.getActivity().setPartLocation(field.getLabel());


        // Schedule
        if (field.getName().equals("assignedto")) workOrderDetailsLabels.getSchedule().setAssignedTo(field.getLabel());
        if (field.getName().equals("datereported")) workOrderDetailsLabels.getSchedule().setReportedDate(field.getLabel());
        if (field.getName().equals("reportedby")) workOrderDetailsLabels.getSchedule().setReportedBy(field.getLabel());
        if (field.getName().equals("schedstartdate")) workOrderDetailsLabels.getSchedule().setProgramedStartDate(field.getLabel());
        if (field.getName().equals("schedenddate")) workOrderDetailsLabels.getSchedule().setProgramedEndDate(field.getLabel());
        if (field.getName().equals("reqenddate")) workOrderDetailsLabels.getSchedule().setSolicitedEndDate(field.getLabel());
        if (field.getName().equals("reqstartdate")) workOrderDetailsLabels.getSchedule().setSolicitedStartDate(field.getLabel());
        if (field.getName().equals("startdate")) workOrderDetailsLabels.getSchedule().setStartDate(field.getLabel());
        if (field.getName().equals("enddate")) workOrderDetailsLabels.getSchedule().setEndDate(field.getLabel());
        if (field.getName().equals("shift")) workOrderDetailsLabels.getSchedule().setShift(field.getLabel());
        if (field.getName().equals("projbud")) workOrderDetailsLabels.getSchedule().setBudget(field.getLabel());
        if (field.getName().equals("campaign")) workOrderDetailsLabels.getSchedule().setCampaign(field.getLabel());
        if (field.getName().equals("schedgroup")) workOrderDetailsLabels.getSchedule().setAssignedBy(field.getLabel());
        if (field.getName().equals("datecompleted")) workOrderDetailsLabels.getSchedule().setEndDate(field.getLabel());
        if (field.getName().equals("servicerequestid")) workOrderDetailsLabels.getSchedule().setServiceRequestCode(field.getLabel());

        // LinearReference
        if (field.getName().equals("frompoint")) workOrderDetailsLabels.getLinearReferenceDetails().setFromPoint(field.getLabel());
        if (field.getName().equals("fromrefdesc")) workOrderDetailsLabels.getLinearReferenceDetails().setFromRefDescription(field.getLabel());
        if (field.getName().equals("fromgeoref")) workOrderDetailsLabels.getLinearReferenceDetails().setFromGeoRef(field.getLabel());

        if (field.getName().equals("topoint")) workOrderDetailsLabels.getLinearReferenceDetails().setToPoint(field.getLabel());
        if (field.getName().equals("torefdesc")) workOrderDetailsLabels.getLinearReferenceDetails().setToRefDescription(field.getLabel());
        if (field.getName().equals("togeoref")) workOrderDetailsLabels.getLinearReferenceDetails().setToGeoRef(field.getLabel());

        if (field.getName().equals("inspectiondirection_display")) workOrderDetailsLabels.getLinearReferenceDetails().setInspectionDirection(field.getLabel());
        if (field.getName().equals("flow_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFlow(field.getLabel());
        if (field.getName().equals("relationshiptype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setRelationship(field.getLabel());

        if (field.getName().equals("fromreferencepoint")) workOrderDetailsLabels.getLinearReferenceDetails().setFromReference(field.getLabel());
        if (field.getName().equals("fromoffset")) workOrderDetailsLabels.getLinearReferenceDetails().setFromOffset(field.getLabel());
        if (field.getName().equals("fromoffsetpercent")) workOrderDetailsLabels.getLinearReferenceDetails().setFromOffsetPercentage(field.getLabel());
        if (field.getName().equals("fromoffsetdirection")) workOrderDetailsLabels.getLinearReferenceDetails().setFromOffsetDirection(field.getLabel());
        if (field.getName().equals("relatedfromreference")) workOrderDetailsLabels.getLinearReferenceDetails().setFromReference(field.getLabel());
        if (field.getName().equals("relatedfromreferencedesc")) workOrderDetailsLabels.getLinearReferenceDetails().setFromRelatedReference(field.getLabel());
        if (field.getName().equals("relatedfromoffset")) workOrderDetailsLabels.getLinearReferenceDetails().setFromRelatedOffset(field.getLabel());
        if (field.getName().equals("relatedfromoffsetdir")) workOrderDetailsLabels.getLinearReferenceDetails().setFromRelatedOffsetDirection(field.getLabel());
        if (field.getName().equals("fromxcoordinate")) workOrderDetailsLabels.getLinearReferenceDetails().setFromCoordinateX(field.getLabel());
        if (field.getName().equals("fromycoordinate")) workOrderDetailsLabels.getLinearReferenceDetails().setFromCoordinateY(field.getLabel());
        if (field.getName().equals("fromlatitude")) workOrderDetailsLabels.getLinearReferenceDetails().setFromLatitude(field.getLabel());
        if (field.getName().equals("fromlongitude")) workOrderDetailsLabels.getLinearReferenceDetails().setFromLongitude(field.getLabel());
//        if (field.getName().equals("fromrelationshiptype")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalRelationShip(field.getLabel());
        if (field.getName().equals("fromrelationshiptype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalRelationShip(field.getLabel());
        if (field.getName().equals("fromhorizontaloffset")) workOrderDetailsLabels.getLinearReferenceDetails().setFromHorizontalOffset(field.getLabel());
//        if (field.getName().equals("fromhoroffsettype")) workOrderDetailsLabels.getLinearReferenceDetails().setFromHorizontalOffsetType(field.getLabel());
        if (field.getName().equals("fromhoroffsettype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFromHorizontalOffsetType(field.getLabel());
        if (field.getName().equals("fromverticaloffset")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalOffset(field.getLabel());
//        if (field.getName().equals("fromverticaloffsettype")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalOffsetType(field.getLabel());
        if (field.getName().equals("fromverticaloffsettype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalOffsetType(field.getLabel());


        if (field.getName().equals("toreferencepoint")) workOrderDetailsLabels.getLinearReferenceDetails().setToReference(field.getLabel());
        if (field.getName().equals("tooffset")) workOrderDetailsLabels.getLinearReferenceDetails().setToOffset(field.getLabel());
        if (field.getName().equals("tooffsetpercent")) workOrderDetailsLabels.getLinearReferenceDetails().setToOffsetPercentage(field.getLabel());
        if (field.getName().equals("tooffsetdirection")) workOrderDetailsLabels.getLinearReferenceDetails().setToOffsetDirection(field.getLabel());
        if (field.getName().equals("relatedtoreferencedesc")) workOrderDetailsLabels.getLinearReferenceDetails().setToRelatedReference(field.getLabel());
        if (field.getName().equals("relatedtooffset")) workOrderDetailsLabels.getLinearReferenceDetails().setToRelatedOffset(field.getLabel());
        if (field.getName().equals("relatedtooffsetdir")) workOrderDetailsLabels.getLinearReferenceDetails().setToRelatedOffsetDirection(field.getLabel());
        if (field.getName().equals("toxcoordinate")) workOrderDetailsLabels.getLinearReferenceDetails().setToCoordinateX(field.getLabel());
        if (field.getName().equals("toycoordinate")) workOrderDetailsLabels.getLinearReferenceDetails().setToCoordinateY(field.getLabel());
        if (field.getName().equals("tolatitude")) workOrderDetailsLabels.getLinearReferenceDetails().setToLatitude(field.getLabel());
        if (field.getName().equals("tolongitude")) workOrderDetailsLabels.getLinearReferenceDetails().setToLongitude(field.getLabel());
//        if (field.getName().equals("torelationshiptype")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalRelationShip(field.getLabel());
        if (field.getName().equals("torelationshiptype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalRelationShip(field.getLabel());
        if (field.getName().equals("tohorizontaloffset")) workOrderDetailsLabels.getLinearReferenceDetails().setToHorizontalOffset(field.getLabel());
//        if (field.getName().equals("tohorizontaloffsettype")) workOrderDetailsLabels.getLinearReferenceDetails().setToHorizontalOffsetType(field.getLabel());
        if (field.getName().equals("tohorizontaloffsettype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setToHorizontalOffsetType(field.getLabel());
        if (field.getName().equals("toverticaloffset")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalOffset(field.getLabel());
//        if (field.getName().equals("toverticaloffsettype")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalOffsetType(field.getLabel());
        if (field.getName().equals("toverticaloffsettype_display")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalOffsetType(field.getLabel());

        //Num sei

        //if (field.getName().equals("relatedtoreference")) workOrderDetailsLabels.getLinearReferenceDetails().setToReferenceCode(field.getLabel());
        //if (field.getName().equals("fromhoroffsetuom")) workOrderDetailsLabels.getLinearReferenceDetails().setFromHorizontalOffset(field.getLabel());
        //if (field.getName().equals("fromhoroffsetuom_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFromHorizontalOffset(field.getLabel());
        //if (field.getName().equals("fromoffset")) workOrderDetailsLabels.getLinearReferenceDetails().setFromOffsetLinearReferenceDetails(field.getLabel());
        //if (field.getName().equals("fromverticaloffsetuom")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalOffsetType(field.getLabel());
        //if (field.getName().equals("fromverticaloffsetuom_display")) workOrderDetailsLabels.getLinearReferenceDetails().setFromVerticalOffsetType(field.getLabel());
        //if (field.getName().equals("tohorizontaloffsetuom")) workOrderDetailsLabels.getLinearReferenceDetails().setToHorizontalOffset(field.getLabel());
        //if (field.getName().equals("tohorizontaloffsetuom_display")) workOrderDetailsLabels.getLinearReferenceDetails().setToHorizontalOffset(field.getLabel());
        //if (field.getName().equals("tooffset")) workOrderDetailsLabels.getLinearReferenceDetails().setToOffsetLinearReferenceDetails(field.getLabel());
        //if (field.getName().equals("toverticaloffsetuom")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalOffsetType(field.getLabel());
        //if (field.getName().equals("toverticaloffsetuom_display")) workOrderDetailsLabels.getLinearReferenceDetails().setToVerticalOffsetType(field.getLabel());
        //if (field.getName().equals("calalerttolerance")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("caleffectivedate")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calibrationinterval")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calibrationstatus")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calincrement")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calintervaluom")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("callastcalibrated")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calperformedby")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calprecision")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calreviewedby")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("calsop")) workOrderDetailsLabels.setSurvey(field.getLabel());

        //if (field.getName().equals("casecode")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("casetype")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("casetype_display")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("classorganization")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("dependant")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("duplicatecase")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("duration")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("enteredbydesc")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("estlaborcostcurrency")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("evt_rstatus")) workOrderDetailsLabels.setSurvey(field.getLabel());

        //if (field.getName().equals("meteruom")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("origcasemanagementtask")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("originatingcase")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("parentpropertydesc")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("project")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("recordid")) workOrderDetailsLabels.setSurvey(field.getLabel());

        //if (field.getName().equals("sequence")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("statusicon")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("timecreated")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("vendor")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("workorderrtype")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("workorderrtypedesc")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("workorderstatuscode")) workOrderDetailsLabels.setSurvey(field.getLabel());
        //if (field.getName().equals("duedate")) workOrderDetailsLabels.setSurvey(field.getLabel());

        userDefinedFieldsLabelsSetter.setLabels(field,workOrderDetailsLabels);
    }
}
