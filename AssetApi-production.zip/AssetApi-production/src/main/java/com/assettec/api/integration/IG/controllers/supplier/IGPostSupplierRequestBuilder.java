package com.assettec.api.integration.IG.controllers.supplier;

import com.assettec.api.internal.utilities.requests.requestbuilders.common.XMLRequestHeader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class IGPostSupplierRequestBuilder {
    private XMLRequestHeader xmlRequestHeader;

    public String postIGSupplier(String userName, String tenant,String passWord, String organization, String supplierCode, String supplierOrganization, String supplierDescription, String languageCode, String currencyCode, String udfString) {
        return "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                xmlRequestHeader.postRequestHeader(userName,tenant,passWord,organization) +
                "    <Body>\n" +
                "        <MP0291_AddSupplier_001 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" verb=\"Add\" noun=\"Supplier\" version=\"001\" xmlns=\"http://schemas.datastream.net/MP_functions/MP0291_001\">\n" +
                "            <Supplier recordid=\"1\" xmlns=\"http://schemas.datastream.net/MP_entities/Supplier_001\">\n" +
                "                <SUPPLIERID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <SUPPLIERCODE>" + supplierCode + "</SUPPLIERCODE>\n" +
                "                    <ORGANIZATIONID entity=\"User\">\n" +
                "                        <ORGANIZATIONCODE>" + supplierOrganization + "</ORGANIZATIONCODE>\n" +
                "                    </ORGANIZATIONID>\n" +
                "                    <DESCRIPTION>" + supplierDescription + "</DESCRIPTION>\n" +
                "                </SUPPLIERID>\n" +
                "                <LANGUAGEID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <LANGUAGECODE>" + languageCode + "</LANGUAGECODE>\n" +
                "                </LANGUAGEID>\n" +
                "                <CURRENCYID xmlns=\"http://schemas.datastream.net/MP_fields\">\n" +
                "                    <CURRENCYCODE>" + currencyCode + "</CURRENCYCODE>\n" +
                "                </CURRENCYID>\n" +
                "                <UserDefinedFields>\n" +
                "                    <UDFCHAR01 xmlns=\"http://schemas.datastream.net/MP_fields\">" + udfString + "</UDFCHAR01> \n" +
                "                </UserDefinedFields>\n" +
                "            </Supplier>\n" +
                "        </MP0291_AddSupplier_001>\n" +
                "    </Body>\n" +
                "</Envelope>";
    }
}
