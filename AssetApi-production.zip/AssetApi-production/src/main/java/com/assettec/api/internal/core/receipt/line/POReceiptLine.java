package com.assettec.api.internal.core.receipt.line;

import com.assettec.api.internal.core.items.part.Part;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class POReceiptLine {
    private Long id;
    private String purchaseOrderType;
    private Part part;
}
